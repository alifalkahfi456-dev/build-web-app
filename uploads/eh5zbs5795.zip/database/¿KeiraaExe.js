module.exports = {
  tokens: "8560977514:AAE_89Q4ICTfjOeIEBBia4qEeSiNkuba8uI", 
  owner: "8384929286", 
  port: "2245", // Ini Wajib Jangan Diubah
  ipvps: "http://indryblabla.pterodacytl.my.id:2245" // Jangan Diubah Nanti Eror!!
};