const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeCacheableSignalKeyStore, 
    Browsers,
    delay
} = require("@whiskeysockets/baileys");
const fs = require('fs');
const pino = require('pino');
const path = require('path');

// --- 1. SETUP DATABASE & SESSION ---
const dbFolder = path.join(process.cwd(), "database");
const file_session = path.join(dbFolder, "sessions.json");
const sessions_dir = path.join(dbFolder, "auth"); 

const sessions = new Map(); // Global Map Session

// Auto Create Folder
if (!fs.existsSync(dbFolder)) fs.mkdirSync(dbFolder, { recursive: true });
if (!fs.existsSync(file_session)) fs.writeFileSync(file_session, JSON.stringify([]));

// --- 2. FUNGSI SAVE/DELETE ---
const saveActive = (number) => {
    try {
        let data = JSON.parse(fs.readFileSync(file_session, 'utf-8') || '[]');
        if (!data.includes(number)) {
            data.push(number);
            fs.writeFileSync(file_session, JSON.stringify(data, null, 2));
        }
    } catch (e) { console.error("Error Save:", e); }
};

const deleteActive = (number) => {
    try {
        let data = JSON.parse(fs.readFileSync(file_session, 'utf-8') || '[]');
        const newData = data.filter(n => n !== number);
        fs.writeFileSync(file_session, JSON.stringify(newData, null, 2));
    } catch (e) { console.error("Error Delete:", e); }
};

// --- 3. FUNGSI UTAMA: ADD SENDER ---
const addSender = async (number) => {
    return new Promise(async (resolve, reject) => {
        try {
            const sessionDir = path.join(sessions_dir, number);
            if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });

            const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
            const { version } = await fetchLatestBaileysVersion();

                        const sock = makeWASocket({
                auth: {
                    creds: state.creds,
                    keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
                },
                printQRInTerminal: false,
                logger: pino({ level: "silent" }),
                browser: ["Ubuntu", "Chrome", "20.0.04"], 
                version,
                markOnlineOnConnect: true
            });

            // Simpan ke Memory
            sessions.set(number, sock);

            // Listener
            sock.ev.on("connection.update", async (update) => {
                const { connection, lastDisconnect } = update;

                if (connection === "close") {
                    const code = lastDisconnect?.error?.output?.statusCode;
                    if (code !== DisconnectReason.loggedOut) {
                        console.log(`[ ${number} ] Reconnecting...`);
                        await addSender(number); // Reconnect
                    } else {
                        console.log(`[ ${number} ] Logged Out`);
                        sessions.delete(number);
                        deleteActive(number);
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                    }
                } else if (connection === "open") {
                    console.log(`[ ${number} ] Connected ✅`);
                    saveActive(number);
                }
            });

            sock.ev.on("creds.update", saveCreds);

            // Request Pairing Code (Jika belum terdaftar)
            if (!sock.authState.creds.registered) {
                setTimeout(async () => {
                    try {
                        const code = await sock.requestPairingCode(number);
                        resolve({ status: true, code: code?.match(/.{1,4}/g)?.join("-") || code });
                    } catch (err) {
                        reject({ status: false, message: "Gagal request code" });
                    }
                }, 3000);
            } else {
                resolve({ status: true, message: "Already Connected" });
            }

        } catch (error) {
            console.error(error);
            reject({ status: false, message: "Internal Error" });
        }
    });
};

// --- EXPORT AGAR BISA DIBACA INDEX.JS ---
module.exports = { addSender, sessions, file_session };