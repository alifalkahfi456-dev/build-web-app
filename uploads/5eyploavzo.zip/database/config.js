module.exports = {
  tokens: "8352490397:AAH2WMwOLiKG5W1Xhkg2eSIZKWcJN_aS-jk",  // Ubah Jadi Token Bot Mu !!!
  owner: "8061941312", // Ubah Jadi Id Mu !!!
  port: "2590", // Ubah Jadi Port Panel Mu !!!
  ipvps: "andinofficial.web.id" // Ubah Jadi Ip Vps Mu !!!
};