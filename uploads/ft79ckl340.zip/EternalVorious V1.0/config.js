module.exports = {
  BOT_TOKEN: "TOKEN_BOT_LU",
  OWNER_ID: ["ID_TELEGRAM_LU"],
};

//thanks to buying base