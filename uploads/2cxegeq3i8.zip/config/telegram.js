module.exports = {
  TOKEN: process.env.TELEGRAM_TOKEN || "8532438826:AAHQd0gbpNS8yvqpjODiof-cq4VV_FKcEKQ",
  OWNER_ID: process.env.OWNER_ID || 8038739051,
  ID_GROUP: [
    -1002933860223
  ],
  ID_GROUP_UTAMA: [
    -1002933860223
  ]
};