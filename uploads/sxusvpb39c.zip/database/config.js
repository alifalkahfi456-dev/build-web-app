module.exports = {
      tokens: "8304738283:AAGBAIFQDyKGogiytTmAj9GKFT3_j3T0AK0",  // Ubah Jadi Token Bot Mu !!!
  owner: "7234392093", // Ubah Jadi Id Mu !!!
  port: "2149", // Ubah Jadi Port Panel Mu !!!
  ipvps: "http://a.mbbstore.my.id" // Ubah Jadi Ip Vps Mu !!!
};