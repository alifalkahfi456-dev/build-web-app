/* 

=========================================================================

⎋ Developer : FallOffcial 
Telegram :  https://t.me/XxzFallOffc

=========================================================================

*/
const settings = {
  token: '7117460687:AAFfPW3Ph5YGhzbUiw51nZQVDIEvsqgc6ts', // Token Bot
  adminId: '1944622477', // Admin Id
  urladmin: 'https://t.me/XxzFallOffc',
  apiSimpelBot: 'new2025',      
  merchantIdOrderKuota: '-', 
  apiOrderKuota: '-',
  qrisOrderKuota: '-',
  domain: 'https://com.cfxcloud.com', // domain
  plta: 'ptla_AxPsxxxhcpgF4fwnYUj5CrTpbgwhkzm063MFOBeefg0', // plta yang sesuai
  pltc: 'ptlc_an4EMbxBl2BeeYDNA2SOlkIRWedMzrlRM0EuCbc6D7Z', // pltc yang sesuai
  domain2: '-', // domain server 2
  plta2: '', // plta srrver 2
  pltc2: '-', // pltc server 2
  pp: 'https://files.catbox.moe/v8mvrk.jpg',
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;
