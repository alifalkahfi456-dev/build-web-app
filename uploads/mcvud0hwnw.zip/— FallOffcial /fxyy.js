const _0x364fe1 = require("node-telegram-bot-api");
const _0x2230b1 = require("fs");
const _0x1063a4 = require("axios");
const _0x1ad1ce = require("os");
const _0x388663 = require("yt-search");
const _0x10d57f = require("ytdl-core");
const _0x12cc77 = require("./settings");
const _0x1ae6d5 = require("./domains");
const _0x28255e = require("./tokens");
const _0x1093ad = require("path");
const _0x516d9d = _0x12cc77.token;
const _0x1823e6 = _0x12cc77.adminId;
const _0x187e45 = "adminID.json";
const _0x734f29 = "premiumUsers.json";
const _0xc4d1de = "premiumUsers2.json";
const _0x410be8 = require("./resellersubdo.json");
const _0x10528c = require("crypto");
const _0x57388a = require("chalk");
const {
  tiktokDl: _0x24d2ef
} = require("./scraper");
const {
  execSync: _0x222be6
} = require("child_process");
const _0x2697f8 = require("moment");
const _0x4d6a17 = (_0x45fbdc, _0x13b559) => _0x3f7a03.sendMessage(_0x45fbdc, _0x13b559);
const {
  ImageUploadService: _0x32e233
} = require("node-upload-images");
const _0x29129e = _0x2697f8().format("YYYY-MM-DD HH:mm:ss");
console.log(_0x29129e);
const _0x544de9 = _0x12cc77.adminid;
const _0xb62ec7 = _0x12cc77.domain;
const _0x5a238b = _0x12cc77.plta;
const _0x40f116 = _0x12cc77.pltc;
const _0x206b50 = _0x12cc77.domain2;
const _0x447c7d = _0x12cc77.plta2;
const _0x549bc1 = _0x12cc77.pltc2;
const _0x40655f = _0x12cc77.apisimplebot;
const _0x63ed5f = _0x12cc77.qrisOrderKuota;
const _0x3aea56 = _0x12cc77.apiOrderKuota;
const _0x3ea3bf = _0x12cc77.merchantIdOrderKuota;
const _0x2f1450 = {};
const {
  Client: _0x241de6
} = require("ssh2");
try {
  premiumUsers = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
} catch (_0x2bc8a0) {
  console.error("Error reading premiumUsers file:", _0x2bc8a0);
}
const _0x1e6019 = () => {
  _0x2230b1.writeFileSync("./resellersubdo.json", JSON.stringify(_0x410be8));
};
const _0x3f7a03 = new _0x364fe1(_0x516d9d, {
  polling: true
});
try {
  adminUsers = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
} catch (_0x15652a) {
  console.error("Error reading adminUsers file:", _0x15652a);
}
function _0x3d4cb8(_0x114616, _0x439bc6) {
  return Math.floor(Math.random() * (_0x439bc6 - _0x114616 + 1)) + _0x114616;
}
function _0x51f680() {
  const _0x85c83b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let _0x1d5e6d = "";
  for (let _0xa23973 = 0; _0xa23973 < 12; _0xa23973++) {
    _0x1d5e6d += _0x85c83b.charAt(Math.floor(Math.random() * _0x85c83b.length));
  }
  return _0x1d5e6d;
}
function _0x380e37() {
  const _0x4b0d29 = process.memoryUsage().heapUsed / 1024 / 1024;
  return Math.round(_0x4b0d29 * 100) / 100 + " MB";
}
function _0x3eabde() {
  const _0x2dbcb8 = _0x1ad1ce.totalmem() / 1024 / 1024;
  return Math.round(_0x2dbcb8 * 100) / 100 + " MB";
}
const _0x2d6996 = _0x380e37();
const _0x1bb6fd = _0x3eabde();
if (_0x2d6996 && _0x1bb6fd) {
  console.log("RAM VPS: " + _0x2d6996 + " / " + _0x1bb6fd);
} else {
  console.error("Gagal mendapatkan informasi RAM.");
}
function _0x2e916c(_0x2808ae) {
  const _0x1c8f20 = process.uptime();
  const _0x5bb46e = Math.floor(_0x1c8f20 / 3600);
  const _0x1d408d = Math.floor(_0x1c8f20 % 3600 / 60);
  const _0x374725 = Math.floor(_0x1c8f20 % 60);
  return _0x5bb46e + " Jam " + _0x1d408d + " Menit " + _0x374725 + " Detik";
}
const _0x5eef87 = Date.now();
_0x3f7a03.onText(/\/start/, _0x19eec5 => {
  const _0x1d978e = _0x19eec5.chat.id;
  const _0x41c3b8 = _0x19eec5.from.id;
  const _0x20151e = _0x19eec5.from.username ? "User: @" + _0x19eec5.from.username : "User ID: " + _0x41c3b8;
  let _0x932fd3 = " \nhello @" + _0x19eec5.from.username + " I'm a Bot Create Panel special group — Discusicon dis Who is ready, helps with any problem\n\n╭── ⋅ ⋅ ── ⋅ ⋅ ─── ⋅ ⋅ ── ─ ⋅ ⋅ ── \n |  ⎋ Developer : @XxzFallOffc\n |  ⎋ Runtime :  " + _0x2e916c(_0x5eef87) + "\n╰── ⋅ ⋅ ──── ⋅ ⋅ ──── ⋅ ⋅ ──── \n Pilih Menu Button Ke Bawah\n      \n";
  _0x3f7a03.sendPhoto(_0x1d978e, "https://files.catbox.moe/v8mvrk.jpg", {
    caption: _0x932fd3,
    reply_markup: {
      inline_keyboard: [[{
        text: "CEK ID",
        callback_data: "cekid"
      }, {
        text: "CREATE PANEL",
        callback_data: "createpanel"
      }, {
        text: "INSTALL PANEL",
        callback_data: "panelinstall"
      }], [{
        text: "OWNER MENU",
        callback_data: "ownermenu"
      }, {
        text: "INSTALL TEMA",
        callback_data: "temainstall"
      }, {
        text: "DOWNLOAD MENU",
        callback_data: "downloadmenu"
      }], [{
        text: "Ｃｏｎｔａｃｋ",
        url: "https://t.me/XxzFallOffc"
      }], [{
        text: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        url: "https://t.me/boyxzsstarboy"
      }]]
    }
  });
});
_0x3f7a03.on("callback_query", _0x2265e4 => {
  if (_0x2265e4.data === "createpanel") {
    _0x3f7a03.answerCallbackQuery(_0x2265e4.id);
    const _0x553fce = " ━❏「 🖥️ Create Pterodact 」❏━\n➥ /1gb [nama,idtele] – Buat server 1GB\n➥ /2gb [nama,idtele] – Buat server 2GB\n➥ /3gb [nama,idtele] – Buat server 3GB\n➥ /4gb [nama,idtele] – Buat server 4GB\n➥ /5gb [nama,idtele] – Buat server 5GB\n➥ /6gb [nama,idtele] – Buat server 6GB\n➥ /7gb [nama,idtele] – Buat server 7GB\n➥ /8gb [nama,idtele] – Buat server 8GB\n➥ /9gb [nama,idtele] – Buat server 9GB\n➥ /10gb [nama,idtele] – Buat server 10GB\n➥ /unli [nama,idtele] – Buat server UNLI\n➥ /createadmin [nama,idtele] – Bikin admin\n➥ /listsrv – Daftar server\n➥ /listusr – Daftar pengguna\n➥ /clearserver – Hapus semua server\n➥ /clearuser – Hapus semua users";
    _0x3f7a03.editMessageCaption(_0x553fce, {
      chat_id: _0x2265e4.message.chat.id,
      message_id: _0x2265e4.message.message_id,
      reply_markup: {
        inline_keyboard: [[{
          text: "CEK ID",
          callback_data: "cekid"
        }, {
          text: "CREATE SRV2",
          callback_data: "createpanel2"
        }, {
          text: "INSTALL PANEL",
          callback_data: "panelinstall"
        }], [{
          text: "OWNER MENU",
          callback_data: "ownermenu"
        }, {
          text: "TEMA MENU",
          callback_data: "cekid"
        }, {
          text: "DOWNLOAD MENU",
          callback_data: "downloadmenu"
        }], [{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }], [{
          text: " Ｂ Ａ Ｃ Ｋ ",
          callback_data: "beck"
        }]]
      }
    });
  }
});
_0x3f7a03.on("callback_query", _0xc3616 => {
  if (_0xc3616.data === "createpanel2") {
    _0x3f7a03.answerCallbackQuery(_0xc3616.id);
    const _0x2b372c = " ━❏「 🖥️ Create Pterodact2 」❏━\n➥ /1gb2 [nama,idtele] – Buat server2 1GB\n➥ /2gb2 [nama,idtele] – Buat server2 2GB\n➥ /3gb2 [nama,idtele] – Buat server2 3GB\n➥ /4gb2 [nama,idtele] – Buat server2 4GB\n➥ /5gb2 [nama,idtele] – Buat server2 5GB\n➥ /6gb2 [nama,idtele] – Buat server2 6GB\n➥ /7gb2 [nama,idtele] – Buat server2 7GB\n➥ /8gb2 [nama,idtele] – Buat server2 8GB\n➥ /9gb2 [nama,idtele] – Buat server2 9GB\n➥ /10gb2 [nama,idtele] – Buat server2 10GB\n➥ /unli2 [nama,idtele] – Buat server2 UNLI\n➥ /createadmin2 [nama,idtele] – Bikin admin2\n➥ /listsrv2 – Daftar server2\n➥ /listusr2 – Daftar pengguna2\n➥ /clearserver2 – Hapus semua server2\n➥ /clearuser2   – Hapus semua users2";
    _0x3f7a03.editMessageCaption(_0x2b372c, {
      chat_id: _0xc3616.message.chat.id,
      message_id: _0xc3616.message.message_id,
      reply_markup: {
        inline_keyboard: [[{
          text: "CEK ID",
          callback_data: "cekid"
        }, {
          text: "CREATE SRV1",
          callback_data: "createpanel"
        }, {
          text: "INSTALL PANEL",
          callback_data: "panelinstall"
        }], [{
          text: "OWNER MENU",
          callback_data: "ownermenu"
        }, {
          text: "TEMA MENU",
          callback_data: "cekid"
        }, {
          text: "DOWNLOAD MENU",
          callback_data: "downloadmenu"
        }], [{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }], [{
          text: " Ｂ Ａ Ｃ Ｋ ",
          callback_data: "beck"
        }]]
      }
    });
  }
});
_0x3f7a03.on("callback_query", _0x39bad3 => {
  if (_0x39bad3.data === "ownermenu") {
    _0x3f7a03.answerCallbackQuery(_0x39bad3.id);
    const _0x717102 = "━❏「 🌟 Owner Menu 」❏━\n➥ /addprem – Tambah prem\n➥ /addowner – Tambah owner\n➥ /addresellersubdo – Tambah subdomain reseller\n➥ /delprem – Hapus prem\n➥ /delresellersubdo – Hapus subdomain reseller\n➥ /antilink on/off – Atur fitur antilink";
    _0x3f7a03.editMessageCaption(_0x717102, {
      chat_id: _0x39bad3.message.chat.id,
      message_id: _0x39bad3.message.message_id,
      reply_markup: {
        inline_keyboard: [[{
          text: "CEK ID",
          callback_data: "cekid"
        }, {
          text: "CREATE PANEL",
          callback_data: "createpanel"
        }, {
          text: "INSTALL PANEL",
          callback_data: "panelinstall"
        }], [{
          text: "OWNER MENU",
          callback_data: "ownermenu"
        }, {
          text: "TEMA MENU",
          callback_data: "temamenu"
        }, {
          text: "DOWNLOAD MENU",
          callback_data: "downloadmenu"
        }], [{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/FxyyCxx"
        }], [{
          text: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
          url: "https://t.me/boyxzsstarboy"
        }], [{
          text: " Ｂ Ａ Ｃ Ｋ ",
          callback_data: "beck"
        }]]
      }
    });
  }
});
_0x3f7a03.on("callback_query", _0xdb75df => {
  if (_0xdb75df.data === "panelinstall") {
    _0x3f7a03.answerCallbackQuery(_0xdb75df.id);
    const _0x3c8edc = "━❏「 📂 Pterodactyl Installer 」❏━\n➥ /installpanel – Install panel\n➥ /wings – Install wings\n➥ /hackbackpanel – Hack back panel\n➥ /uninstallpanel – Uninstall panel\n➥ /listdomain – Lihat daftar domain";
    _0x3f7a03.editMessageCaption(_0x3c8edc, {
      chat_id: _0xdb75df.message.chat.id,
      message_id: _0xdb75df.message.message_id,
      reply_markup: {
        inline_keyboard: [[{
          text: "CEK ID",
          callback_data: "cekid"
        }, {
          text: "CREATE PANEL",
          callback_data: "createpanel"
        }, {
          text: "INSTALL PANEL",
          callback_data: "panelinstall"
        }], [{
          text: "OWNER MENU",
          callback_data: "ownermenu"
        }, {
          text: "TEMA MENU",
          callback_data: "temamenu"
        }, {
          text: "DOWNLOAD MENU",
          callback_data: "downloadmenu"
        }], [{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }], [{
          text: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
          url: "https://t.me/boyxzsstarboy"
        }], [{
          text: " Ｂ Ａ Ｃ Ｋ ",
          callback_data: "beck"
        }]]
      }
    });
  }
});
_0x3f7a03.on("callback_query", _0x547d50 => {
  if (_0x547d50.data === "temamenu") {
    _0x3f7a03.answerCallbackQuery(_0x547d50.id);
    const _0x5e6fd0 = "━❏「 🎨 Install Tema 」❏━\n➥ /night – Install tema night\n➥ /stellar – Install tema Stellar\n➥ /billing – Install tema Billing\n➥ /elysium – Install tema Elysium\n➥ /enigma – Install tema Enigma\n➥ /uninstalltema – Uninstall tema";
    _0x3f7a03.editMessageCaption(_0x5e6fd0, {
      chat_id: _0x547d50.message.chat.id,
      message_id: _0x547d50.message.message_id,
      reply_markup: {
        inline_keyboard: [[{
          text: "CEK ID",
          callback_data: "cekid"
        }, {
          text: "CREATE PANEL",
          callback_data: "createpanel"
        }, {
          text: "INSTALL PANEL",
          callback_data: "panelinstall"
        }], [{
          text: "OWNER MENU",
          callback_data: "ownermenu"
        }, {
          text: "TEMA MENU",
          callback_data: "temamenu"
        }, {
          text: "DOWNLOAD MENU",
          callback_data: "downloadmenu"
        }], [{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/ellmhtirzx"
        }], [{
          text: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
          url: "https://t.me/boyxzsstarboy"
        }], [{
          text: " Ｂ Ａ Ｃ Ｋ ",
          callback_data: "beck"
        }]]
      }
    });
  }
});
_0x3f7a03.on("callback_query", _0x2dc404 => {
  if (_0x2dc404.data === "cekid") {
    _0x3f7a03.answerCallbackQuery(_0x2dc404.id);
    const _0x59f647 = "━❏「 🛡 Cek Id Menu 」❏━\n➥ /cekid - Melihat id pengguna";
    _0x3f7a03.editMessageCaption(_0x59f647, {
      chat_id: _0x2dc404.message.chat.id,
      message_id: _0x2dc404.message.message_id,
      reply_markup: {
        inline_keyboard: [[{
          text: "CEK ID",
          callback_data: "cekid"
        }, {
          text: "CREATE PANEL",
          callback_data: "createpanel"
        }, {
          text: "INSTALL PANEL",
          callback_data: "panelinstall"
        }], [{
          text: "OWNER MENU",
          callback_data: "ownermenu"
        }, {
          text: "TEMA MENU",
          callback_data: "temamenu"
        }, {
          text: "DOWNLOAD MENU",
          callback_data: "downloadmenu"
        }], [{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }], [{
          text: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
          url: "https://t.me/boyxzsstarboy"
        }], [{
          text: " Ｂ Ａ Ｃ Ｋ ",
          callback_data: "beck"
        }]]
      }
    });
  }
});
_0x3f7a03.on("callback_query", _0x375277 => {
  if (_0x375277.data === "downloadmenu") {
    _0x3f7a03.answerCallbackQuery(_0x375277.id);
    const _0x57bb3a = "━❏「 📥 Download Menu 」❏━\n➥ /tiktok – Download video TikTok\n➥ /play – memutar musik\n➥ /tourl – Konversi Foto ke URL\n➥ /brat – Download lainnya";
    _0x3f7a03.editMessageCaption(_0x57bb3a, {
      chat_id: _0x375277.message.chat.id,
      message_id: _0x375277.message.message_id,
      reply_markup: {
        inline_keyboard: [[{
          text: "CEK ID",
          callback_data: "cekid"
        }, {
          text: "CREATE PANEL",
          callback_data: "createpanel"
        }, {
          text: "INSTALL PANEL",
          callback_data: "panelinstall"
        }], [{
          text: "OWNER MENU",
          callback_data: "ownermenu"
        }, {
          text: "TEMA MENU",
          callback_data: "temamenu"
        }, {
          text: "DOWNLOAD MENU",
          callback_data: "downloadmenu"
        }], [{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }], [{
          text: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
          url: "https://t.me/boyxzsstarboy"
        }], [{
          text: " Ｂ Ａ Ｃ Ｋ ",
          callback_data: "beck"
        }]]
      }
    });
  }
});
_0x3f7a03.onText(/\/addprem (.+)/, (_0x481b4d, _0x4c4982) => {
  const _0x523d91 = _0x481b4d.chat.id;
  const _0xfc58a9 = _0x4c4982[1];
  if (_0x481b4d.from.id.toString() === _0x1823e6) {
    if (!premiumUsers.includes(_0xfc58a9)) {
      premiumUsers.push(_0xfc58a9);
      _0x2230b1.writeFileSync(_0x734f29, JSON.stringify(premiumUsers));
      _0x3f7a03.sendMessage(_0x523d91, "User " + _0xfc58a9 + " telah ditambahkan ke daftar premium.");
    } else {
      _0x3f7a03.sendMessage(_0x523d91, "User " + _0xfc58a9 + " sudah termasuk pengguna premium.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x523d91, "Hanya pemilik bot yang dapat melakukan tindakan ini.");
  }
});
_0x3f7a03.onText(/\/addprem2 (.+)/, (_0x450fff, _0x433658) => {
  const _0x486dd5 = _0x450fff.chat.id;
  const _0x60c9ab = _0x433658[1];
  if (_0x450fff.from.id.toString() === _0x1823e6) {
    if (!premiumUsers2.includes(_0x60c9ab)) {
      premiumUsers2.push(_0x60c9ab);
      _0x2230b1.writeFileSync(_0xc4d1de, JSON.stringify(premiumUsers2));
      _0x3f7a03.sendMessage(_0x486dd5, "User " + _0x60c9ab + " telah ditambahkan ke daftar premium2.");
    } else {
      _0x3f7a03.sendMessage(_0x486dd5, "User " + _0x60c9ab + " sudah termasuk pengguna premium2.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x486dd5, "Hanya pemilik bot yang dapat melakukan tindakan ini.");
  }
});
_0x3f7a03.on("callback_query", _0x338f79 => {
  if (_0x338f79.data === "beck") {
    _0x3f7a03.answerCallbackQuery(_0x338f79.id);
    const _0xd5f174 = "hello I'm a Bot Create Panel special group — Discusicon dis Who is ready, helps with any problem\n\n╭── ⋅ ⋅ ── ⋅ ⋅ ─── ⋅ ⋅ ── ─ ⋅ ⋅ ── \n |  ⎋ Developer : @XxzFallOffc\n | ⎋ Version : 3.0.0\n╰── ⋅ ⋅ ──── ⋅ ⋅ ──── ⋅ ⋅ ────\n  𝗣𝗶𝗹𝗶𝗵 𝗠𝗲𝗻𝘂 𝗕𝘂𝘁𝘁𝗼𝗻 𝗗𝗶 𝗯𝗮𝘄𝗮𝗵 ";
    _0x3f7a03.editMessageCaption(_0xd5f174, {
      chat_id: _0x338f79.message.chat.id,
      message_id: _0x338f79.message.message_id,
      reply_markup: {
        inline_keyboard: [[{
          text: "CEK ID",
          callback_data: "cekid"
        }, {
          text: "CREATE PANEL",
          callback_data: "createpanel"
        }, {
          text: "INSTALL PANEL",
          callback_data: "panelinstall"
        }], [{
          text: "OWNER MENU",
          callback_data: "ownermenu"
        }, {
          text: "TEMA MENU",
          callback_data: "temamenu"
        }, {
          text: "DOWNLOAD MENU",
          callback_data: "downloadmenu"
        }], [{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }], [{
          text: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
          url: "https://t.me/boyxzsstarboy"
        }]]
      }
    });
  }
});
_0x3f7a03.onText(/\/delprem (.+)/, (_0x37d8b0, _0x4c3ec5) => {
  const _0x2c8770 = _0x37d8b0.chat.id;
  const _0x54c47c = _0x4c3ec5[1];
  if (_0x37d8b0.from.id.toString() === _0x1823e6) {
    const _0x4d6418 = premiumUsers.indexOf(_0x54c47c);
    if (_0x4d6418 !== -1) {
      premiumUsers.splice(_0x4d6418, 1);
      _0x2230b1.writeFileSync(_0x734f29, JSON.stringify(premiumUsers));
      _0x3f7a03.sendMessage(_0x2c8770, "User " + _0x54c47c + " telah dihapus dari daftar premium.");
    } else {
      _0x3f7a03.sendMessage(_0x2c8770, "User " + _0x54c47c + " bukan pengguna premium.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x2c8770, "Hanya pemilik bot yang dapat melakukan tindakan ini.");
  }
});
_0x3f7a03.onText(/\/addowner (.+)/, (_0x274c6f, _0x35f526) => {
  const _0x841e0a = _0x274c6f.chat.id;
  const _0x27733b = _0x35f526[1];
  if (_0x274c6f.from.id.toString() === _0x1823e6) {
    if (!adminUsers.includes(_0x27733b)) {
      adminUsers.push(_0x27733b);
      _0x2230b1.writeFileSync(_0x187e45, JSON.stringify(adminUsers));
      _0x3f7a03.sendMessage(_0x841e0a, "User " + _0x27733b + " telah ditambahkan sebagai admin.");
    } else {
      _0x3f7a03.sendMessage(_0x841e0a, "User " + _0x27733b + " sudah menjadi admin.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x841e0a, "Hanya pemilik bot yang dapat melakukan tindakan ini.");
  }
});
_0x3f7a03.onText(/\/listsrv/, async _0x109091 => {
  const _0x4981d0 = _0x109091.chat.id;
  const _0x583eb0 = _0x109091.from.id;
  const _0x34acb3 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x2ad741 = _0x34acb3.includes(String(_0x109091.from.id));
  if (!_0x2ad741) {
    _0x3f7a03.sendMessage(_0x4981d0, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  let _0x2fb4b7 = 1;
  try {
    let _0x2d9981 = await fetch(_0xb62ec7 + "/api/application/servers?page=" + _0x2fb4b7, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      }
    });
    let _0x2a0c13 = await _0x2d9981.json();
    let _0x5d8a3c = _0x2a0c13.data;
    let _0x3baae7 = "Daftar server aktif yang dimiliki:\n\n";
    for (let _0x4d712a of _0x5d8a3c) {
      let _0x2ca8d3 = _0x4d712a.attributes;
      let _0x4e89ca = await fetch(_0xb62ec7 + "/api/client/servers/" + _0x2ca8d3.uuid.split("-")[0] + "/resources", {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + _0x40f116
        }
      });
      let _0x257590 = await _0x4e89ca.json();
      let _0x26db3a = _0x257590.attributes ? _0x257590.attributes.current_state : _0x2ca8d3.status;
      _0x3baae7 += "ID Server: " + _0x2ca8d3.id + "\n";
      _0x3baae7 += "Nama Server: " + _0x2ca8d3.name + "\n";
      _0x3baae7 += "Status: " + _0x26db3a + "\n\n";
    }
    _0x3f7a03.sendMessage(_0x4981d0, _0x3baae7);
  } catch (_0x410291) {
    console.error(_0x410291);
    _0x3f7a03.sendMessage(_0x4981d0, "Terjadi kesalahan dalam memproses permintaan.");
  }
});
_0x3f7a03.onText(/\/listusr/, async _0x91eeb1 => {
  const _0x59455d = _0x91eeb1.chat.id;
  const _0x287717 = _0x91eeb1.from.id;
  const _0x1a00ea = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x1b1d1 = _0x1a00ea.includes(String(_0x91eeb1.from.id));
  if (!_0x1b1d1) {
    _0x3f7a03.sendMessage(_0x59455d, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  let _0x43b4bf = "1";
  try {
    let _0x14e147 = await fetch(_0xb62ec7 + "/api/application/users?page=" + _0x43b4bf, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      }
    });
    let _0x37f4cc = await _0x14e147.json();
    let _0x10b8a8 = _0x37f4cc.data;
    let _0x1f9caa = "Berikut daftar users aktif yang dimiliki :\n\n";
    for (let _0x782303 of _0x10b8a8) {
      let _0x4ef348 = _0x782303.attributes;
      _0x1f9caa += "\nID Users: " + _0x4ef348.id;
      _0x1f9caa += "\nName Users: " + _0x4ef348.username;
    }
    _0x1f9caa += "\nPage : " + _0x37f4cc.meta.pagination.current_page + "/" + _0x37f4cc.meta.pagination.total_pages + "\n";
    _0x1f9caa += "Total User : " + _0x37f4cc.meta.pagination.count;
    _0x3f7a03.sendMessage(_0x59455d, _0x1f9caa);
  } catch (_0x219280) {
    console.error(_0x219280);
    _0x3f7a03.sendMessage(_0x59455d, "Terjadi kesalahan dalam memproses permintaan.");
  }
});
_0x3f7a03.onText(/^(\.|\#|\/)delsrv$/, async _0x39d238 => {
  const _0x142999 = _0x39d238.chat.id;
  _0x3f7a03.sendMessage(_0x142999, "Format salah example delsrv id");
});
_0x3f7a03.onText(/\/delsrv (.+)/, async (_0x2f9a14, _0x59ded8) => {
  const _0x5319f7 = _0x2f9a14.chat.id;
  const _0x3f701a = _0x59ded8[1].trim();
  const _0x4e2d21 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x293af1 = _0x4e2d21.includes(String(_0x2f9a14.from.id));
  if (!_0x293af1) {
    _0x3f7a03.sendMessage(_0x5319f7, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  if (!_0x3f701a) {
    _0x3f7a03.sendMessage(_0x5319f7, "Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv 1234");
    return;
  }
  try {
    let _0x4b4c12 = await fetch(_0xb62ec7 + "/api/application/servers/" + _0x3f701a, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      }
    });
    let _0x53782f = _0x4b4c12.ok ? {
      errors: null
    } : await _0x4b4c12.json();
    if (_0x53782f.errors) {
      _0x3f7a03.sendMessage(_0x5319f7, "SERVER TIDAK ADA");
    } else {
      _0x3f7a03.sendMessage(_0x5319f7, "SUCCESFULLY DELETE SERVER");
    }
  } catch (_0x5e567f) {
    console.error(_0x5e567f);
    _0x3f7a03.sendMessage(_0x5319f7, "Terjadi kesalahan saat menghapus server.");
  }
});
_0x3f7a03.onText(/^(\.|\#|\/)deluser$/, async _0x4d98ad => {
  const _0xfdc65 = _0x4d98ad.chat.id;
  _0x3f7a03.sendMessage(_0xfdc65, "Format salah example delusr id yang akan di hapus");
});
_0x3f7a03.onText(/\/delusr(.*)/, async (_0x499f6a, _0x145320) => {
  const _0x3478c1 = _0x499f6a.chat.id;
  const _0x29e6aa = _0x145320[1].trim();
  const _0x486cad = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0xf1644b = _0x486cad.includes(String(_0x499f6a.from.id));
  if (!_0xf1644b) {
    _0x3f7a03.sendMessage(_0x3478c1, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  if (!_0x29e6aa) {
    _0x3f7a03.sendMessage(_0x3478c1, "Mohon masukkan ID server yang ingin dihapus, contoh: /delusr 1");
    return;
  }
  try {
    let _0x5d8236 = await fetch(_0xb62ec7 + "/api/application/users/" + _0x29e6aa, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      }
    });
    let _0x428cc7 = _0x5d8236.ok ? {
      errors: null
    } : await _0x5d8236.json();
    if (_0x428cc7.errors) {
      _0x3f7a03.sendMessage(_0x3478c1, "USER NOT FOUND");
    } else {
      _0x3f7a03.sendMessage(_0x3478c1, "SUCCESSFULLY DELETE THE USER");
    }
  } catch (_0xabc24) {
    console.error(_0xabc24);
    _0x3f7a03.sendMessage(_0x3478c1, "Terjadi kesalahan saat menghapus server.");
  }
});
_0x3f7a03.onText(/\/delowner (.+)/, (_0x3e8310, _0x1a6796) => {
  const _0x1d2710 = _0x3e8310.chat.id;
  const _0xae421b = _0x1a6796[1];
  if (_0x3e8310.from.id.toString() === _0x1823e6) {
    const _0xf3a115 = adminUsers.indexOf(_0xae421b);
    if (_0xf3a115 !== -1) {
      adminUsers.splice(_0xf3a115, 1);
      _0x2230b1.writeFileSync(_0x187e45, JSON.stringify(adminUsers));
      _0x3f7a03.sendMessage(_0x1d2710, "User " + _0xae421b + " telah dihapus sebagai admin.");
    } else {
      _0x3f7a03.sendMessage(_0x1d2710, "User " + _0xae421b + " bukan seorang admin.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x1d2710, "Hanya pemilik bot yang dapat melakukan tindakan ini.");
  }
});
_0x3f7a03.onText(/^(\.|\#|\/)buyadpp$/, async _0x2b09d5 => {
  const _0x17d3d8 = _0x2b09d5.chat.id;
  _0x3f7a03.sendMessage(_0x17d3d8, "Format salah example /buyadp nama");
});
_0x3f7a03.onText(/\/buyadpp (.+)/, async (_0x4815ea, _0x462557) => {
  const _0x2d7a66 = _0x4815ea.chat.id;
  if (_0x4815ea.chat.type !== "private") {
    return _0x3f7a03.sendMessage(_0x2d7a66, "Pembelian panel hanya bisa dilakukan melalui private chat.");
  }
  const _0x20bb55 = _0x462557[1];
  if (!_0x20bb55) {
    return _0x3f7a03.sendMessage(_0x2d7a66, "Harap masukkan username.\nContoh: /buyadpp <username>");
  }
  if (_0x20bb55.includes(" ")) {
    return _0x3f7a03.sendMessage(_0x2d7a66, "Username tidak boleh mengandung spasi!");
  }
  const _0x26f9c1 = _0x4815ea.from.id;
  if (_0x2f1450[_0x26f9c1]?.active) {
    return _0x3f7a03.sendMessage(_0x2d7a66, "Masih ada transaksi yang belum selesai! Ketik /cancel untuk membatalkan.");
  }
  const _0x3f5a80 = _0x63ed5f;
  const _0x1a9f16 = 100;
  const _0x1894bf = _0x20bb55;
  try {
    const _0x492407 = await _0x1063a4.get("https://api.skyzopedia.us.kg/api/orkut/createpayment?apikey=admin&amount=" + _0x1a9f16 + "&codeqr=" + _0x3f5a80);
    const _0xbb1095 = _0x492407.data.result;
    if (!_0xbb1095 || !_0xbb1095.transactionId) {
      console.error("Invalid payment response:", _0x492407.data);
      return _0x3f7a03.sendMessage(_0x2d7a66, "Terjadi kesalahan: Transaksi tidak valid.");
    }
    _0x2f1450[_0x26f9c1] = {
      active: true,
      transactionId: _0xbb1095.transactionId,
      amount: _0xbb1095.amount,
      username: _0x1894bf,
      qrImageUrl: _0xbb1095.qrImageUrl,
      expiration: Date.now() + 300000
    };
    await _0x3f7a03.sendPhoto(_0x2d7a66, _0xbb1095.qrImageUrl, {
      caption: ("\n📢 *Informasi Pembayaran Anda:*\n\n✨ ID Transaksi: " + _0xbb1095.transactionId + "\n💳 Total Pembayaran: Rp" + _0xbb1095.amount + "\n🛒 Barang: Admin Panel Pterodactyl (Username: " + _0x1894bf + ")\n⏳ Batas Waktu Pembayaran: 5 Menit\n\n🔔 *Catatan*: Setelah pembayaran berhasil, Anda akan menerima notifikasi secara otomatis dari bot kami.\n\n❌ Jika ingin membatalkan transaksi, ketik /cancel.\n\n🚀 Jangan tunggu lama, selesaikan pembayaran Anda sekarang!").replace(/_/g, "\\_").replace(/\*/g, "\\*"),
      parse_mode: "Markdown"
    });
    const _0x27ce73 = setInterval(async () => {
      const _0x4ebec8 = await _0x1063a4.get("https://api.skyzopedia.us.kg/api/orkut/cekstatus?apikey=admin&merchant=" + _0x3ea3bf + "&keyorkut=" + _0x3aea56);
      const _0x4de6e8 = _0x4ebec8.data;
      if (_0x4de6e8.amount === _0x2f1450[_0x26f9c1].amount) {
        clearInterval(_0x27ce73);
        const _0x49d996 = _0x1894bf + "@gmail.com";
        const _0x424fe9 = "lexcz123";
        const _0x3619dc = await _0x1063a4.post(_0xb62ec7 + "/api/application/users", {
          email: _0x49d996,
          username: _0x1894bf,
          first_name: _0x1894bf,
          last_name: "Admin",
          root_admin: true,
          language: "en",
          password: _0x424fe9
        }, {
          headers: {
            Authorization: "Bearer " + _0x5a238b
          }
        });
        const _0x7159ad = _0x3619dc.data.attributes;
        _0x3f7a03.sendMessage(_0x2d7a66, "\n🎉 Pembayaran Berhasil! 🎉\n\n📌 DETAIL AKUN ADMIN PANEL ANDA:\n\nID User: " + _0x7159ad.id + "\n\nNama: " + _0x7159ad.first_name + "\nUsername: " + _0x7159ad.username + "\nPassword: " + _0x424fe9 + "\nLogin: " + _0xb62ec7 + "\n\nMasa Aktif: 1 bulan\n\n\n💡 Pastikan Anda menyimpan data ini dengan aman!\nTerima kasih telah menggunakan layanan kami!\n*Rules Admin Panel ⚠️*\n* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!\n* Simpan Baik² Data Akun Ini\n* Buat Panel Seperlunya Aja, Jangan Asal Buat!\n* Garansi Aktif 10 Hari\n* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian.");
        delete _0x2f1450[_0x26f9c1];
      }
    }, 8000);
    setTimeout(() => {
      if (_0x2f1450[_0x26f9c1]?.active) {
        clearInterval(_0x27ce73);
        _0x3f7a03.sendMessage(_0x2d7a66, "QRIS pembayaran telah expired!");
        delete _0x2f1450[_0x26f9c1];
      }
    }, 300000);
  } catch (_0x55823a) {
    console.error(_0x55823a);
    _0x3f7a03.sendMessage(_0x2d7a66, "Terjadi kesalahan saat memproses pembayaran.");
  }
});
_0x3f7a03.onText(/^(\.|\#|\/)installpanel$/, async _0x4df8f0 => {
  const _0x5dfbf1 = _0x4df8f0.chat.id;
  _0x3f7a03.sendMessage(_0x5dfbf1, "𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹1 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱𝘃𝗽𝘀,𝗱𝗼𝗺𝗮𝗶𝗻𝗽𝗻𝗹,𝗱𝗼𝗺𝗮𝗶𝗻𝗻𝗼𝗱𝗲,𝟭𝟲𝟬𝟬𝟬𝟬𝟬𝟬");
});
_0x3f7a03.onText(/\/installpanel1 (.+)/, async (_0xa68bce, _0xd665d6) => {
  const _0x425c39 = _0xa68bce.chat.id;
  const _0x26ea49 = _0xd665d6[1];
  const _0x30a025 = _0x26ea49.split(",");
  if (_0x30a025.length < 3) {
    return _0x3f7a03.sendMessage(_0x425c39, "𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹1 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱𝘃𝗽𝘀,𝗱𝗼𝗺𝗮𝗶𝗻𝗽𝗻𝗹,𝗱𝗼𝗺𝗮𝗶𝗻𝗻𝗼𝗱𝗲,𝗿𝗮𝗺𝘃𝗽𝘀 ( ᴄᴏɴᴛᴏʜ : 𝟾𝟶𝟶𝟶 = ʀᴀᴍ 𝟾");
  }
  const _0x3fb862 = _0x30a025[0];
  const _0x38c1cc = _0x30a025[1];
  const _0x1ddc76 = _0x30a025[2];
  const _0x3e5e5d = _0x30a025[3];
  const _0x29a6c1 = _0x30a025[4];
  const _0x2ef75e = {
    host: _0x3fb862,
    port: 22,
    username: "root",
    password: _0x38c1cc
  };
  const _0x584d22 = _0x51f680();
  const _0x106dd7 = "bash <(curl -s https://pterodactyl-installer.se)";
  const _0x3d1070 = "bash <(curl -s https://pterodactyl-installer.se)";
  const _0x2fe5d7 = new _0x241de6();
  _0x2fe5d7.on("ready", () => {
    _0x3f7a03.sendMessage(_0x425c39, "𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗦𝗘𝗗𝗔𝗡𝗚 𝗕𝗘𝗥𝗟𝗔𝗡𝗚𝗦𝗨𝗡𝗚 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝟱-𝟭𝟬𝗠𝗘𝗡𝗜𝗧");
    _0x2fe5d7.exec(_0x106dd7, (_0x3610e1, _0xe889f1) => {
      if (_0x3610e1) {
        _0x3f7a03.sendMessage(_0x425c39, "𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗻𝗷𝗮𝗹𝗮𝗻𝗸𝗮𝗻 𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗶𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶.");
        _0x2fe5d7.end();
        return;
      }
      _0xe889f1.on("close", (_0x330ae7, _0x3d7184) => {
        console.log("Stream closed with code " + _0x330ae7 + " and signal " + _0x3d7184);
        _0x2614f1(_0x2fe5d7, _0x3e5e5d, _0x1ddc76, _0x584d22, _0x29a6c1);
      }).on("data", _0x2f12f4 => {
        _0x6e8f02(_0x2f12f4, _0xe889f1, _0x1ddc76, _0x584d22);
      }).stderr.on("data", _0x53fb3e => {
        console.log("STDERR: " + _0x53fb3e);
      });
    });
  }).on("error", _0x5d87d3 => {
    if (_0x5d87d3.message.includes("All configured authentication methods failed")) {
      _0x3f7a03.sendMessage(_0x425c39, "Koneksi gagal: Kata sandi salah atau VPS tidak dapat diakses.");
    } else if (_0x5d87d3.message.includes("connect ECONNREFUSED")) {
      _0x3f7a03.sendMessage(_0x425c39, "Koneksi gagal: VPS tidak bisa diakses atau mati.");
    } else {
      _0x3f7a03.sendMessage(_0x425c39, "Koneksi gagal: " + _0x5d87d3.message);
    }
    console.error("Connection Error: ", _0x5d87d3.message);
  }).connect(_0x2ef75e);
  async function _0x2614f1(_0x50dddd, _0x15f38e, _0x5f55ce, _0x28da4c, _0x18e59a) {
    _0x3f7a03.sendMessage(_0x425c39, "𝗣𝗥𝗢𝗦𝗘𝗦 𝗣𝗘𝗡𝗚𝗜𝗡𝗦𝗧𝗔𝗟𝗟𝗔𝗡 𝗪𝗜𝗡𝗚𝗦 𝗦𝗘𝗗𝗔𝗡𝗚 𝗕𝗘𝗥𝗟𝗔𝗡𝗚𝗦𝗨𝗡𝗚 𝗠𝗢𝗛𝗢𝗡 𝗧𝗨𝗡𝗚𝗚𝗨 𝟱 𝗠𝗘𝗡𝗜𝗧");
    _0x50dddd.exec(_0x3d1070, (_0x460440, _0x2737d7) => {
      if (_0x460440) {
        _0x3f7a03.sendMessage(_0x425c39, "𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗻𝗷𝗮𝗹𝗮𝗻𝗸𝗮𝗻 𝗽𝗲𝗿𝗶𝗻𝘁𝗮𝗵 𝗶𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶 𝘄𝗶𝗻𝗴𝘀.");
        _0x50dddd.end();
        return;
      }
      _0x2737d7.on("close", (_0x16c1cd, _0x2e7b49) => {
        console.log("Wings installation stream closed with code " + _0x16c1cd + " and signal " + _0x2e7b49);
        _0x5ccad9(_0x50dddd, _0x15f38e, _0x18e59a, _0x5f55ce, _0x28da4c);
      }).on("data", _0x2dca1b => {
        _0x1d9706(_0x2dca1b, _0x2737d7, _0x15f38e, _0x5f55ce);
      }).stderr.on("data", _0x1f0096 => {
        console.log("STDERR: " + _0x1f0096);
      });
    });
  }
  async function _0x5ccad9(_0x4b489e, _0x240f13, _0x524ef1, _0x3973e2, _0x4e54f2) {
    const _0x7f99f4 = "bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/Installerlex/refs/heads/main/install.sh)";
    _0x3f7a03.sendMessage(_0x425c39, "𝗠𝗘𝗠𝗨𝗟𝗔𝗜 𝗖𝗥𝗘𝗔𝗧𝗘 𝗡𝗢𝗗𝗘 & 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡");
    _0x4b489e.exec(_0x7f99f4, (_0x41f83f, _0x45a629) => {
      if (_0x41f83f) {
        _0x3f7a03.sendMessage(_0x425c39, "𝗧𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝘀𝗮𝗹𝗮𝗵𝗮𝗻 𝘀𝗮𝗮𝘁 𝗺𝗲𝗺𝗯𝘂𝗮𝘁 𝗻𝗼𝗱𝗲.");
        _0x4b489e.end();
        return;
      }
      _0x45a629.on("close", (_0x40c9ce, _0x19a4ff) => {
        console.log("Node creation stream closed with code " + _0x40c9ce + " and " + _0x19a4ff + " signal");
        _0x4b489e.end();
        _0x3e24d8(_0x3973e2);
      }).on("data", _0x4a92c6 => {
        _0x12b22c(_0x4a92c6, _0x45a629, _0x240f13, _0x524ef1);
      }).stderr.on("data", _0x2d6c55 => {
        console.log("STDERR: " + _0x2d6c55);
      });
    });
  }
  function _0x3e24d8(_0x48eeed) {
    _0x3f7a03.sendMessage(_0x425c39, "𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n\n𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘: 𝗿𝗲𝘅𝘅𝗮\n𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗: 𝗿𝗲𝘅𝘅𝗮\n𝗟𝗢𝗚𝗜𝗡: " + _0x48eeed + "\n\n𝗡𝗼𝘁𝗲: 𝗦𝗲𝗺𝘂𝗮 𝗜𝗻𝘀𝘁𝗮𝗹𝗮𝘀𝗶 𝗧𝗲𝗹𝗮𝗵 𝗦𝗲𝗹𝗲𝘀𝗮𝗶. 𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗰𝗿𝗲𝗮𝘁𝗲 𝗮𝗹𝗹𝗼𝗰𝗮𝘁𝗶𝗼𝗻 𝗱𝗶 𝗻𝗼𝗱𝗲 𝘆𝗮𝗻𝗴 𝗱𝗶𝗯𝘂𝗮𝘁 𝗼𝗹𝗲𝗵 𝗯𝗼𝘁 𝗱𝗮𝗻 𝗮𝗺𝗯𝗶𝗹 𝘁𝗼𝗸𝗲𝗻 𝗸𝗼𝗻𝗳𝗶𝗴𝘂𝗿𝗮𝘀𝗶, 𝗹𝗮𝗹𝘂 𝗸𝗲𝘁𝗶𝗸 /𝘄𝗶𝗻𝗴𝘀 𝗶𝗽𝘃𝗽𝘀,𝗽𝘄𝘃𝗽𝘀,(𝘁𝗼𝗸𝗲𝗻). \n𝗡𝗼𝘁𝗲: 𝗛𝗮𝗿𝗮𝗽 𝘁𝘂𝗻𝗴𝗴𝘂 𝟭-𝟱 𝗺𝗲𝗻𝗶𝘁 𝗮𝗴𝗮𝗿 𝘄𝗲𝗯 𝗯𝗶𝘀𝗮 𝗱𝗶𝗮𝗸𝘀𝗲𝘀.");
  }
  function _0x6e8f02(_0x16271d, _0x277283, _0x143bae, _0xd98a27) {
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("0\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write(_0xd98a27 + "\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write(_0xd98a27 + "\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write(_0xd98a27 + "\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("Asia/Jakarta\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("fxyyoffc@gmail.com\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("fxyyoffc@gmail.com\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("fxyy\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("fxyy\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("fxyy\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("fxyy\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write(_0x143bae + "\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("y\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("y\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("y\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("y\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("yes\n");
    }
    if (_0x16271d.toString().includes("Please read the Terms of Service")) {
      _0x277283.write("Y\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("\n");
    }
    if (_0x16271d.toString().includes("Input")) {
      _0x277283.write("1\n");
    }
    console.log("STDOUT: " + _0x16271d);
  }
  function _0x1d9706(_0xda8a5c, _0x4e6db7, _0x2f31d1, _0x513511) {
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("1\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("y\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("y\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("y\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write(_0x513511 + "\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("y\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write(_0x584d22 + "\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write(_0x584d22 + "\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("y\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write(_0x2f31d1 + "\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("y\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("fxyyoffc@gmail.com\n");
    }
    if (_0xda8a5c.toString().includes("Input")) {
      _0x4e6db7.write("y\n");
    }
    console.log("STDOUT: " + _0xda8a5c);
  }
  function _0x12b22c(_0x475822, _0x10540b, _0x3d0f07, _0xb53fa7) {
    _0x10540b.write("4\n");
    _0x10540b.write("ReXcZ\n");
    _0x10540b.write("ReXcZ\n");
    _0x10540b.write(_0x3d0f07 + "\n");
    _0x10540b.write("ReXcZ\n");
    _0x10540b.write(_0xb53fa7 + "\n");
    _0x10540b.write(_0xb53fa7 + "\n");
    _0x10540b.write("1\n");
    console.log("STDOUT: " + _0x475822);
  }
});
_0x3f7a03.onText(/^(\.|\#|\/)wings$/, async _0x5aabbd => {
  const _0x3233fe = _0x5aabbd.chat.id;
  _0x3f7a03.sendMessage(_0x3233fe, "Formt salah !\nPenggunaan: /wings ipvps,password,token");
});
_0x3f7a03.onText(/\/wings (.+)/, async (_0xeb0f3f, _0x27cfc2) => {
  const _0x1f84ce = _0xeb0f3f.chat.id;
  const _0x222eb5 = _0x27cfc2[1];
  const _0x442883 = _0x222eb5.split(",");
  if (_0x442883.length < 3) {
    return _0x3f7a03.sendMessage(_0x1f84ce, "Format salah!\nPenggunaam: /startwings ipvps, passwordvps,token");
  }
  const _0x1d3a82 = _0x442883[0];
  const _0x5cbea4 = _0x442883[1];
  const _0x4fe5fe = _0x442883[2];
  const _0x5500c2 = {
    host: _0x1d3a82,
    port: 22,
    username: "root",
    password: _0x5cbea4
  };
  const _0x1f7fc7 = new _0x241de6();
  const _0xa11ef8 = "bash <(curl -s https://raw.githubusercontent.com/sevsbotz/sevsrawr/refs/heads/main/install.sh)";
  _0x1f7fc7.on("ready", () => {
    isSuccess = true;
    _0x3f7a03.sendMessage(_0x1f84ce, " PROSES STARTWINGS");
    _0x1f7fc7.exec(_0xa11ef8, (_0x1e6812, _0x2e1919) => {
      if (_0x1e6812) {
        throw _0x1e6812;
      }
      _0x2e1919.on("close", (_0x393946, _0x22e6c5) => {
        console.log("Stream closed with code ${code} and ${signal} signal");
        _0x3f7a03.sendMessage(_0x1f84ce, "success startwings");
        _0x1f7fc7.end();
      }).on("data", _0x200c11 => {
        _0x2e1919.write("3\n");
        _0x2e1919.write(_0x4fe5fe + "\n");
        console.log("STDOUT: " + _0x200c11);
      }).stderr.on("data", _0x11b9f1 => {
        console.log("STDERR: " + _0x11b9f1);
      });
    });
  }).on("error", _0x464783 => {
    console.log("Connection Error: " + _0x464783);
    _0x3f7a03.sendMessage(_0x1f84ce, "Katasandi atau IP tidak valid");
  }).connect(_0x5500c2);
});
_0x3f7a03.onText(/\/cekid/, _0x4790c => {
  const _0x418bf9 = _0x4790c.chat.id;
  const _0x5db98a = _0x4790c.from.username;
  const _0x3daf3c = _0x4790c.from.id;
  const _0x41f3dc = "6371879956";
  const _0x559b6b = "Hai Sayangkuu @" + _0x5db98a + " 👋\n\n👤 hari? " + _0x3daf3c + "\n\n  └🙋🏽 kamuu\n\n Nih id tele lu : " + _0x3daf3c + "\n Nih nama tele lu : @" + _0x5db98a + "\n\n\n Developer : @XxzFallOffc";
  const _0x2895a7 = {
    reply_markup: {
      inline_keyboard: [[{
        text: "fxyy",
        url: "https://t.me/fxyycxx"
      }, {
        text: "-",
        url: "https://t.me/fxyycxx"
      }], [{
        text: "-",
        url: "https://t.me/fxyycxx"
      }]]
    }
  };
  _0x3f7a03.sendPhoto(_0x418bf9, _0x12cc77.pp, {
    caption: _0x559b6b,
    parse_mode: "Markdown",
    reply_markup: _0x2895a7
  });
});
_0x3f7a03.onText(/^(\.|\#|\/)uninstallpanel$/, async _0x107ca4 => {
  const _0x50d9dd = _0x107ca4.chat.id;
  _0x3f7a03.sendMessage(_0x50d9dd, "𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝘂𝗻𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱");
});
_0x3f7a03.onText(/\/uninstallpanel (.+)/, async (_0x193769, _0x58c715) => {
  const _0x4b8c5a = _0x193769.chat.id;
  const _0x5e5596 = _0x58c715[1];
  const _0x40d0df = _0x5e5596.split(",");
  if (_0x40d0df.length < 2) {
    return _0x3f7a03.sendMessage(_0x4b8c5a, "𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /𝘂𝗻𝗶𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱");
  }
  const _0x5d4b81 = _0x40d0df[0];
  const _0x4e11c9 = _0x40d0df[1];
  const _0x28f779 = {
    host: _0x5d4b81,
    port: 22,
    username: "root",
    password: _0x4e11c9
  };
  const _0x1b5ea8 = new _0x241de6();
  const _0x55269f = "bash <(curl -s https://pterodactyl-installer.se)";
  _0x1b5ea8.on("ready", () => {
    isSuccess = true;
    _0x3f7a03.sendMessage(_0x4b8c5a, "PROSES UNINSTALL PTERODACTYL");
    _0x1b5ea8.exec(_0x55269f, (_0x559d04, _0x126993) => {
      if (_0x559d04) {
        throw _0x559d04;
      }
      _0x126993.on("close", (_0x2c69a3, _0xeb5846) => {
        console.log("Stream closed with code ${code} and ${signal} signal");
        _0x3f7a03.sendMessage(_0x4b8c5a, "𝗦𝗨𝗖𝗖𝗘𝗦 𝗨𝗡𝗜𝗡𝗦𝗧𝗔𝗟𝗟 𝗣𝗧𝗘𝗥𝗢𝗗𝗔𝗖𝗧𝗬𝗟");
        _0x1b5ea8.end();
      }).on("data", _0x182f16 => {
        _0x126993.write("6\n");
        _0x126993.write("y\n");
        _0x126993.write("y\n");
        _0x126993.write("y\n");
        _0x126993.write("y\n");
        _0x126993.write("\n");
        _0x126993.write("\n");
        console.log("STDOUT: " + _0x182f16);
      }).stderr.on("data", _0x4acad7 => {
        console.log("STDERR: " + _0x4acad7);
      });
    });
  }).on("error", _0x455bc9 => {
    console.log("Connection Error: " + _0x455bc9);
    _0x3f7a03.sendMessage(_0x4b8c5a, "Katasandi atau IP tidak valid");
  }).connect(_0x28f779);
});
_0x3f7a03.onText(/^(\.|\#|\/)uninstalltema$/, async _0x1417dc => {
  const _0x25b2e2 = _0x1417dc.chat.id;
  _0x3f7a03.sendMessage(_0x25b2e2, "Format salah!\nPenggunaan: /uninstalltheme ipvps,password");
});
_0x3f7a03.onText(/\/uninstalltema (.+)/, (_0x39f248, _0x56402e) => {
  const _0x53ce4e = _0x39f248.chat.id;
  const _0xe78677 = _0x56402e[1];
  let _0x2ebf57 = _0xe78677.split(",");
  if (_0x2ebf57.length < 2) {
    return _0x3f7a03.sendMessage(_0x53ce4e, "Format salah!\nPenggunaan: /uninstalltheme ipvps,password");
  }
  let _0x2fa189 = _0x2ebf57[0];
  let _0x1e3e84 = _0x2ebf57[1];
  const _0x474618 = {
    host: _0x2fa189,
    port: "22",
    username: "root",
    password: _0x1e3e84
  };
  const _0x126359 = "bash <(curl -s https://raw.githubusercontent.com/sevsbotz/sevsrawr/refs/heads/main/install.sh)";
  const _0x448d3c = new _0x241de6();
  let _0x435860 = false;
  _0x448d3c.on("ready", () => {
    _0x435860 = true;
    _0x3f7a03.sendMessage(_0x53ce4e, "PROSES UNINSTALL TEMA DIMULAI MOHON TUNGGU 2-5 MENIT KEDEPAN");
    _0x448d3c.exec(_0x126359, (_0x258b8c, _0x2e5353) => {
      if (_0x258b8c) {
        throw _0x258b8c;
      }
      _0x2e5353.on("close", (_0x1cfe47, _0x2779dd) => {
        console.log("Stream closed with code " + _0x1cfe47 + " and signal " + _0x2779dd);
        _0x3f7a03.sendMessage(_0x53ce4e, "`SUKSES UNINSTALL THEME PANEL ANDA, SILAHKAN CEK WEB PANEL ANDA`");
        _0x448d3c.end();
      }).on("data", _0x286370 => {
        _0x2e5353.write("2\n");
        _0x2e5353.write("yes\n");
        console.log("STDOUT: " + _0x286370);
      }).stderr.on("data", _0x1ed5a5 => {
        console.log("STDERR: " + _0x1ed5a5);
      });
    });
  }).on("error", _0xae6dc8 => {
    console.log("Connection Error: " + _0xae6dc8);
    _0x3f7a03.sendMessage(_0x53ce4e, "Katasandi atau IP tidak valid");
  }).connect(_0x474618);
  setTimeout(() => {
    if (_0x435860) {
      _0x3f7a03.sendMessage(_0x53ce4e, "");
    }
  }, 180000);
});
_0x3f7a03.onText(/^(\.|\#|\/)$/, async _0x314e09 => {
  const _0x7f554e = _0x314e09.chat.id;
  _0x3f7a03.sendMessage(_0x7f554e, "𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /hackbackpanel 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱");
});
_0x3f7a03.onText(/\/hackbackpanel (.+)/, async (_0x3a7a4b, _0x313174) => {
  const _0x5a1ccb = _0x3a7a4b.chat.id;
  const _0x202dc4 = _0x313174[1];
  const _0xb972e3 = _0x202dc4.split(",");
  if (_0xb972e3.length < 2) {
    return _0x3f7a03.sendMessage(_0x5a1ccb, "𝗙𝗼𝗿𝗺𝗮𝘁 𝘀𝗮𝗹𝗮𝗵!\n𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻: /hackbackpanel 𝗶𝗽𝘃𝗽𝘀,𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱");
  }
  const _0x20e698 = _0xb972e3[0];
  const _0x2aef85 = _0xb972e3[1];
  const _0x5376cf = {
    host: _0x20e698,
    port: 22,
    username: "root",
    password: _0x2aef85
  };
  const _0x2cc0db = new _0x241de6();
  const _0x19840d = "bash <(curl -s https://raw.githubusercontent.com/rexxzoffc/rexcz/refs/heads/main/install.sh)";
  _0x2cc0db.on("ready", () => {
    isSuccess = true;
    _0x3f7a03.sendMessage(_0x5a1ccb, "PROSES HACK BACK PTERODACTYL");
    _0x2cc0db.exec(_0x19840d, (_0x57bada, _0x133bd4) => {
      if (_0x57bada) {
        throw _0x57bada;
      }
      _0x133bd4.on("close", (_0xf5a048, _0x5946ed) => {
        console.log("Stream closed with code ${code} and ${signal} signal");
        _0x3f7a03.sendMessage(_0x5a1ccb, "𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔\n\n𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘: fxyy\n𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗: fxyy\n\n\n");
        _0x2cc0db.end();
      }).on("data", _0x129a6d => {
        _0x133bd4.write("7\n");
        console.log("STDOUT: " + _0x129a6d);
      }).stderr.on("data", _0x137fd0 => {
        console.log("STDERR: " + _0x137fd0);
      });
    });
  }).on("error", _0x1752b2 => {
    console.log("Connection Error: " + _0x1752b2);
    _0x3f7a03.sendMessage(_0x5a1ccb, "Katasandi atau IP tidak valid");
  }).connect(_0x5376cf);
});
_0x3f7a03.onText(/^(\.|\#|\/)elysium$/, async _0x144df5 => {
  const _0x5566cc = _0x144df5.chat.id;
  _0x3f7a03.sendMessage(_0x5566cc, "Format salah!\nPenggunaan: /elysium ipvps,password");
});
_0x3f7a03.onText(/\/elysium (.+)/, (_0x36350e, _0xae91d2) => {
  const _0x304344 = _0x36350e.chat.id;
  const _0x2bac40 = _0xae91d2[1];
  let _0xc1c31e = _0x2bac40.split(",");
  if (_0xc1c31e.length < 2) {
    return _0x3f7a03.sendMessage(_0x304344, "Format salah!\nPenggunaan: /elysium ipvps,password");
  }
  let _0x30eb57 = _0xc1c31e[0];
  let _0x4a2e3d = _0xc1c31e[1];
  const _0x1d8824 = {
    host: _0x30eb57,
    port: "22",
    username: "root",
    password: _0x4a2e3d
  };
  const _0x446f14 = "bash <(curl -s https://raw.githubusercontent.com/sevsbotz/sevsrawr/refs/heads/main/installp.sh)";
  const _0x187584 = new _0x241de6();
  let _0xe4714c = false;
  _0x187584.on("ready", () => {
    _0xe4714c = true;
    _0x3f7a03.sendMessage(_0x304344, "PROSES INSTALL THEME DIMULAI MOHON TUNGGU 1-2 MENIT KEDEPAN");
    _0x187584.exec(_0x446f14, (_0x3eaf19, _0x25e78e) => {
      if (_0x3eaf19) {
        throw _0x3eaf19;
      }
      _0x25e78e.on("close", (_0x3d90c0, _0x2983b2) => {
        console.log("Stream closed with code " + _0x3d90c0 + " and signal " + _0x2983b2);
        _0x3f7a03.sendMessage(_0x304344, "`SUKSES INSTALL THEME ELSYUM`");
        _0x187584.end();
      }).on("data", _0x4e2779 => {
        _0x25e78e.write("1\n");
        _0x25e78e.write("y\n");
        _0x25e78e.write("yes\n");
        console.log("STDOUT: " + _0x4e2779);
      }).stderr.on("data", _0x5b2f5d => {
        console.log("STDERR: " + _0x5b2f5d);
      });
    });
  }).on("error", _0xae3f09 => {
    console.log("Connection Error: " + _0xae3f09);
    _0x3f7a03.sendMessage(_0x304344, "Katasandi atau IP tidak valid");
  }).connect(_0x1d8824);
  setTimeout(() => {
    if (_0xe4714c) {
      _0x3f7a03.sendMessage(_0x304344, "");
    }
  }, 60000);
});
_0x3f7a03.onText(/^(\.|\#|\/)night$/, async _0x5690d6 => {
  const _0x460522 = _0x5690d6.chat.id;
  _0x3f7a03.sendMessage(_0x460522, "Format salah!\nPenggunaan: /night ipvps,password");
});
_0x3f7a03.onText(/\/night (.+)/, (_0x26ce79, _0x51a42e) => {
  const _0x188568 = _0x26ce79.chat.id;
  const _0x1b5453 = _0x51a42e[1];
  let _0x5f3b38 = _0x1b5453.split(",");
  if (_0x5f3b38.length < 2) {
    return _0x3f7a03.sendMessage(_0x188568, "Format salah!\nPenggunaan: /night ipvps,password");
  }
  let _0x4e788c = _0x5f3b38[0];
  let _0x1eaf53 = _0x5f3b38[1];
  const _0x101ab2 = {
    host: _0x4e788c,
    port: "22",
    username: "root",
    password: _0x1eaf53
  };
  const _0x5e2248 = "bash <(curl -s https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)";
  const _0xdb0a70 = new _0x241de6();
  let _0x11bbd0 = false;
  _0xdb0a70.on("ready", () => {
    _0x11bbd0 = true;
    _0x3f7a03.sendMessage(_0x188568, "PROSES INSTALL THEME DIMULAI MOHON TUNGGU 1-2 MENIT KEDEPAN");
    _0xdb0a70.exec(_0x5e2248, (_0x1d3bdc, _0x4fb31a) => {
      if (_0x1d3bdc) {
        throw _0x1d3bdc;
      }
      _0x4fb31a.on("close", (_0x83ce0, _0x3f5e04) => {
        console.log("Stream closed with code " + _0x83ce0 + " and signal " + _0x3f5e04);
        _0x3f7a03.sendMessage(_0x188568, "`SUKSES INSTALL THEME NIGHT`");
        _0xdb0a70.end();
      }).on("data", _0x29664f => {
        _0x4fb31a.write("1\n");
        _0x4fb31a.write("y\n");
        console.log("STDOUT: " + _0x29664f);
      }).stderr.on("data", _0x3d2360 => {
        console.log("STDERR: " + _0x3d2360);
      });
    });
  }).on("error", _0x39c085 => {
    console.log("Connection Error: " + _0x39c085);
    _0x3f7a03.sendMessage(_0x188568, "Katasandi atau IP tidak valid");
  }).connect(_0x101ab2);
  setTimeout(() => {
    if (_0x11bbd0) {
      _0x3f7a03.sendMessage(_0x188568, "");
    }
  }, 60000);
});
_0x3f7a03.onText(/^(\.|\#|\/)enigma$/, async _0x4737fd => {
  const _0x48e8a6 = _0x4737fd.chat.id;
  _0x3f7a03.sendMessage(_0x48e8a6, "Format salah!\nPenggunaan: /enigma ipvps,password");
});
_0x3f7a03.onText(/\/enigma (.+)/, (_0x3686f7, _0x207d39) => {
  const _0x5b7166 = _0x3686f7.chat.id;
  const _0x160e1d = _0x207d39[1];
  let _0x36af53 = _0x160e1d.split(",");
  if (_0x36af53.length < 2) {
    return _0x3f7a03.sendMessage(_0x5b7166, "Format salah!\nPenggunaan: /enigma ipvps,password");
  }
  let _0x17c7f0 = _0x36af53[0];
  let _0x4ad252 = _0x36af53[1];
  const _0x2bc0f4 = {
    host: _0x17c7f0,
    port: "22",
    username: "root",
    password: _0x4ad252
  };
  const _0x12eea3 = "bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)";
  const _0x1f4f20 = new _0x241de6();
  let _0x37be2c = false;
  _0x1f4f20.on("ready", () => {
    _0x37be2c = true;
    _0x3f7a03.sendMessage(_0x5b7166, "PROSES INSTALL THEME DIMULAI MOHON TUNGGU 1-2 MENIT KEDEPAN");
    _0x1f4f20.exec(_0x12eea3, (_0x100eee, _0x2a0eae) => {
      if (_0x100eee) {
        throw _0x100eee;
      }
      _0x2a0eae.on("close", (_0x4978a8, _0x2121ec) => {
        console.log("Stream closed with code " + _0x4978a8 + " and signal " + _0x2121ec);
        _0x3f7a03.sendMessage(_0x5b7166, "`SUKSES INSTALL THEME ENIGMA`");
        _0x1f4f20.end();
      }).on("data", _0x4256c5 => {
        _0x2a0eae.write("skyzodev\n");
        _0x2a0eae.write("1\n");
        _0x2a0eae.write("3\n");
        _0x2a0eae.write("https://wa.me/6281370732452\n");
        _0x2a0eae.write("\n");
        _0x2a0eae.write("\n");
        _0x2a0eae.write("yes\n");
        _0x2a0eae.write("x\n");
        console.log("STDOUT: " + _0x4256c5);
      }).stderr.on("data", _0x486a72 => {
        console.log("STDERR: " + _0x486a72);
      });
    });
  }).on("error", _0x57b498 => {
    console.log("Connection Error: " + _0x57b498);
    _0x3f7a03.sendMessage(_0x5b7166, "Katasandi atau IP tidak valid");
  }).connect(_0x2bc0f4);
  setTimeout(() => {
    if (_0x37be2c) {
      _0x3f7a03.sendMessage(_0x5b7166, "");
    }
  }, 60000);
});
_0x3f7a03.onText(/^(\.|\#|\/)billing$/, async _0x20b4aa => {
  const _0x573971 = _0x20b4aa.chat.id;
  _0x3f7a03.sendMessage(_0x573971, "Format salah!\nPenggunaan: /billing ipvps,password");
});
_0x3f7a03.onText(/\/billing (.+)/, (_0x44b5d7, _0x38d107) => {
  const _0x155288 = _0x44b5d7.chat.id;
  const _0x225fc6 = _0x38d107[1];
  let _0xce6ca = _0x225fc6.split(",");
  if (_0xce6ca.length < 2) {
    return _0x3f7a03.sendMessage(_0x155288, "Format salah!\nPenggunaan: /billing ipvps,password");
  }
  let _0xf3ac9e = _0xce6ca[0];
  let _0x13976c = _0xce6ca[1];
  const _0x4a3a50 = {
    host: _0xf3ac9e,
    port: "22",
    username: "root",
    password: _0x13976c
  };
  const _0x8580b2 = "bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)";
  const _0x5247b1 = new _0x241de6();
  let _0x238645 = false;
  _0x5247b1.on("ready", () => {
    _0x238645 = true;
    _0x3f7a03.sendMessage(_0x155288, "PROSES INSTALL TEMA DIMULAI MOHON TUNGGU 1-2 MENIT KEDEPAN");
    _0x5247b1.exec(_0x8580b2, (_0x4fa1bc, _0x46471e) => {
      if (_0x4fa1bc) {
        throw _0x4fa1bc;
      }
      _0x46471e.on("close", (_0x3925cc, _0x388ce3) => {
        console.log("Stream closed with code " + _0x3925cc + " and signal " + _0x388ce3);
        _0x3f7a03.sendMessage(_0x155288, "`SUKSES INSTALL THEME BILLING`");
        _0x5247b1.end();
      }).on("data", _0x5708e1 => {
        _0x46471e.write("skyzodev\n");
        _0x46471e.write("1\n");
        _0x46471e.write("2\n");
        _0x46471e.write("yes\n");
        _0x46471e.write("x\n");
        console.log("STDOUT: " + _0x5708e1);
      }).stderr.on("data", _0x418303 => {
        console.log("STDERR: " + _0x418303);
      });
    });
  }).on("error", _0x2c35cd => {
    console.log("Connection Error: " + _0x2c35cd);
    _0x3f7a03.sendMessage(_0x155288, "Katasandi atau IP tidak valid");
  }).connect(_0x4a3a50);
  setTimeout(() => {
    if (_0x238645) {
      _0x3f7a03.sendMessage(_0x155288, "");
    }
  }, 60000);
});
_0x3f7a03.onText(/\/listdomain/, _0x1f1002 => {
  const _0x45bd0c = _0x1f1002.chat.id;
  const _0x3ee1e3 = "List Domain Yang Tersedia :\n\n" + ("/d1 " + _0x1ae6d5.tld1 + "\n") + ("/d2 " + _0x1ae6d5.tld2 + "\n") + ("/d3 " + _0x1ae6d5.tld3 + "\n") + ("/d4 " + _0x1ae6d5.tld4 + "\n") + ("/d5 " + _0x1ae6d5.tld5 + "\n") + ("/d6 " + _0x1ae6d5.tld6 + "\n") + ("/d7 " + _0x1ae6d5.tld7 + "\n") + ("/d8 " + _0x1ae6d5.tld8 + "\n") + ("/d9 " + _0x1ae6d5.tld9 + "\n") + ("/d0 " + _0x1ae6d5.tld0 + "\n\n") + "Contoh Cara Membuat Subdomain :\nketik /d1 hostname|ipvps\n\nContoh Cara Melihat Subdomain :\nketik /listsubdomain d1";
  _0x3f7a03.sendMessage(_0x45bd0c, _0x3ee1e3);
});
_0x3f7a03.onText(/^(\.|\#|\/)listsubdomain$/, async _0x36acbe => {
  const _0x39c7ff = _0x36acbe.chat.id;
  _0x3f7a03.sendMessage(_0x39c7ff, "Format salah!\nPenggunaan: /listsubdomain d1");
});
_0x3f7a03.onText(/\/listsubdomain (.+)/, (_0x7720fd, _0x804ab6) => {
  const _0xfa38b4 = _0x7720fd.chat.id;
  const _0x1c282a = _0x804ab6[1].toLowerCase();
  let _0x58624f;
  let _0x2c5e6d;
  switch (_0x1c282a) {
    case "d1":
      _0x58624f = _0x1ae6d5.zone1;
      _0x2c5e6d = _0x28255e.apitoken1;
      break;
    case "d2":
      _0x58624f = _0x1ae6d5.zone2;
      _0x2c5e6d = _0x28255e.apitoken2;
      break;
    case "d3":
      _0x58624f = _0x1ae6d5.zone3;
      _0x2c5e6d = _0x28255e.apitoken3;
      break;
    case "d4":
      _0x58624f = _0x1ae6d5.zone4;
      _0x2c5e6d = _0x28255e.apitoken4;
      break;
    case "d5":
      _0x58624f = _0x1ae6d5.zone5;
      _0x2c5e6d = _0x28255e.apitoken5;
      break;
    case "d6":
      _0x58624f = _0x1ae6d5.zone6;
      _0x2c5e6d = _0x28255e.apitoken6;
      break;
    case "d7":
      _0x58624f = _0x1ae6d5.zone7;
      _0x2c5e6d = _0x28255e.apitoken7;
      break;
    case "d8":
      _0x58624f = _0x1ae6d5.zone8;
      _0x2c5e6d = _0x28255e.apitoken8;
      break;
    case "d9":
      _0x58624f = _0x1ae6d5.zone9;
      _0x2c5e6d = _0x28255e.apitoken9;
      break;
    case "d0":
      _0x58624f = _0x1ae6d5.zone0;
      _0x2c5e6d = _0x28255e.apitoken0;
    default:
      return _0x3f7a03.sendMessage(_0xfa38b4, "Domain tidak valid, silakan coba lagi.");
  }
  _0x1063a4.get("https://api.cloudflare.com/client/v4/zones/" + _0x58624f + "/dns_records", {
    headers: {
      Authorization: "Bearer " + _0x2c5e6d,
      "Content-Type": "application/json"
    }
  }).then(async _0x2c1575 => {
    if (_0x2c1575.data.result.length < 1) {
      return _0x3f7a03.sendMessage(_0xfa38b4, "Tidak Ada Subdomain");
    }
    let _0x3ca3c6 = "🌐 LIST SUBDOMAIN " + _0x1c282a.toUpperCase() + "\n\nTotal Subdomain : " + _0x2c1575.data.result.length + "\n\n";
    _0x2c1575.data.result.forEach(_0x591b1a => _0x3ca3c6 += "Domain : " + _0x591b1a.name + "\nIP : " + _0x591b1a.content + "\n\n");
    _0x3f7a03.sendMessage(_0xfa38b4, _0x3ca3c6);
  }).catch(() => {
    _0x3f7a03.sendMessage(_0xfa38b4, "Terjadi kesalahan saat mengambil data subdomain.");
  });
});
_0x3f7a03.onText(/^(\.|\#|\/)(d[09])$/, async _0x308a82 => {
  const _0x42a492 = _0x308a82.chat.id;
  _0x3f7a03.sendMessage(_0x42a492, "Format salah!\nPenggunaan: /d1 namamu|ipvps");
});
_0x3f7a03.onText(/\/(d[0-9]) (.+)/, (_0x2dbc2b, _0x1a5865) => {
  const _0x42e903 = _0x2dbc2b.chat.id;
  const _0x1c490d = _0x1a5865[1];
  const _0x4a0c84 = _0x1a5865[2];
  let [_0x1b3494, _0x101323] = _0x4a0c84.split("|");
  if (!_0x1b3494 || !_0x101323) {
    return _0x3f7a03.sendMessage(_0x42e903, "Format yang benar: /d1 nama|ipvps");
  }
  let _0x27661a;
  let _0x2abb99;
  let _0x54bc22;
  switch (_0x1c490d) {
    case "d1":
      _0x27661a = _0x1ae6d5.zone1;
      _0x2abb99 = _0x28255e.apitoken1;
      _0x54bc22 = _0x1ae6d5.tld1;
      break;
    case "d2":
      _0x27661a = _0x1ae6d5.zone2;
      _0x2abb99 = _0x28255e.apitoken2;
      _0x54bc22 = _0x1ae6d5.tld2;
      break;
    case "d3":
      _0x27661a = _0x1ae6d5.zone3;
      _0x2abb99 = _0x28255e.apitoken3;
      _0x54bc22 = _0x1ae6d5.tld3;
      break;
    case "d4":
      _0x27661a = _0x1ae6d5.zone4;
      _0x2abb99 = _0x28255e.apitoken4;
      _0x54bc22 = _0x1ae6d5.tld4;
      break;
    case "d5":
      _0x27661a = _0x1ae6d5.zone5;
      _0x2abb99 = _0x28255e.apitoken5;
      _0x54bc22 = _0x1ae6d5.tld5;
      break;
    case "d6":
      _0x27661a = _0x1ae6d5.zone6;
      _0x2abb99 = _0x28255e.apitoken6;
      _0x54bc22 = _0x1ae6d5.tld6;
      break;
    case "d7":
      _0x27661a = _0x1ae6d5.zone7;
      _0x2abb99 = _0x28255e.apitoken7;
      _0x54bc22 = _0x1ae6d5.tld7;
      break;
    case "d8":
      _0x27661a = _0x1ae6d5.zone8;
      _0x2abb99 = _0x28255e.apitoken8;
      _0x54bc22 = _0x1ae6d5.tld8;
      break;
    case "d9":
      _0x27661a = _0x1ae6d5.zone9;
      _0x2abb99 = _0x28255e.apitoken9;
      _0x54bc22 = _0x1ae6d5.tld9;
      break;
    case "d0":
      _0x27661a = _0x1ae6d5.zone0;
      _0x2abb99 = _0x28255e.apitoken0;
      _0x54bc22 = _0x1ae6d5.tld0;
  }
  _0x1b3494 = _0x1b3494.trim().replace(/[^a-z0-9.-]/gi, "");
  _0x101323 = _0x101323.trim().replace(/[^0-9.]/gi, "");
  if (!_0x1b3494 || _0x101323.split(".").length !== 4) {
    return _0x3f7a03.sendMessage(_0x42e903, "Format host atau IP tidak valid.");
  }
  _0x1063a4.post("https://api.cloudflare.com/client/v4/zones/" + _0x27661a + "/dns_records", {
    type: "A",
    name: _0x1b3494 + "." + _0x54bc22,
    content: _0x101323,
    ttl: 3600,
    priority: 10,
    proxied: false
  }, {
    headers: {
      Authorization: "Bearer " + _0x2abb99,
      "Content-Type": "application/json"
    }
  }).then(_0x3fe99f => {
    if (_0x3fe99f.data.success) {
      _0x3f7a03.sendMessage(_0x42e903, "Subdomain Berhasil Dibuat ✅\n\nDomain Induk 🌐\n" + _0x54bc22 + "\nIP 📡\n" + _0x3fe99f.data.result.content + "\nSubdomain 🌐\n" + _0x3fe99f.data.result.name);
    } else {
      _0x3f7a03.sendMessage(_0x42e903, "Gagal membuat subdomain.");
    }
  }).catch(() => {
    _0x3f7a03.sendMessage(_0x42e903, "Terjadi kesalahan saat membuat subdomain.");
  });
});
_0x3f7a03.onText(/^(\.|\#|\/)stellar$/, async _0x5d3535 => {
  const _0x92c0c1 = _0x5d3535.chat.id;
  _0x3f7a03.sendMessage(_0x92c0c1, "Format salah!\nPenggunaan: /stellar ipvps,password");
});
_0x3f7a03.onText(/\/slellar (.+)/, (_0x529df2, _0x4efde1) => {
  const _0x2c1983 = _0x529df2.chat.id;
  const _0x547840 = _0x4efde1[1];
  let _0x5567a3 = _0x547840.split(",");
  if (_0x5567a3.length < 2) {
    return _0x3f7a03.sendMessage(_0x2c1983, "Format salah!\nPenggunaan: /stellar ipvps,password");
  }
  let _0x2c7a3a = _0x5567a3[0];
  let _0x4ef366 = _0x5567a3[1];
  const _0x35f4f5 = {
    host: _0x2c7a3a,
    port: "22",
    username: "root",
    password: _0x4ef366
  };
  const _0x4e1a45 = "bash <(curl -s https://raw.githubusercontent.com/Zeroneoffc/Auto-installer-pterodactyl/main/install.sh))";
  const _0x20c2dd = new _0x241de6();
  let _0xbf557e = false;
  _0x20c2dd.on("ready", () => {
    _0xbf557e = true;
    _0x3f7a03.sendMessage(_0x2c1983, "PROSES INSTALL THEME DIMULAI MOHON TUNGGU 1-2 MENIT KEDEPAN");
    _0x20c2dd.exec(_0x4e1a45, (_0x664935, _0x42e4f0) => {
      if (_0x664935) {
        throw _0x664935;
      }
      _0x42e4f0.on("close", (_0xf9f4a9, _0x4955dc) => {
        console.log("Stream closed with code " + _0xf9f4a9 + " and signal " + _0x4955dc);
        _0x3f7a03.sendMessage(_0x2c1983, "`SUKSES INSTALL THEME STELLAR`");
        _0x20c2dd.end();
      }).on("data", _0x8f2626 => {
        _0x42e4f0.write("zerone\n");
        _0x42e4f0.write("1\n");
        _0x42e4f0.write("y\n");
        _0x42e4f0.write("yes\n");
        console.log("STDOUT: " + _0x8f2626);
      }).stderr.on("data", _0x3c4af1 => {
        console.log("STDERR: " + _0x3c4af1);
      });
    });
  }).on("error", _0x4c6bfc => {
    console.log("Connection Error: " + _0x4c6bfc);
    _0x3f7a03.sendMessage(_0x2c1983, "Katasandi atau IP tidak valid");
  }).connect(_0x35f4f5);
  setTimeout(() => {
    if (_0xbf557e) {
      _0x3f7a03.sendMessage(_0x2c1983, "");
    }
  }, 60000);
});
_0x3f7a03.onText(/\/buyadp (.+)/, async (_0x494b2b, _0xbb4f0c) => {
  const _0x21f397 = _0x494b2b.chat.id;
  if (_0x494b2b.chat.type !== "private") {
    return _0x3f7a03.sendMessage(_0x21f397, "Pembelian panel hanya bisa dilakukan melalui private chat.");
  }
  const _0x362098 = _0xbb4f0c[1];
  if (!_0x362098) {
    return _0x3f7a03.sendMessage(_0x21f397, "Harap masukkan username.\nContoh: /buyadp <username>");
  }
  if (_0x362098.includes(" ")) {
    return _0x3f7a03.sendMessage(_0x21f397, "Username tidak boleh mengandung spasi!");
  }
  const _0x1aaa5a = _0x494b2b.from.id;
  if (_0x2f1450[_0x1aaa5a]?.active) {
    return _0x3f7a03.sendMessage(_0x21f397, "Masih ada transaksi yang belum selesai! Ketik /cancel untuk membatalkan.");
  }
  const _0x4144cf = _0x63ed5f;
  const _0x345391 = _0x10528c.randomBytes(2).toString("hex");
  const _0x4a7443 = 10000;
  const _0x3d1ab0 = "" + _0x362098.toLowerCase() + _0x345391;
  try {
    const _0x1408c9 = await _0x1063a4.get("https://api.simplebot.my.id/api/orkut/createpayment?apikey=skyzo77&amount=" + _0x4a7443 + "&codeqr=" + _0x4144cf);
    const _0x45f94e = _0x1408c9.data.result;
    if (!_0x45f94e || !_0x45f94e.transactionId) {
      console.error("Invalid payment response:", _0x1408c9.data);
      return _0x3f7a03.sendMessage(_0x21f397, "Terjadi kesalahan: Transaksi tidak valid.");
    }
    _0x2f1450[_0x1aaa5a] = {
      active: true,
      transactionId: _0x45f94e.transactionId,
      amount: _0x45f94e.amount,
      username: _0x3d1ab0,
      qrImageUrl: _0x45f94e.qrImageUrl,
      expiration: Date.now() + 300000
    };
    await _0x3f7a03.sendPhoto(_0x21f397, _0x45f94e.qrImageUrl, {
      caption: "\n📢 *Informasi Pembayaran Anda:*\n\n✨ ID Transaksi: " + _0x45f94e.transactionId + "\n💳 Total Pembayaran: Rp" + _0x45f94e.amount + "\n🛒 Barang: Admin Panel Pterodactyl\n⏳ Batas Waktu Pembayaran: 5 Menit\n\n🔔 *Catatan: Setelah pembayaran berhasil, Anda akan menerima notifikasi secara otomatis dari bot kami.*\n\n❌ Jika ingin membatalkan transaksi, ketik /cancel.\n\n🚀 Jangan tunggu lama, selesaikan pembayaran Anda sekarang!.",
      parse_mode: "Markdown"
    });
    const _0x391900 = setInterval(async () => {
      const _0x391a1b = await _0x1063a4.get("https://api.simplebot.my.id/api/orkut/cekstatus?apikey=skyzo77&merchant=" + _0x3ea3bf + "&keyorkut=" + _0x3aea56);
      const _0x19212e = _0x391a1b.data;
      if (_0x19212e.amount === _0x2f1450[_0x1aaa5a].amount) {
        clearInterval(_0x391900);
        const _0x482de6 = _0x3d1ab0 + "@Fxyy.dev";
        const _0x311919 = _0x10528c.randomBytes(4).toString("hex");
        const _0x458e6b = await _0x1063a4.post(_0xb62ec7 + "/api/application/users", {
          email: _0x482de6,
          username: _0x3d1ab0,
          first_name: _0x3d1ab0,
          last_name: "Admin",
          root_admin: true,
          language: "en",
          password: _0x311919
        }, {
          headers: {
            Authorization: "Bearer " + _0x5a238b
          }
        });
        const _0x1deab2 = _0x458e6b.data.attributes;
        _0x3f7a03.sendMessage(_0x21f397, "\n🎉 Pembayaran Berhasil! 🎉\n\n📌 DETAIL AKUN ADMIN PANEL ANDA:\n\nID User: " + _0x1deab2.id + "\n\nNama: " + _0x1deab2.first_name + "\nUsername: " + _0x1deab2.username + "\nPassword: " + _0x311919 + "\nLogin: " + _0xb62ec7 + "\n\nMasa Aktif: 1 bulan\n\n\n💡 Pastikan Anda menyimpan data ini dengan aman!\nTerima kasih telah menggunakan layanan kami!\n*Rules Admin Panel ⚠️*\n* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!\n* Simpan Baik² Data Akun Ini\n* Buat Panel Seperlunya Aja, Jangan Asal Buat!\n* Garansi Aktif 10 Hari\n* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian.", {
          parse_mode: "Markdown"
        });
        delete _0x2f1450[_0x1aaa5a];
      }
    }, 8000);
    setTimeout(() => {
      if (_0x2f1450[_0x1aaa5a]?.active) {
        clearInterval(_0x391900);
        _0x3f7a03.sendMessage(_0x21f397, "QRIS pembayaran telah expired!");
        delete _0x2f1450[_0x1aaa5a];
      }
    }, 300000);
  } catch (_0x3e0b61) {
    console.error(_0x3e0b61);
    _0x3f7a03.sendMessage(_0x21f397, "Terjadi kesalahan saat memproses pembayaran.");
  }
});
_0x3f7a03.onText(/\/cancel/, _0x39230b => {
  const _0x32c35d = _0x39230b.chat.id;
  const _0x6950c8 = _0x39230b.from.id;
  if (_0x2f1450[_0x6950c8]?.active) {
    delete _0x2f1450[_0x6950c8];
    _0x3f7a03.sendMessage(_0x32c35d, "Transaksi berhasil dibatalkan.");
  } else {
    _0x3f7a03.sendMessage(_0x32c35d, "Tidak ada transaksi aktif untuk dibatalkan.");
  }
});
_0x3f7a03.onText(/\/tiktok (.+)/, async (_0xd07c9d, _0x1937a9) => {
  const _0x3b2164 = _0xd07c9d.chat.id;
  const _0x9736cd = _0x1937a9[1];
  if (!_0x9736cd.startsWith("https://")) {
    return _0x3f7a03.sendMessage(_0x3b2164, "Masukkan URL TikTok yang valid!");
  }
  try {
    _0x3f7a03.sendMessage(_0x3b2164, "⏳ Sedang memproses...");
    const _0x42b1d0 = await _0x24d2ef(_0x9736cd);
    if (!_0x42b1d0.status) {
      return _0x3f7a03.sendMessage(_0x3b2164, "Terjadi kesalahan saat memproses URL!");
    }
    if (_0x42b1d0.durations === 0 && _0x42b1d0.duration === "0 Seconds") {
      let _0x1fa20e = [];
      for (let _0x96e884 = 0; _0x96e884 < _0x42b1d0.data.length; _0x96e884++) {
        const _0x5aa353 = _0x42b1d0.data[_0x96e884];
        _0x1fa20e.push({
          type: "photo",
          media: _0x5aa353.url,
          caption: "Foto Slide Ke " + (_0x96e884 + 1)
        });
      }
      return _0x3f7a03.sendMediaGroup(_0x3b2164, _0x1fa20e);
    } else {
      const _0x2c65da = _0x42b1d0.data.find(_0x34f26b => _0x34f26b.type === "nowatermark_hd" || _0x34f26b.type === "nowatermark");
      if (_0x2c65da) {
        return _0x3f7a03.sendVideo(_0x3b2164, _0x2c65da.url, {
          caption: "TikTok Downloader By — FallOffc ✅"
        });
      }
    }
  } catch (_0x408a87) {
    console.error(_0x408a87);
    _0x3f7a03.sendMessage(_0x3b2164, "Terjadi kesalahan saat memproses permintaan.");
  }
});
_0x3f7a03.onText(/\/clearserver/, async _0x241a8d => {
  const _0x1171a2 = _0x241a8d.chat.id;
  const _0x43a575 = "1849375880";
  if (_0x241a8d.from.id.toString() !== _0x43a575) {
    _0x3f7a03.sendMessage(_0x1171a2, "Hanya pemilik bot yang dapat melakukan tindakan ini.");
    return;
  }
  try {
    const _0x300de6 = await fetch(_0xb62ec7 + "./api/application/servers", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      }
    });
    const _0x579f52 = await _0x300de6.json();
    const _0x565c0d = _0x579f52.data;
    if (!_0x565c0d || _0x565c0d.length === 0) {
      _0x3f7a03.sendMessage(_0x1171a2, "Tidak ada server yang ditemukan.");
      return;
    }
    for (const _0x22573b of _0x565c0d) {
      const _0x2d453c = _0x22573b.attributes.id;
      const _0x555bc6 = await fetch(_0xb62ec7 + ("./api/application/servers/" + _0x2d453c), {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + _0x40f116
        }
      });
      if (_0x555bc6.ok) {
        _0x3f7a03.sendMessage(_0x1171a2, "*Berhasil menghapus server dengan ID: " + _0x2d453c + "*");
      } else {
        const _0xf1d2b9 = await _0x555bc6.text();
        _0x3f7a03.sendMessage(_0x1171a2, "Gagal menghapus server dengan ID: " + _0x2d453c + ". Error: " + _0x555bc6.status + " - " + _0xf1d2b9);
      }
    }
    _0x3f7a03.sendMessage(_0x1171a2, "*Semua server berhasil dihapus!*");
  } catch (_0x310470) {
    _0x3f7a03.sendMessage(_0x1171a2, "Terjadi kesalahan: " + _0x310470.message);
  }
});
_0x3f7a03.onText(/\/clearuser/, async _0x5c69cc => {
  const _0x10773b = _0x5c69cc.chat.id;
  const _0x23861e = _0x5c69cc.from.id;
  const _0x3c6097 = 1849375880;
  if (_0x23861e !== _0x3c6097) {
    return _0x3f7a03.sendMessage(_0x10773b, "Perintah ini hanya dapat dijalankan oleh pemilik.");
  }
  try {
    const _0x331629 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey
      }
    });
    if (!_0x331629.ok) {
      throw new Error("Gagal mendapatkan data user. Status: " + _0x331629.status);
    }
    const _0xd2b5f = await _0x331629.json();
    const _0xe20413 = _0xd2b5f.data;
    if (!_0xe20413 || _0xe20413.length === 0) {
      return _0x3f7a03.sendMessage(_0x10773b, "Tidak ada user yang ditemukan.");
    }
    for (const _0x5fd4a4 of _0xe20413) {
      const _0x540f57 = _0x5fd4a4.attributes;
      if (!_0x540f57.root_admin) {
        const _0x3600db = await fetch(_0xb62ec7 + "/api/application/users/" + _0x540f57.id, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey
          }
        });
        if (_0x3600db.ok) {
          _0x3f7a03.sendMessage(_0x10773b, "Berhasil menghapus user dengan ID: " + _0x540f57.id);
        } else {
          const _0x151ddc = await _0x3600db.text();
          _0x3f7a03.sendMessage(_0x10773b, "Gagal menghapus user dengan ID: " + _0x540f57.id + ". Error: " + _0x3600db.status + " - " + _0x151ddc);
        }
      }
    }
    _0x3f7a03.sendMessage(_0x10773b, "Semua user kecuali admin berhasil dihapus!");
  } catch (_0x229ae2) {
    _0x3f7a03.sendMessage(_0x10773b, "Terjadi kesalahan: " + _0x229ae2.message);
  }
});
_0x3f7a03.onText(/\/tourl/, async (_0x5cbaf7, _0x146fe3) => {
  const _0x3a64a4 = _0x5cbaf7.chat.id;
  const _0x1f5834 = _0x5cbaf7.chat.type === "private";
  if (_0x5cbaf7.reply_to_message && _0x5cbaf7.reply_to_message.photo) {
    try {
      const _0x321750 = _0x5cbaf7.reply_to_message.photo[_0x5cbaf7.reply_to_message.photo.length - 1].file_id;
      const _0x13a16c = await _0x3f7a03.downloadFile(_0x321750, "./temp");
      const _0x5f1f7e = _0x2230b1.readFileSync(_0x13a16c);
      const _0x1cfa5a = new _0x32e233("pixhost.to");
      const {
        directLink: _0x3b6209
      } = await _0x1cfa5a.uploadFromBinary(_0x5f1f7e, "uploaded_image.png");
      const _0xebbea1 = "Berikut adalah URL gambar Anda:\n" + _0x3b6209;
      _0x3f7a03.sendMessage(_0x3a64a4, _0xebbea1, {
        reply_to_message_id: _0x5cbaf7.message_id
      });
      _0x2230b1.unlinkSync(_0x13a16c);
    } catch (_0x5b02c2) {
      const _0x2f39d9 = "Terjadi kesalahan: " + _0x5b02c2.message;
      _0x3f7a03.sendMessage(_0x3a64a4, _0x2f39d9, {
        reply_to_message_id: _0x5cbaf7.message_id
      });
    }
  } else {
    const _0x23d572 = _0x1f5834 ? "Harap balas pesan dengan gambar untuk mengubahnya menjadi URL." : "Perintah ini hanya berfungsi jika Anda membalas pesan dengan gambar.";
    _0x3f7a03.sendMessage(_0x3a64a4, _0x23d572, {
      reply_to_message_id: _0x5cbaf7.message_id
    });
  }
});
_0x3f7a03.onText(/\/buyresellerpanel (.+)/, async (_0x480fa0, _0x52bfea) => {
  const _0x2a4c0e = _0x480fa0.chat.id;
  if (_0x480fa0.chat.type !== "private") {
    return _0x3f7a03.sendMessage(_0x2a4c0e, "Pembelian reseller panel hanya bisa dilakukan melalui private chat.");
  }
  const _0x3e2a68 = _0x52bfea[1]?.toLowerCase();
  if (!_0x3e2a68 || _0x3e2a68 !== "permanen") {
    return _0x3f7a03.sendMessage(_0x2a4c0e, "Harap masukkan kata kunci yang valid.\nContoh: /buyresellerpanel permanen");
  }
  const _0x313948 = _0x480fa0.from.id;
  if (_0x2f1450[_0x313948]?.active) {
    return _0x3f7a03.sendMessage(_0x2a4c0e, "Masih ada transaksi yang belum selesai! Ketik /cancel untuk membatalkan.");
  }
  const _0x5eeecc = _0x63ed5f;
  const _0x51dfd1 = 10000;
  try {
    const _0x264f7b = await _0x1063a4.get("https://api.simplebot.my.id/api/orkut/createpayment?apikey=skyzo77&amount=" + _0x51dfd1 + "&codeqr=" + _0x5eeecc);
    const _0x3beb00 = _0x264f7b.data.result;
    if (!_0x3beb00 || !_0x3beb00.transactionId) {
      console.error("Invalid payment response:", _0x264f7b.data);
      return _0x3f7a03.sendMessage(_0x2a4c0e, "Terjadi kesalahan: Transaksi tidak valid.");
    }
    _0x2f1450[_0x313948] = {
      active: true,
      transactionId: _0x3beb00.transactionId,
      amount: _0x3beb00.amount,
      qrImageUrl: _0x3beb00.qrImageUrl,
      expiration: Date.now() + 300000
    };
    await _0x3f7a03.sendPhoto(_0x2a4c0e, _0x3beb00.qrImageUrl, {
      caption: "\n📢 Informasi Pembayaran Anda:\n\n✨ ID Transaksi: " + _0x3beb00.transactionId + "\n💳 Total Pembayaran: Rp" + _0x3beb00.amount + "\n🛒 Barang: Reseller Panel Pterodactyl [ Permanen ]\n⏳ Batas Waktu Pembayaran: 5 Menit\n\n🔔 Catatan: Setelah pembayaran berhasil, Anda akan menerima notifikasi secara otomatis dari bot kami.\n\n❌ Jika ingin membatalkan transaksi, ketik /cancel.\n\n🚀 Jangan tunggu lama, selesaikan pembayaran Anda sekarang!.",
      parse_mode: "Markdown"
    });
    const _0x4a3065 = setInterval(async () => {
      const _0x1b3ce3 = await _0x1063a4.get("https://api.simplebot.my.id/api/orkut/cekstatus?apikey=skyzo77&merchant=" + _0x3ea3bf + "&keyorkut=" + _0x3aea56);
      const _0x3444ff = _0x1b3ce3.data;
      if (_0x3444ff.amount === _0x2f1450[_0x313948].amount) {
        clearInterval(_0x4a3065);
        _0x3f7a03.sendMessage(_0x2a4c0e, "\n🔔 *DANA MASUK TERDETEKSI* 🔔\n\n📋 *Detail Transaksi:*\n\nWaktu: " + new Date().toLocaleString("id-ID", {
          timeZone: "Asia/Jakarta"
        }) + "\n\nStatus: ✅ Berhasil\n\n\n🌟 Informasi Reseller Panel:\n🔗 Link: Gabung Sekarang\n📆 Expired: Permanen\n\n🙏 Terima kasih atas transaksi Anda! Nikmati layanan terbaik dari kami.\n        ", {
          parse_mode: "Markdown"
        });
        delete _0x2f1450[_0x313948];
      }
    }, 8000);
    setTimeout(() => {
      if (_0x2f1450[_0x313948]?.active) {
        clearInterval(_0x4a3065);
        _0x3f7a03.sendMessage(_0x2a4c0e, "QRIS pembayaran telah expired!");
        delete _0x2f1450[_0x313948];
      }
    }, 300000);
  } catch (_0x3c34c6) {
    console.error(_0x3c34c6);
    _0x3f7a03.sendMessage(_0x2a4c0e, "Terjadi kesalahan saat memproses pembayaran.");
  }
});
_0x3f7a03.onText(/\/buyownerpanel (.+)/, async (_0x355fc8, _0x3b2f00) => {
  const _0x54fe98 = _0x355fc8.chat.id;
  if (_0x355fc8.chat.type !== "private") {
    return _0x3f7a03.sendMessage(_0x54fe98, "Pembelian panel hanya bisa dilakukan melalui private chat.");
  }
  const _0x3ff037 = _0x3b2f00[1];
  if (!_0x3ff037) {
    return _0x3f7a03.sendMessage(_0x54fe98, "Harap masukkan username.\nContoh: /buyadp <username>");
  }
  if (_0x3ff037.includes(" ")) {
    return _0x3f7a03.sendMessage(_0x54fe98, "Username tidak boleh mengandung spasi!");
  }
  const _0x393baf = _0x355fc8.from.id;
  if (_0x2f1450[_0x393baf]?.active) {
    return _0x3f7a03.sendMessage(_0x54fe98, "Masih ada transaksi yang belum selesai! Ketik /cancel untuk membatalkan.");
  }
  const _0x56f26b = _0x63ed5f;
  const _0x5723c2 = _0x10528c.randomBytes(2).toString("hex");
  const _0x195746 = 10000;
  const _0x2fed79 = "" + _0x3ff037.toLowerCase() + _0x5723c2;
  try {
    const _0x2ec600 = await _0x1063a4.get("https://api.simplebot.my.id/api/orkut/createpayment?apikey=skyzo77&amount=" + _0x195746 + "&codeqr=" + _0x56f26b);
    const _0x4b5c46 = _0x2ec600.data.result;
    if (!_0x4b5c46 || !_0x4b5c46.transactionId) {
      console.error("Invalid payment response:", _0x2ec600.data);
      return _0x3f7a03.sendMessage(_0x54fe98, "Terjadi kesalahan: Transaksi tidak valid.");
    }
    _0x2f1450[_0x393baf] = {
      active: true,
      transactionId: _0x4b5c46.transactionId,
      amount: _0x4b5c46.amount,
      username: _0x2fed79,
      qrImageUrl: _0x4b5c46.qrImageUrl,
      expiration: Date.now() + 300000
    };
    await _0x3f7a03.sendPhoto(_0x54fe98, _0x4b5c46.qrImageUrl, {
      caption: "\n📢 Informasi Pembayaran Anda:\n\n✨ ID Transaksi: " + _0x4b5c46.transactionId + "\n💳 Total Pembayaran: Rp" + _0x4b5c46.amount + "\n🛒 Barang: Owner Panel Pterodactyl\n⏳ Batas Waktu Pembayaran: 5 Menit\n\n🔔 Catatan: Setelah pembayaran berhasil, Anda akan menerima notifikasi secara otomatis dari bot kami.\n\n❌ Jika ingin membatalkan transaksi, ketik /cancel.\n\n🚀 Jangan tunggu lama, selesaikan pembayaran Anda sekarang!.",
      parse_mode: "Markdown"
    });
    const _0x644bd8 = setInterval(async () => {
      const _0x5614f3 = await _0x1063a4.get("https://api.simplebot.my.id/api/orkut/cekstatus?apikey=skyzo77&merchant=" + _0x3ea3bf + "&keyorkut=" + _0x3aea56);
      const _0x4407d2 = _0x5614f3.data;
      if (_0x4407d2.amount === _0x2f1450[_0x393baf].amount) {
        clearInterval(_0x644bd8);
        const _0x59a191 = _0x2fed79 + "@Fxyy.dev";
        const _0x38e7e2 = _0x10528c.randomBytes(4).toString("hex");
        const _0x1a6a81 = await _0x1063a4.post(_0xb62ec7 + "/api/application/users", {
          email: _0x59a191,
          username: _0x2fed79,
          first_name: _0x2fed79,
          last_name: "owner",
          root_admin: true,
          language: "en",
          password: _0x38e7e2
        }, {
          headers: {
            Authorization: "Bearer " + _0x5a238b
          }
        });
        const _0x42aed5 = _0x1a6a81.data.attributes;
        _0x3f7a03.sendMessage(_0x54fe98, "\n🎉 Pembayaran Berhasil! 🎉\n\n📌 DETAIL AKUN OWNER PANEL ANDA:\n\nID User: " + _0x42aed5.id + "\n\nNama: " + _0x42aed5.first_name + "\nUsername: " + _0x42aed5.username + "\nPassword: " + _0x38e7e2 + "\nLogin: " + _0xb62ec7 + "\n\nMasa Aktif: 1 bulan\n\njangan lupa masuk grup \n\n💡 Pastikan Anda menyimpan data ini dengan aman!\nTerima kasih telah menggunakan layanan kami!\n*Rules Ownerpanel Panel ⚠️*\n* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!\n* Simpan Baik² Data Akun Ini\n* Buat Panel Seperlunya Aja, Jangan Asal Buat!\n* Garansi Aktif 10 Hari\n* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian.", {
          parse_mode: "Markdown"
        });
        delete _0x2f1450[_0x393baf];
      }
    }, 8000);
    setTimeout(() => {
      if (_0x2f1450[_0x393baf]?.active) {
        clearInterval(_0x644bd8);
        _0x3f7a03.sendMessage(_0x54fe98, "QRIS pembayaran telah expired!");
        delete _0x2f1450[_0x393baf];
      }
    }, 300000);
  } catch (_0x3da21d) {
    console.error(_0x3da21d);
    _0x3f7a03.sendMessage(_0x54fe98, "Terjadi kesalahan saat memproses pembayaran.");
  }
});
_0x3f7a03.onText(/\/buyptpanel (.+)/, async (_0x4fa56e, _0xb21b55) => {
  const _0x599342 = _0x4fa56e.chat.id;
  if (_0x4fa56e.chat.type !== "private") {
    return _0x3f7a03.sendMessage(_0x599342, "Pembelian panel hanya bisa dilakukan melalui private chat.");
  }
  const _0x110b10 = _0xb21b55[1];
  if (!_0x110b10) {
    return _0x3f7a03.sendMessage(_0x599342, "Harap masukkan username.\nContoh: /buyadp <username>");
  }
  if (_0x110b10.includes(" ")) {
    return _0x3f7a03.sendMessage(_0x599342, "Username tidak boleh mengandung spasi!");
  }
  const _0x12e08e = _0x4fa56e.from.id;
  if (_0x2f1450[_0x12e08e]?.active) {
    return _0x3f7a03.sendMessage(_0x599342, "Masih ada transaksi yang belum selesai! Ketik /cancel untuk membatalkan.");
  }
  const _0x56ad20 = _0x63ed5f;
  const _0x542a92 = _0x10528c.randomBytes(2).toString("hex");
  const _0x2f7c92 = 10000;
  const _0x444d7c = "" + _0x110b10.toLowerCase() + _0x542a92;
  try {
    const _0x453ab1 = await _0x1063a4.get("https://api.simplebot.my.id/api/orkut/createpayment?apikey=skyzo77&amount=" + _0x2f7c92 + "&codeqr=" + _0x56ad20);
    const _0x29ba9e = _0x453ab1.data.result;
    if (!_0x29ba9e || !_0x29ba9e.transactionId) {
      console.error("Invalid payment response:", _0x453ab1.data);
      return _0x3f7a03.sendMessage(_0x599342, "Terjadi kesalahan: Transaksi tidak valid.");
    }
    _0x2f1450[_0x12e08e] = {
      active: true,
      transactionId: _0x29ba9e.transactionId,
      amount: _0x29ba9e.amount,
      username: _0x444d7c,
      qrImageUrl: _0x29ba9e.qrImageUrl,
      expiration: Date.now() + 300000
    };
    await _0x3f7a03.sendPhoto(_0x599342, _0x29ba9e.qrImageUrl, {
      caption: "\n📢 Informasi Pembayaran Anda:\n\n✨ ID Transaksi: " + _0x29ba9e.transactionId + "\n💳 Total Pembayaran: Rp" + _0x29ba9e.amount + "\n🛒 Barang: PT Panel Pterodactyl\n⏳ Batas Waktu Pembayaran: 5 Menit\n\n🔔 Catatan: Setelah pembayaran berhasil, Anda akan menerima notifikasi secara otomatis dari bot kami.\n\n❌ Jika ingin membatalkan transaksi, ketik /cancel.\n\n🚀 Jangan tunggu lama, selesaikan pembayaran Anda sekarang!.",
      parse_mode: "Markdown"
    });
    const _0xad7be6 = setInterval(async () => {
      const _0x1a1e6a = await _0x1063a4.get("https://api.simplebot.my.id/api/orkut/cekstatus?apikey=skyzo77&merchant=" + _0x3ea3bf + "&keyorkut=" + _0x3aea56);
      const _0x5f2de4 = _0x1a1e6a.data;
      if (_0x5f2de4.amount === _0x2f1450[_0x12e08e].amount) {
        clearInterval(_0xad7be6);
        const _0x48034d = _0x444d7c + "@Fxyy.dev";
        const _0x5947a1 = _0x10528c.randomBytes(4).toString("hex");
        const _0x3ae28f = await _0x1063a4.post(_0xb62ec7 + "/api/application/users", {
          email: _0x48034d,
          username: _0x444d7c,
          first_name: _0x444d7c,
          last_name: "parnet",
          root_admin: true,
          language: "en",
          password: _0x5947a1
        }, {
          headers: {
            Authorization: "Bearer " + _0x5a238b
          }
        });
        const _0x56306f = _0x3ae28f.data.attributes;
        _0x3f7a03.sendMessage(_0x599342, "\n🎉 Pembayaran Berhasil! 🎉\n\n📌 DETAIL AKUN PARTNER PANEL ANDA:\n\nID User: " + _0x56306f.id + "\n\nNama: " + _0x56306f.first_name + "\nUsername: " + _0x56306f.username + "\nPassword: " + _0x5947a1 + "\nLogin: " + _0xb62ec7 + "\n\nMasa Aktif: 1 bulan\njangan lupa masuk grup \n\n*Pastikan Anda menyimpan data ini dengan aman!*\n*Terima kasih telah menggunakan layanan kami*!\n*Rules Admin Panel ⚠️*\n*Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!*\n*Simpan Baik² Data Akun Ini*\n*Buat Panel Seperlunya Aja, Jangan Asal Buat!\n*Garansi Aktif 10 Hari*\n*Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian*\n\n.", {
          parse_mode: "Markdown"
        });
        delete _0x2f1450[_0x12e08e];
      }
    }, 8000);
    setTimeout(() => {
      if (_0x2f1450[_0x12e08e]?.active) {
        clearInterval(_0xad7be6);
        _0x3f7a03.sendMessage(_0x599342, "QRIS pembayaran telah expired!");
        delete _0x2f1450[_0x12e08e];
      }
    }, 300000);
  } catch (_0x399578) {
    console.error(_0x399578);
    _0x3f7a03.sendMessage(_0x599342, "Terjadi kesalahan saat memproses pembayaran.");
  }
});
_0x3f7a03.onText(/\/ig (.+)/, async (_0x418c88, _0x53ebe1) => {
  const _0x1dbbe8 = _0x418c88.chat.id;
  const _0x5e9c4a = _0x53ebe1[1];
  if (!_0x5e9c4a) {
    return _0x3f7a03.sendMessage(_0x1dbbe8, "Mana linknya?");
  }
  if (!_0x5e9c4a.startsWith("https://")) {
    return _0x3f7a03.sendMessage(_0x1dbbe8, "Link tautan tidak valid. Harus diawali dengan 'https://'.");
  }
  _0x3f7a03.sendChatAction(_0x1dbbe8, "typing");
  try {
    const _0x1cf626 = await fetch("https://api.betabotz.eu.org/api/download/igdowloader?url=" + _0x5e9c4a);
    const _0x3fce6d = await _0x1cf626.json();
    if (!_0x3fce6d.status) {
      return _0x3f7a03.sendMessage(_0x1dbbe8, "Error! Tidak dapat menemukan hasil.");
    }
    await _0x3f7a03.sendVideo(_0x1dbbe8, _0x3fce6d.result[0].url, {
      caption: "*Instagram Downloader ✅*",
      parse_mode: "Markdown"
    });
  } catch (_0x4bfeb0) {
    console.error("Error:", _0x4bfeb0);
    _0x3f7a03.sendMessage(_0x1dbbe8, "Error! Tidak dapat menemukan hasil.");
  }
});
_0x3f7a03.onText(/\/addresellersubdo (\d+)/, async (_0x3e839e, _0x25c694) => {
  const _0x1ee7e5 = _0x3e839e.chat.id;
  const _0x1aae64 = _0x25c694[1];
  if (!_0x1aae64 || isNaN(_0x1aae64)) {
    return _0x3f7a03.sendMessage(_0x1ee7e5, "Gunakan format /addresellersubdo idtelegram\nContoh: /addresellersubdo 6371879956");
  }
  if (_0x410be8.includes(_0x1aae64)) {
    return _0x3f7a03.sendMessage(_0x1ee7e5, "ID Telegram " + _0x1aae64 + " sudah ada di database resellersubdo kami.");
  }
  try {
    _0x410be8.push(_0x1aae64);
    await _0x1e6019();
    _0x3f7a03.sendMessage(_0x1ee7e5, "ID Telegram " + _0x1aae64 + " telah ditambahkan ke dalam sistem database resellersubdo kami!");
  } catch (_0x345d52) {
    console.error("Error saat menyimpan ke database:", _0x345d52);
    _0x3f7a03.sendMessage(_0x1ee7e5, "Terjadi kesalahan saat menyimpan data ke database. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/delresellersubdo (\d+)/, async (_0x23bed7, _0x358035) => {
  const _0x99518 = _0x23bed7.chat.id;
  const _0x5e359e = _0x358035[1];
  if (!_0x5e359e || isNaN(_0x5e359e)) {
    return _0x3f7a03.sendMessage(_0x99518, "Gunakan format /delresellersubdo idtelegram\nContoh: /delresellersubdo 2282727262");
  }
  if (!_0x410be8.includes(_0x5e359e)) {
    return _0x3f7a03.sendMessage(_0x99518, "ID Telegram " + _0x5e359e + " tidak ditemukan di database resellersubdo kami.");
  }
  try {
    const _0x4f0283 = _0x410be8.indexOf(_0x5e359e);
    if (_0x4f0283 > -1) {
      _0x410be8.splice(_0x4f0283, 1);
    }
    await _0x1e6019();
    _0x3f7a03.sendMessage(_0x99518, "ID Telegram " + _0x5e359e + " telah dihapus dari sistem database resellersubdo kami!");
  } catch (_0x268d0f) {
    console.error("Error saat menghapus dari database:", _0x268d0f);
    _0x3f7a03.sendMessage(_0x99518, "Terjadi kesalahan saat menghapus data dari database. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/play (.+)/, async (_0x1282f5, _0x3df5f5) => {
  const _0x5c58a0 = _0x1282f5.chat.id;
  const _0x2ba843 = _0x3df5f5[1];
  if (!_0x2ba843) {
    return _0x3f7a03.sendMessage(_0x5c58a0, "Contoh penggunaan:\n\n/play Pulang - Wali Band");
  }
  try {
    const _0x1aecba = await _0x388663(_0x2ba843);
    if (!_0x1aecba || _0x1aecba.all.length === 0) {
      return _0x3f7a03.sendMessage(_0x5c58a0, "Lagu yang Anda cari tidak ditemukan.");
    }
    const _0x104447 = _0x1aecba.videos[0];
    const _0x43ec39 = "\n🎵 **YouTube Audio Play** 🎶\n\n✨ **Judul Lagu**: " + _0x104447.title + "\n👁️‍🗨️ **Penonton**: " + _0x104447.views + "\n🎤 **Pengarang**: " + _0x104447.author.name + "\n📅 **Diunggah**: " + _0x104447.ago + "\n🔗 **Tonton Selengkapnya**: [Klik Disini](" + _0x104447.url + ")";
    await _0x3f7a03.sendMessage(_0x5c58a0, _0x43ec39, {
      parse_mode: "Markdown"
    });
    const _0x443aca = _0x10d57f(_0x104447.url, {
      filter: "audioonly"
    });
    _0x3f7a03.sendAudio(_0x5c58a0, _0x443aca, {
      caption: "Sekarang Memutar Musik"
    });
  } catch (_0x3eec6a) {
    console.error("Error:", _0x3eec6a.message);
    _0x3f7a03.sendMessage(_0x5c58a0, "Terjadi kesalahan saat memproses permintaan Anda.");
  }
});
const _0x23bf1f = 1668975729;
const _0x2101f7 = _0x5881c5 => {
  return _0x5881c5 + "\n\n---\n📌 Pesan dari bot";
};
_0x3f7a03.onText(/\/promote/, async _0x2535e9 => {
  if (_0x2535e9.from.id !== _0x23bf1f) {
    return _0x3f7a03.sendMessage(_0x2535e9.chat.id, _0x2101f7("❌ Anda tidak diotorisasi untuk menggunakan perintah ini."));
  }
  const _0x35e66d = _0x2535e9.reply_to_message;
  if (!_0x35e66d) {
    return _0x3f7a03.sendMessage(_0x2535e9.chat.id, _0x2101f7("❌ Harap membalas pesan untuk dipromosikan."));
  }
  let _0x55ca96 = 0;
  let _0x46d048 = 0;
  const _0x4ad8c4 = [123456789, 987654321, 1122334455];
  const _0x2af2d4 = _0x4ad8c4.length;
  const _0x506944 = await _0x3f7a03.sendMessage(_0x2535e9.chat.id, _0x2101f7("📤 Mulai promosi..."));
  for (const _0x4045a9 of _0x4ad8c4) {
    try {
      if (_0x35e66d.document) {
        const _0x69d145 = await _0x3f7a03.downloadFile(_0x35e66d.document.file_id, "./");
        await _0x3f7a03.sendDocument(_0x4045a9, _0x69d145, {
          caption: _0x2101f7(_0x35e66d.text)
        });
      } else {
        await _0x3f7a03.sendMessage(_0x4045a9, _0x2101f7(_0x35e66d.text));
      }
      _0x55ca96++;
    } catch (_0x21555c) {
      _0x46d048++;
      console.error("Gagal mengirim ke pengguna " + _0x4045a9 + ": " + _0x21555c.message);
    }
    const _0x23dfd0 = _0x55ca96 / _0x2af2d4 * 100;
    await _0x3f7a03.editMessageText(_0x2101f7("📤 Mengirim pesan... " + _0x23dfd0.toFixed(2) + "%\nTerkirim: " + _0x55ca96 + "\nGagal: " + _0x46d048), {
      chat_id: _0x506944.chat.id,
      message_id: _0x506944.message_id
    });
  }
  await _0x3f7a03.editMessageText(_0x2101f7("✅ Selesai mengirim pesan!\nTotal pengguna terkirim: " + _0x55ca96 + "\nTotal pengguna gagal: " + _0x46d048), {
    chat_id: _0x506944.chat.id,
    message_id: _0x506944.message_id
  });
});
const _0x3c57af = [-1002433763200];
const _0x432b27 = {};
_0x3f7a03.onText(/\/antilink (.+)/, async (_0x2ca794, _0x52ca4f) => {
  const _0x475407 = _0x2ca794.chat.id;
  const _0x46259e = _0x52ca4f[1]?.toLowerCase();
  if (_0x2ca794.chat.type !== "group" && _0x2ca794.chat.type !== "supergroup") {
    return _0x3f7a03.sendMessage(_0x475407, "Perintah ini hanya dapat dijalankan di grup.");
  }
  if (!_0x3c57af.includes(_0x475407)) {
    return _0x3f7a03.sendMessage(_0x475407, "Grup ini tidak diizinkan menggunakan fitur antilink.");
  }
  if (_0x46259e === "on") {
    _0x432b27[_0x475407] = true;
    _0x3f7a03.sendMessage(_0x475407, "Fitur antilink telah diaktifkan untuk grup ini.");
  } else if (_0x46259e === "off") {
    _0x432b27[_0x475407] = false;
    _0x3f7a03.sendMessage(_0x475407, "Fitur antilink telah dinonaktifkan untuk grup ini.");
  } else {
    _0x3f7a03.sendMessage(_0x475407, "Penggunaan: /antilink on atau /antilink off");
  }
});
_0x3f7a03.on("text", _0x2f1987 => {
  const _0x4b6f55 = _0x2f1987.chat.id;
  const _0x41717c = _0x2f1987.text;
  if (_0x432b27[_0x4b6f55] && /http|https|www\.|\.\w{2,}/.test(_0x41717c)) {
    _0x3f7a03.deleteMessage(_0x4b6f55, _0x2f1987.message_id).catch(_0x2dccbb => {
      console.error("Gagal menghapus pesan:", _0x2dccbb.message);
    });
    _0x3f7a03.sendMessage(_0x4b6f55, "Pesan yang mengandung tautan telah dihapus!. Fitur antilink sedang aktif.");
  }
});
const _0xad9a95 = async (_0x2ca604, _0x5c58f9) => {
  const _0x3245ef = await _0x1063a4({
    url: _0x2ca604,
    method: "GET",
    responseType: "stream"
  });
  return new Promise((_0x233588, _0x330478) => {
    _0x3245ef.data.pipe(_0x2230b1.createWriteStream(_0x5c58f9)).on("finish", () => _0x233588()).on("error", _0x5492c4 => _0x330478(_0x5492c4));
  });
};
_0x3f7a03.onText(/\/brat (.+)/, async (_0x176611, _0x453077) => {
  const _0x4a608f = _0x176611.chat.id;
  const _0x4538b8 = _0x453077[1];
  if (!_0x4538b8) {
    return _0x3f7a03.sendMessage(_0x4a608f, "Contoh penggunaan: /brat teksnya");
  }
  try {
    const _0x171382 = "https://kepolu-brat.hf.space/brat?q=" + encodeURIComponent(_0x4538b8);
    const _0x472065 = "./temp_sticker.webp";
    const _0x5854ff = async (_0x1ffa0a, _0x2ef242) => {
      const _0x32a308 = _0x2230b1.createWriteStream(_0x2ef242);
      const _0x1d5f82 = await _0x1063a4({
        url: _0x1ffa0a,
        method: "GET",
        responseType: "stream"
      });
      _0x1d5f82.data.pipe(_0x32a308);
      return new Promise((_0x45f9de, _0xc2ba9a) => {
        _0x32a308.on("finish", _0x45f9de);
        _0x32a308.on("error", _0xc2ba9a);
      });
    };
    await _0x5854ff(_0x171382, _0x472065);
    await _0x3f7a03.sendSticker(_0x4a608f, _0x472065);
    await _0x2230b1.promises.unlink(_0x472065);
  } catch (_0x1eafe4) {
    console.error(_0x1eafe4.message || _0x1eafe4);
    _0x3f7a03.sendMessage(_0x4a608f, "Terjadi kesalahan saat membuat stiker. Pastikan teks valid atau coba lagi.");
  }
});
_0x3f7a03.onText(/\/1gb (.+)/, async (_0x543219, _0x2265a3) => {
  const _0x2c2b4e = _0x543219.chat.id;
  const _0x3943ff = _0x2265a3[1];
  const _0x1f2044 = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x9db1e2 = _0x1f2044.includes(String(_0x543219.from.id));
  if (!_0x9db1e2) {
    _0x3f7a03.sendMessage(_0x2c2b4e, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x5eb526 = _0x3943ff.split(",");
  if (_0x5eb526.length < 2) {
    _0x3f7a03.sendMessage(_0x2c2b4e, "Invalid format. Usage: /1gb namapanel,idtele");
    return;
  }
  const _0x5b83d4 = _0x5eb526[0];
  const _0x3aee8e = _0x5eb526[1];
  const _0xe61a42 = _0x5b83d4 + "1gb";
  const _0x37a424 = _0x12cc77.eggs;
  const _0x1817bd = _0x12cc77.loc;
  const _0x6eabdc = "1024";
  const _0x342215 = "30";
  const _0x1d51ae = "1024";
  const _0x6dc806 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x52d4f1 = _0x5b83d4 + "@Fxyy.dev";
  const _0x58bd27 = _0x12cc77.pp;
  const _0x264dac = _0x5b83d4 + "001";
  let _0x15ab09;
  let _0x579361;
  try {
    const _0x4ae07c = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x52d4f1,
        username: _0x5b83d4,
        first_name: _0x5b83d4,
        last_name: _0x5b83d4,
        language: "en",
        password: _0x264dac
      })
    });
    const _0xe4f451 = await _0x4ae07c.json();
    if (_0xe4f451.errors) {
      if (_0xe4f451.errors[0].meta.rule === "unique" && _0xe4f451.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x2c2b4e, "Email already exists. Please use a different email.");
      } else {
        _0x3f7a03.sendMessage(_0x2c2b4e, "Error: " + JSON.stringify(_0xe4f451.errors[0], null, 2));
      }
      return;
    }
    _0x15ab09 = _0xe4f451.attributes;
    const _0x3e284b = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0xe61a42,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x15ab09.id,
        egg: parseInt(_0x37a424),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x6dc806,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x6eabdc,
          swap: 0,
          disk: _0x1d51ae,
          io: 500,
          cpu: _0x342215
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x1817bd)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x5969c6 = await _0x3e284b.json();
    _0x579361 = _0x5969c6.attributes;
  } catch (_0x322a2e) {
    _0x3f7a03.sendMessage(_0x2c2b4e, "Error: " + _0x322a2e.message);
  }
  if (_0x15ab09 && _0x579361) {
    _0x3f7a03.sendMessage(_0x2c2b4e, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x5b83d4 + "\nEMAIL: " + _0x52d4f1 + "\nID: " + _0x15ab09.id + "\nMEMORY: " + (_0x579361.limits.memory === 0 ? "Unlimited" : _0x579361.limits.memory) + " MB\nDISK: " + (_0x579361.limits.disk === 0 ? "Unlimited" : _0x579361.limits.disk) + " MB\nCPU: " + _0x579361.limits.cpu + "%");
    if (_0x58bd27) {
      _0x3f7a03.sendAnimation(_0x3aee8e, _0x58bd27, {
        caption: "Hai @" + _0x3aee8e + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x15ab09.username + "\n〽️ Password : " + _0x264dac + " \n┏━━━━━━━⬣\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallOffc"
      });
      _0x3f7a03.sendMessage(_0x2c2b4e, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x2c2b4e, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/2gb (.+)/, async (_0x53dd22, _0x3ae187) => {
  const _0x5ad60c = _0x53dd22.chat.id;
  const _0x562d78 = _0x3ae187[1];
  const _0x374494 = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x3c82a8 = _0x374494.includes(String(_0x53dd22.from.id));
  if (!_0x3c82a8) {
    _0x3f7a03.sendMessage(_0x5ad60c, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x5d95da = _0x562d78.split(",");
  if (_0x5d95da.length < 2) {
    _0x3f7a03.sendMessage(_0x5ad60c, "Invalid format. Usage: /2gb namapanel,idtele");
    return;
  }
  const _0x2da8c7 = _0x5d95da[0];
  const _0x51ce81 = _0x5d95da[1];
  const _0x32a3b2 = _0x2da8c7 + "2gb";
  const _0x4ea999 = _0x12cc77.eggs;
  const _0x4f3100 = _0x12cc77.loc;
  const _0x16fd63 = "2048";
  const _0x71d15c = "60";
  const _0x4697b4 = "2048";
  const _0x5398c5 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x36412d = _0x2da8c7 + "_" + _0x51ce81 + "@Fxyy.dev";
  const _0x14721c = _0x12cc77.pp;
  const _0x1e24db = _0x2da8c7 + "001";
  let _0x52cea0;
  let _0x156930;
  try {
    const _0x2fd878 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x36412d,
        username: _0x2da8c7,
        first_name: _0x2da8c7,
        last_name: _0x2da8c7,
        language: "en",
        password: _0x1e24db
      })
    });
    const _0x230429 = await _0x2fd878.json();
    if (_0x230429.errors) {
      if (_0x230429.errors[0].meta.rule === "unique" && _0x230429.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x5ad60c, "Email already exists. Please use a different email.");
      } else {
        _0x3f7a03.sendMessage(_0x5ad60c, "Error: " + JSON.stringify(_0x230429.errors[0], null, 2));
      }
      return;
    }
    _0x52cea0 = _0x230429.attributes;
    const _0x2742e3 = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0x32a3b2,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x52cea0.id,
        egg: parseInt(_0x4ea999),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x5398c5,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x16fd63,
          swap: 0,
          disk: _0x4697b4,
          io: 500,
          cpu: _0x71d15c
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x4f3100)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0xef7757 = await _0x2742e3.json();
    _0x156930 = _0xef7757.attributes;
  } catch (_0x4efcc4) {
    _0x3f7a03.sendMessage(_0x5ad60c, "Error: " + _0x4efcc4.message);
  }
  if (_0x52cea0 && _0x156930) {
    _0x3f7a03.sendMessage(_0x5ad60c, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x2da8c7 + "\nEMAIL: " + _0x36412d + "\nID: " + _0x52cea0.id + "\nMEMORY: " + (_0x156930.limits.memory === 0 ? "Unlimited" : _0x156930.limits.memory) + " MB\nDISK: " + (_0x156930.limits.disk === 0 ? "Unlimited" : _0x156930.limits.disk) + " MB\nCPU: " + _0x156930.limits.cpu + "%");
    if (_0x14721c) {
      _0x3f7a03.sendAnimation(_0x51ce81, _0x14721c, {
        caption: "Hai @" + _0x51ce81 + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x52cea0.username + "\n〽️ Password : " + _0x1e24db + " \n┏━━━━━━━⬣\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallOffc"
      });
      _0x3f7a03.sendMessage(_0x5ad60c, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x5ad60c, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/3gb (.+)/, async (_0xe17d62, _0x556f6d) => {
  const _0x20c194 = _0xe17d62.chat.id;
  const _0x527db1 = _0x556f6d[1];
  const _0x3c6278 = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x99fc04 = _0x3c6278.includes(String(_0xe17d62.from.id));
  if (!_0x99fc04) {
    _0x3f7a03.sendMessage(_0x20c194, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "@XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x184ab2 = _0x527db1.split(",");
  if (_0x184ab2.length < 2) {
    _0x3f7a03.sendMessage(_0x20c194, "Invalid format. Usage: /3gb2 namapanel,idtele");
    return;
  }
  const _0x5960c3 = _0x184ab2[0];
  const _0x36c85c = _0x184ab2[1];
  const _0x4a5d87 = _0x5960c3 + "3gb2";
  const _0x423410 = _0x12cc77.eggs;
  const _0x2e6414 = _0x12cc77.loc;
  const _0x15aa6e = "3072";
  const _0x44b41a = "90";
  const _0x3a6c7e = "3072";
  const _0x4bffc6 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x31c0e5 = _0x5960c3 + "@Fxyy.dev";
  const _0x3ff3f1 = _0x12cc77.pp;
  const _0x3ff32a = _0x5960c3 + "001";
  let _0x40a8f8;
  let _0x45f020;
  try {
    const _0x3c3d96 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x31c0e5,
        username: _0x5960c3,
        first_name: _0x5960c3,
        last_name: _0x5960c3,
        language: "en",
        password: _0x3ff32a
      })
    });
    const _0x2e1923 = await _0x3c3d96.json();
    if (_0x2e1923.errors) {
      if (_0x2e1923.errors[0].meta.rule === "unique" && _0x2e1923.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x20c194, "Email&user telah ada di data panel fxyy.");
      } else {
        _0x3f7a03.sendMessage(_0x20c194, "Error: " + JSON.stringify(_0x2e1923.errors[0], null, 2));
      }
      return;
    }
    _0x40a8f8 = _0x2e1923.attributes;
    const _0x5a3131 = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0x4a5d87,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x40a8f8.id,
        egg: parseInt(_0x423410),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x4bffc6,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x15aa6e,
          swap: 0,
          disk: _0x3a6c7e,
          io: 500,
          cpu: _0x44b41a
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x2e6414)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x45ae48 = await _0x5a3131.json();
    _0x45f020 = _0x45ae48.attributes;
  } catch (_0x559ae2) {
    _0x3f7a03.sendMessage(_0x20c194, "Error: " + _0x559ae2.message);
  }
  if (_0x40a8f8 && _0x45f020) {
    _0x3f7a03.sendMessage(_0x20c194, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x5960c3 + "\nEMAIL: " + _0x31c0e5 + "\nID: " + _0x40a8f8.id + "\nMEMORY: " + (_0x45f020.limits.memory === 0 ? "Unlimited" : _0x45f020.limits.memory) + " MB\nDISK: " + (_0x45f020.limits.disk === 0 ? "Unlimited" : _0x45f020.limits.disk) + " MB\nCPU: " + _0x45f020.limits.cpu + "%");
    if (_0x3ff3f1) {
      _0x3f7a03.sendAnimation(_0x36c85c, _0x3ff3f1, {
        caption: "Hai @" + _0x36c85c + "\n\nPANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x40a8f8.username + "\n〽️ Password : " + _0x3ff32a + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallOffc"
      });
      _0x3f7a03.sendMessage(_0x20c194, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x20c194, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/4gb (.+)/, async (_0x23573a, _0x147295) => {
  const _0x3784e1 = _0x23573a.chat.id;
  const _0x4501d9 = _0x147295[1];
  const _0x1c8285 = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x1e006a = _0x1c8285.includes(String(_0x23573a.from.id));
  if (!_0x1e006a) {
    _0x3f7a03.sendMessage(_0x3784e1, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "@XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x36409a = _0x4501d9.split(",");
  if (_0x36409a.length < 2) {
    _0x3f7a03.sendMessage(_0x3784e1, "Invalid format. Usage: /4gb namapanel,idtele");
    return;
  }
  const _0x8c6c64 = _0x36409a[0];
  const _0x59b959 = _0x36409a[1];
  const _0x2b77e9 = _0x8c6c64 + "4gb";
  const _0x5a4bbc = _0x12cc77.eggs;
  const _0x461fa4 = _0x12cc77.loc;
  const _0x21a101 = "4048";
  const _0x3cbe42 = "110";
  const _0x2fdce0 = "4048";
  const _0x3d2412 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x455aa3 = _0x8c6c64 + "@Fxyy.dev";
  const _0x3c65c7 = _0x12cc77.pp;
  const _0x36b561 = _0x8c6c64 + "001";
  let _0x17cdd5;
  let _0x7c0de2;
  try {
    const _0x3dded8 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x455aa3,
        username: _0x8c6c64,
        first_name: _0x8c6c64,
        last_name: _0x8c6c64,
        language: "en",
        password: _0x36b561
      })
    });
    const _0x26018a = await _0x3dded8.json();
    if (_0x26018a.errors) {
      if (_0x26018a.errors[0].meta.rule === "unique" && _0x26018a.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x3784e1, "Email already exists. Please use a different email.");
      } else {
        _0x3f7a03.sendMessage(_0x3784e1, "Error: " + JSON.stringify(_0x26018a.errors[0], null, 2));
      }
      return;
    }
    _0x17cdd5 = _0x26018a.attributes;
    const _0xd196bd = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0x2b77e9,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x17cdd5.id,
        egg: parseInt(_0x5a4bbc),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x3d2412,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x21a101,
          swap: 0,
          disk: _0x2fdce0,
          io: 500,
          cpu: _0x3cbe42
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x461fa4)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x17a92b = await _0xd196bd.json();
    _0x7c0de2 = _0x17a92b.attributes;
  } catch (_0x264469) {
    _0x3f7a03.sendMessage(_0x3784e1, "Error: " + _0x264469.message);
  }
  if (_0x17cdd5 && _0x7c0de2) {
    _0x3f7a03.sendMessage(_0x3784e1, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x8c6c64 + "\nEMAIL: " + _0x455aa3 + "\nID: " + _0x17cdd5.id + "\nMEMORY: " + (_0x7c0de2.limits.memory === 0 ? "Unlimited" : _0x7c0de2.limits.memory) + " MB\nDISK: " + (_0x7c0de2.limits.disk === 0 ? "Unlimited" : _0x7c0de2.limits.disk) + " MB\nCPU: " + _0x7c0de2.limits.cpu + "%");
    if (_0x3c65c7) {
      _0x3f7a03.sendAnimation(_0x59b959, _0x3c65c7, {
        caption: "Hai @" + _0x59b959 + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x17cdd5.username + "\n〽️ Password : " + _0x36b561 + " \n┏━━━━━━━⬣\n│ RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallOffc"
      });
      _0x3f7a03.sendMessage(_0x3784e1, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x3784e1, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/5gb (.+)/, async (_0x2d552a, _0xad5314) => {
  const _0x2c196b = _0x2d552a.chat.id;
  const _0x31b3fd = _0xad5314[1];
  const _0x18fbc0 = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x111ee7 = _0x18fbc0.includes(String(_0x2d552a.from.id));
  if (!_0x111ee7) {
    _0x3f7a03.sendMessage(_0x2c196b, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x13f0cc = _0x31b3fd.split(",");
  if (_0x13f0cc.length < 2) {
    _0x3f7a03.sendMessage(_0x2c196b, "Invalid format. Usage: /5gb2 namapanel,idtele");
    return;
  }
  const _0x42075e = _0x13f0cc[0];
  const _0xe27db2 = _0x13f0cc[1];
  const _0x121187 = _0x42075e + "5gb2";
  const _0x2096d9 = _0x12cc77.eggs;
  const _0x4d634b = _0x12cc77.loc;
  const _0xbc68fc = "5048";
  const _0x2e8ccb = "140";
  const _0x9736cf = "5048";
  const _0x4e4e4d = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x370b7a = _0x42075e + "@Fxyy.dev";
  const _0x20eae7 = _0x12cc77.pp;
  const _0x20011c = _0x42075e + "001";
  let _0x3311d6;
  let _0xf35b08;
  try {
    const _0x306880 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x370b7a,
        username: _0x42075e,
        first_name: _0x42075e,
        last_name: _0x42075e,
        language: "en",
        password: _0x20011c
      })
    });
    const _0x3b79ab = await _0x306880.json();
    if (_0x3b79ab.errors) {
      if (_0x3b79ab.errors[0].meta.rule === "unique" && _0x3b79ab.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x2c196b, "Email&user telah ada di panel — 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧.");
      } else {
        _0x3f7a03.sendMessage(_0x2c196b, "Error: " + JSON.stringify(_0x3b79ab.errors[0], null, 2));
      }
      return;
    }
    _0x3311d6 = _0x3b79ab.attributes;
    const _0x53dbce = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0x121187,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x3311d6.id,
        egg: parseInt(_0x2096d9),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x4e4e4d,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0xbc68fc,
          swap: 0,
          disk: _0x9736cf,
          io: 500,
          cpu: _0x2e8ccb
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x4d634b)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x59c226 = await _0x53dbce.json();
    _0xf35b08 = _0x59c226.attributes;
  } catch (_0x593d4f) {
    _0x3f7a03.sendMessage(_0x2c196b, "Error: " + _0x593d4f.message);
  }
  if (_0x3311d6 && _0xf35b08) {
    _0x3f7a03.sendMessage(_0x2c196b, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x42075e + "\nEMAIL: " + _0x370b7a + "\nID: " + _0x3311d6.id + "\nMEMORY: " + (_0xf35b08.limits.memory === 0 ? "Unlimited" : _0xf35b08.limits.memory) + " MB\nDISK: " + (_0xf35b08.limits.disk === 0 ? "Unlimited" : _0xf35b08.limits.disk) + " MB\nCPU: " + _0xf35b08.limits.cpu + "%");
    if (_0x20eae7) {
      _0x3f7a03.sendAnimation(_0xe27db2, _0x20eae7, {
        caption: "Hai @" + _0xe27db2 + "\n\nPANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x3311d6.username + "\n〽️ Password : " + _0x20011c + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallOffc"
      });
      _0x3f7a03.sendMessage(_0x2c196b, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x2c196b, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/6gb (.+)/, async (_0x2b4233, _0x8c9d39) => {
  const _0x38df8f = _0x2b4233.chat.id;
  const _0x5b2e0c = _0x8c9d39[1];
  const _0x4673cd = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x48ae6d = _0x4673cd.includes(String(_0x2b4233.from.id));
  if (!_0x48ae6d) {
    _0x3f7a03.sendMessage(_0x38df8f, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x3ed6b2 = _0x5b2e0c.split(",");
  if (_0x3ed6b2.length < 2) {
    _0x3f7a03.sendMessage(_0x38df8f, "Invalid format. Usage: /6gb2 namapanel,idtele");
    return;
  }
  const _0x574fd8 = _0x3ed6b2[0];
  const _0x35f085 = _0x3ed6b2[1];
  const _0x3dd780 = _0x574fd8 + "6gb2";
  const _0x489ee4 = _0x12cc77.eggs;
  const _0x1cd8fc = _0x12cc77.loc;
  const _0x3e6935 = "6048";
  const _0x12b3b7 = "170";
  const _0x3352da = "6048";
  const _0x1501c4 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x98c973 = _0x574fd8 + "@Fxyy.dev";
  const _0x3e10da = _0x12cc77.pp;
  const _0x5463d7 = _0x574fd8 + "001";
  let _0x36d286;
  let _0x3cb848;
  try {
    const _0x1a4e66 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x98c973,
        username: _0x574fd8,
        first_name: _0x574fd8,
        last_name: _0x574fd8,
        language: "en",
        password: _0x5463d7
      })
    });
    const _0x40cfd0 = await _0x1a4e66.json();
    if (_0x40cfd0.errors) {
      if (_0x40cfd0.errors[0].meta.rule === "unique" && _0x40cfd0.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x38df8f, "Email&user telah ada di panel — 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧.");
      } else {
        _0x3f7a03.sendMessage(_0x38df8f, "Error: " + JSON.stringify(_0x40cfd0.errors[0], null, 2));
      }
      return;
    }
    _0x36d286 = _0x40cfd0.attributes;
    const _0xc852ed = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0x3dd780,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x36d286.id,
        egg: parseInt(_0x489ee4),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x1501c4,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x3e6935,
          swap: 0,
          disk: _0x3352da,
          io: 500,
          cpu: _0x12b3b7
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x1cd8fc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x5b59c5 = await _0xc852ed.json();
    _0x3cb848 = _0x5b59c5.attributes;
  } catch (_0x11c6d4) {
    _0x3f7a03.sendMessage(_0x38df8f, "Error: " + _0x11c6d4.message);
  }
  if (_0x36d286 && _0x3cb848) {
    _0x3f7a03.sendMessage(_0x38df8f, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x574fd8 + "\nEMAIL: " + _0x98c973 + "\nID: " + _0x36d286.id + "\nMEMORY: " + (_0x3cb848.limits.memory === 0 ? "Unlimited" : _0x3cb848.limits.memory) + " MB\nDISK: " + (_0x3cb848.limits.disk === 0 ? "Unlimited" : _0x3cb848.limits.disk) + " MB\nCPU: " + _0x3cb848.limits.cpu + "%");
    if (_0x3e10da) {
      _0x3f7a03.sendAnimation(_0x35f085, _0x3e10da, {
        caption: "Hai @" + _0x35f085 + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x36d286.username + "\n〽️ Password : " + _0x5463d7 + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x38df8f, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x38df8f, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/7gb (.+)/, async (_0xa7f928, _0xcb4e00) => {
  const _0x5ccb03 = _0xa7f928.chat.id;
  const _0x1f60dd = _0xcb4e00[1];
  const _0x30fc74 = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x337e11 = _0x30fc74.includes(String(_0xa7f928.from.id));
  if (!_0x337e11) {
    _0x3f7a03.sendMessage(_0x5ccb03, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0xdfff94 = _0x1f60dd.split(",");
  if (_0xdfff94.length < 2) {
    _0x3f7a03.sendMessage(_0x5ccb03, "Invalid format. Usage: /7gb namapanel,idtele");
    return;
  }
  const _0x30536a = _0xdfff94[0];
  const _0x433798 = _0xdfff94[1];
  const _0xf060e = _0x30536a + "7gb";
  const _0x472c39 = _0x12cc77.eggs;
  const _0x334c09 = _0x12cc77.loc;
  const _0x413feb = "7048";
  const _0x426a06 = "200";
  const _0x41bb06 = "7048";
  const _0x4d1ab5 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x223969 = _0x30536a + "@Fxyy.dev";
  const _0x3ac0de = _0x12cc77.pp;
  const _0x1c3303 = _0x30536a + "001";
  let _0x4a4651;
  let _0x3d4519;
  try {
    const _0x5def21 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x223969,
        username: _0x30536a,
        first_name: _0x30536a,
        last_name: _0x30536a,
        language: "en",
        password: _0x1c3303
      })
    });
    const _0x132898 = await _0x5def21.json();
    if (_0x132898.errors) {
      if (_0x132898.errors[0].meta.rule === "unique" && _0x132898.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x5ccb03, "Email&user telah ada di panel — Falloffc.");
      } else {
        _0x3f7a03.sendMessage(_0x5ccb03, "Error: " + JSON.stringify(_0x132898.errors[0], null, 2));
      }
      return;
    }
    _0x4a4651 = _0x132898.attributes;
    const _0x39f7db = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0xf060e,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x4a4651.id,
        egg: parseInt(_0x472c39),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x4d1ab5,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x413feb,
          swap: 0,
          disk: _0x41bb06,
          io: 500,
          cpu: _0x426a06
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x334c09)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x1a7046 = await _0x39f7db.json();
    _0x3d4519 = _0x1a7046.attributes;
  } catch (_0x3c2847) {
    _0x3f7a03.sendMessage(_0x5ccb03, "Error: " + _0x3c2847.message);
  }
  if (_0x4a4651 && _0x3d4519) {
    _0x3f7a03.sendMessage(_0x5ccb03, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x30536a + "\nEMAIL: " + _0x223969 + "\nID: " + _0x4a4651.id + "\nMEMORY: " + (_0x3d4519.limits.memory === 0 ? "Unlimited" : _0x3d4519.limits.memory) + " MB\nDISK: " + (_0x3d4519.limits.disk === 0 ? "Unlimited" : _0x3d4519.limits.disk) + " MB\nCPU: " + _0x3d4519.limits.cpu + "%");
    if (_0x3ac0de) {
      _0x3f7a03.sendAnimation(_0x433798, _0x3ac0de, {
        caption: "Hai @" + _0x433798 + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x4a4651.username + "\n〽️ Password : " + _0x1c3303 + " \n┏━━━━━━━⬣\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x5ccb03, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x5ccb03, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/8gb (.+)/, async (_0xab030d, _0x489705) => {
  const _0x31f80b = _0xab030d.chat.id;
  const _0x56e5ed = _0x489705[1];
  const _0x5bc98a = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x2e7529 = _0x5bc98a.includes(String(_0xab030d.from.id));
  if (!_0x2e7529) {
    _0x3f7a03.sendMessage(_0x31f80b, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0xacc189 = _0x56e5ed.split(",");
  if (_0xacc189.length < 2) {
    _0x3f7a03.sendMessage(_0x31f80b, "Invalid format. Usage: /8gb2 namapanel,idtele");
    return;
  }
  const _0x2fa628 = _0xacc189[0];
  const _0x59d29a = _0xacc189[1];
  const _0xfef9e3 = _0x2fa628 + "8gb2";
  const _0x309afa = _0x12cc77.eggs;
  const _0x4a87cb = _0x12cc77.loc;
  const _0x51097a = "8048";
  const _0xa9a3cc = "230";
  const _0x124740 = "8048";
  const _0x2bd40d = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x541999 = _0x2fa628 + "@Fxyy.dev";
  const _0x3764f9 = _0x12cc77.pp;
  const _0x413b85 = _0x2fa628 + "001";
  let _0x1553a5;
  let _0x5bfbda;
  try {
    const _0x2f77f6 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x541999,
        username: _0x2fa628,
        first_name: _0x2fa628,
        last_name: _0x2fa628,
        language: "en",
        password: _0x413b85
      })
    });
    const _0x5d3048 = await _0x2f77f6.json();
    if (_0x5d3048.errors) {
      if (_0x5d3048.errors[0].meta.rule === "unique" && _0x5d3048.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x31f80b, "Email already exists. Please use a different email.");
      } else {
        _0x3f7a03.sendMessage(_0x31f80b, "Error: " + JSON.stringify(_0x5d3048.errors[0], null, 2));
      }
      return;
    }
    _0x1553a5 = _0x5d3048.attributes;
    const _0x42ddef = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0xfef9e3,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x1553a5.id,
        egg: parseInt(_0x309afa),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x2bd40d,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x51097a,
          swap: 0,
          disk: _0x124740,
          io: 500,
          cpu: _0xa9a3cc
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x4a87cb)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0xf317a3 = await _0x42ddef.json();
    _0x5bfbda = _0xf317a3.attributes;
  } catch (_0x2284af) {
    _0x3f7a03.sendMessage(_0x31f80b, "Error: " + _0x2284af.message);
  }
  if (_0x1553a5 && _0x5bfbda) {
    _0x3f7a03.sendMessage(_0x31f80b, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x2fa628 + "\nEMAIL: " + _0x541999 + "\nID: " + _0x1553a5.id + "\nMEMORY: " + (_0x5bfbda.limits.memory === 0 ? "Unlimited" : _0x5bfbda.limits.memory) + " MB\nDISK: " + (_0x5bfbda.limits.disk === 0 ? "Unlimited" : _0x5bfbda.limits.disk) + " MB\nCPU: " + _0x5bfbda.limits.cpu + "%");
    if (_0x3764f9) {
      _0x3f7a03.sendAnimation(_0x59d29a, _0x3764f9, {
        caption: "Hai @" + _0x59d29a + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x1553a5.username + "\n〽️ Password : " + _0x413b85 + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x31f80b, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x31f80b, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/9gb (.+)/, async (_0x52e3d2, _0x93cd22) => {
  const _0x1f4d82 = _0x52e3d2.chat.id;
  const _0x17e72b = _0x93cd22[1];
  const _0x3ed995 = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x49651a = _0x3ed995.includes(String(_0x52e3d2.from.id));
  if (!_0x49651a) {
    _0x3f7a03.sendMessage(_0x1f4d82, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Owner",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x1f1c4b = _0x17e72b.split(",");
  if (_0x1f1c4b.length < 2) {
    _0x3f7a03.sendMessage(_0x1f4d82, "ᴘᴇɴɢɢᴜɴᴀᴀɴ sᴀʟᴀʜ ᴋᴇᴛɪᴋ /ᴘᴀɴᴇʟ");
    return;
  }
  const _0x1f2101 = _0x1f1c4b[0];
  const _0x4149c1 = _0x1f1c4b[1];
  const _0x295116 = _0x1f2101 + "9gb";
  const _0x48d8c7 = _0x12cc77.eggs;
  const _0xf32894 = _0x12cc77.loc;
  const _0x3b4f33 = "9048";
  const _0x3a198e = "225";
  const _0x5ca5c8 = "9048";
  const _0x364dc3 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x452ad2 = _0x1f2101 + "panel@gmail.com";
  const _0x426a93 = _0x12cc77.pp;
  const _0x541442 = _0x1f2101 + "871";
  let _0x7e9760;
  let _0x590335;
  try {
    const _0x5731e9 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x452ad2,
        username: _0x1f2101,
        first_name: _0x1f2101,
        last_name: _0x1f2101,
        language: "en",
        password: _0x541442
      })
    });
    const _0x51683c = await _0x5731e9.json();
    if (_0x51683c.errors) {
      if (_0x51683c.errors[0].meta.rule === "unique" && _0x51683c.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x1f4d82, "ᴜsᴇʀɴᴀᴍᴇ sᴜᴅᴀʜ ᴀᴅᴀ, ɢᴀɴᴛɪ ᴅᴇɴɢᴀɴ ʏᴀɴɢ ʟᴀɪɴ.");
      } else {
        _0x3f7a03.sendMessage(_0x1f4d82, "Error: " + JSON.stringify(_0x51683c.errors[0], null, 2));
      }
      return;
    }
    _0x7e9760 = _0x51683c.attributes;
    const _0x5896dd = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0x295116,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x7e9760.id,
        egg: parseInt(_0x48d8c7),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x364dc3,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x3b4f33,
          swap: 0,
          disk: _0x5ca5c8,
          io: 500,
          cpu: _0x3a198e
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0xf32894)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x29a5ef = await _0x5896dd.json();
    _0x590335 = _0x29a5ef.attributes;
  } catch (_0x513e15) {
    _0x3f7a03.sendMessage(_0x1f4d82, "Error: " + _0x513e15.message);
  }
  if (_0x7e9760 && _0x590335) {
    _0x3f7a03.sendMessage(_0x1f4d82, "BERIKUT DATA PANEL ANDA\nᴜsᴇʀ: " + _0x1f2101 + "\nᴇᴍᴀɪʟ: " + _0x452ad2 + "\nɪᴅ: " + _0x7e9760.id + "\nʀᴀᴍ: " + (_0x590335.limits.memory === 0 ? "Unlimited" : _0x590335.limits.memory) + " MB\nᴅɪsᴋ: " + (_0x590335.limits.disk === 0 ? "Unlimited" : _0x590335.limits.disk) + " MB\nᴄᴘᴜ: " + _0x590335.limits.cpu + "%");
    if (_0x426a93) {
      _0x3f7a03.sendPhoto(_0x4149c1, _0x426a93, {
        caption: "Hai @" + _0x4149c1 + "\n\n\nPANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x7e9760.username + "\n〽️ Password : " + _0x541442 + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — XxzFallOffc"
      });
      _0x3f7a03.sendMessage(_0x1f4d82, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x1f4d82, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/10gb (.+)/, async (_0x36caa8, _0xed4e08) => {
  const _0x5aa97e = _0x36caa8.chat.id;
  const _0x57d0b8 = _0xed4e08[1];
  const _0x397d1b = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x5c0608 = _0x397d1b.includes(String(_0x36caa8.from.id));
  if (!_0x5c0608) {
    _0x3f7a03.sendMessage(_0x5aa97e, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Owner",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x202669 = _0x57d0b8.split(",");
  if (_0x202669.length < 2) {
    _0x3f7a03.sendMessage(_0x5aa97e, "ᴘᴇɴɢɢᴜɴᴀᴀɴ sᴀʟᴀʜ ᴋᴇᴛɪᴋ /ᴘᴀɴᴇʟ");
    return;
  }
  const _0x18c2a9 = _0x202669[0];
  const _0x25122b = _0x202669[1];
  const _0x41556c = _0x18c2a9 + "10gb2";
  const _0x4d19aa = _0x12cc77.eggs;
  const _0x59ccc0 = _0x12cc77.loc;
  const _0x4f5036 = "10000";
  const _0x5c3ca2 = "250";
  const _0xcef0dc = "10000";
  const _0x5cbedf = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x359e6c = _0x18c2a9 + "panel@gmail.com";
  const _0x3470b1 = _0x12cc77.pp;
  const _0xd9ed73 = _0x18c2a9 + "881";
  let _0x1a4f36;
  let _0x11bbe0;
  try {
    const _0x490dd2 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x359e6c,
        username: _0x18c2a9,
        first_name: _0x18c2a9,
        last_name: _0x18c2a9,
        language: "en",
        password: _0xd9ed73
      })
    });
    const _0x4e8819 = await _0x490dd2.json();
    if (_0x4e8819.errors) {
      if (_0x4e8819.errors[0].meta.rule === "unique" && _0x4e8819.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x5aa97e, "ᴜsᴇʀɴᴀᴍᴇ sᴜᴅᴀʜ ᴀᴅᴀ, ɢᴀɴᴛɪ ᴅᴇɴɢᴀɴ ʏᴀɴɢ ʟᴀɪɴ.");
      } else {
        _0x3f7a03.sendMessage(_0x5aa97e, "Error: " + JSON.stringify(_0x4e8819.errors[0], null, 2));
      }
      return;
    }
    _0x1a4f36 = _0x4e8819.attributes;
    const _0x41f71a = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0x41556c,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x1a4f36.id,
        egg: parseInt(_0x4d19aa),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x5cbedf,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x4f5036,
          swap: 0,
          disk: _0xcef0dc,
          io: 500,
          cpu: _0x5c3ca2
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x59ccc0)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x170663 = await _0x41f71a.json();
    _0x11bbe0 = _0x170663.attributes;
  } catch (_0x5b1618) {
    _0x3f7a03.sendMessage(_0x5aa97e, "Error: " + _0x5b1618.message);
  }
  if (_0x1a4f36 && _0x11bbe0) {
    _0x3f7a03.sendMessage(_0x5aa97e, "BERIKUT DATA PANEL ANDA\nɴᴀᴍᴀ: " + _0x18c2a9 + "\nᴇᴍᴀɪʟ: " + _0x359e6c + "\nɪᴅ:  " + _0x1a4f36.id + "\nʀᴀᴍ: " + (_0x11bbe0.limits.memory === 0 ? "Unlimited" : _0x11bbe0.limits.memory) + " MB\nᴅɪsᴋ: " + (_0x11bbe0.limits.disk === 0 ? "Unlimited" : _0x11bbe0.limits.disk) + " MB\nᴄᴘᴜ: " + _0x11bbe0.limits.cpu + "%");
    if (_0x3470b1) {
      _0x3f7a03.sendPhoto(_0x25122b, _0x3470b1, {
        caption: "Hai @" + _0x25122b + "\n\nPANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x1a4f36.username + "\n〽️ Password : " + _0xd9ed73 + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallOffc"
      });
      _0x3f7a03.sendMessage(_0x5aa97e, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x5aa97e, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/unli (.+)/, async (_0x50e439, _0xcb815e) => {
  const _0x49188a = _0x50e439.chat.id;
  const _0x3441c3 = _0xcb815e[1];
  const _0x92ec13 = JSON.parse(_0x2230b1.readFileSync(_0x734f29));
  const _0x13ea5f = _0x92ec13.includes(String(_0x50e439.from.id));
  if (!_0x13ea5f) {
    _0x3f7a03.sendMessage(_0x49188a, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0xbf66e0 = _0x3441c3.split(",");
  if (_0xbf66e0.length < 2) {
    _0x3f7a03.sendMessage(_0x49188a, "Invalid format. Usage: /unli namapanel,idtele");
    return;
  }
  const _0x42657c = _0xbf66e0[0];
  const _0x244b53 = _0xbf66e0[1];
  const _0x48d7e6 = _0x42657c + "unli";
  const _0x25db4e = _0x12cc77.eggs;
  const _0x412ce0 = _0x12cc77.loc;
  const _0x3cd698 = "0";
  const _0x35608b = "0";
  const _0x9bb43e = "0";
  const _0x4bfa95 = _0x42657c + "@Fxyy.dev";
  const _0x5350ab = _0x12cc77.pp;
  const _0x1ff057 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x27f2f1 = _0x42657c + "001";
  let _0x3e7632;
  let _0x25518b;
  try {
    const _0x19e14d = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0x4bfa95,
        username: _0x42657c,
        first_name: _0x42657c,
        last_name: _0x42657c,
        language: "en",
        password: _0x27f2f1
      })
    });
    const _0x494955 = await _0x19e14d.json();
    if (_0x494955.errors) {
      if (_0x494955.errors[0].meta.rule === "unique" && _0x494955.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x49188a, "Email&user telah ada di panel — 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧.");
      } else {
        _0x3f7a03.sendMessage(_0x49188a, "Error: " + JSON.stringify(_0x494955.errors[0], null, 2));
      }
      return;
    }
    _0x3e7632 = _0x494955.attributes;
    const _0xd40cad = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        name: _0x48d7e6,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x3e7632.id,
        egg: parseInt(_0x25db4e),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x1ff057,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x3cd698,
          swap: 0,
          disk: _0x9bb43e,
          io: 500,
          cpu: _0x35608b
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x412ce0)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0xd40415 = await _0xd40cad.json();
    _0x25518b = _0xd40415.attributes;
  } catch (_0x22a917) {
    _0x3f7a03.sendMessage(_0x49188a, "Error: " + _0x22a917.message);
  }
  if (_0x3e7632 && _0x25518b) {
    _0x3f7a03.sendMessage(_0x49188a, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x42657c + "\nEMAIL: " + _0x4bfa95 + "\nID: " + _0x3e7632.id + "\nMEMORY: " + (_0x25518b.limits.memory === 0 ? "Unlimited" : _0x25518b.limits.memory) + " MB\nDISK: " + (_0x25518b.limits.disk === 0 ? "Unlimited" : _0x25518b.limits.disk) + " MB\nCPU: " + _0x25518b.limits.cpu + "%");
    if (_0x5350ab) {
      _0x3f7a03.sendAnimation(_0x244b53, _0x5350ab, {
        caption: "Hai @" + _0x244b53 + "\n\nPANEL DATA ANDA :\n〽️ Login : " + _0xb62ec7 + "\n〽️ Username : " + _0x3e7632.username + "\n〽️ Password : " + _0x27f2f1 + " \n┏━━━━━━━⬣\nRULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallOffc"
      });
      _0x3f7a03.sendMessage(_0x49188a, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x49188a, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/clearserver2/, async _0x1325ba => {
  const _0xb63ed5 = _0x1325ba.chat.id;
  const _0x20b8f4 = "1849375880";
  if (_0x1325ba.from.id.toString() !== _0x20b8f4) {
    _0x3f7a03.sendMessage(_0xb63ed5, "Hanya pemilik bot yang dapat melakukan tindakan ini.");
    return;
  }
  try {
    const _0x52daff = await fetch(_0xb62ec7 + "./api/application/servers", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      }
    });
    const _0x5e6ad6 = await _0x52daff.json();
    const _0x2576b4 = _0x5e6ad6.data;
    if (!_0x2576b4 || _0x2576b4.length === 0) {
      _0x3f7a03.sendMessage(_0xb63ed5, "Tidak ada server yang ditemukan.");
      return;
    }
    for (const _0x3e6c58 of _0x2576b4) {
      const _0x8251a5 = _0x3e6c58.attributes.id;
      const _0x4cc16c = await fetch(_0xb62ec7 + ("./api/application/servers/" + _0x8251a5), {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + _0x549bc1
        }
      });
      if (_0x4cc16c.ok) {
        _0x3f7a03.sendMessage(_0xb63ed5, "*Berhasil menghapus server dengan ID: " + _0x8251a5 + "*");
      } else {
        const _0x85471 = await _0x4cc16c.text();
        _0x3f7a03.sendMessage(_0xb63ed5, "Gagal menghapus server dengan ID: " + _0x8251a5 + ". Error: " + _0x4cc16c.status + " - " + _0x85471);
      }
    }
    _0x3f7a03.sendMessage(_0xb63ed5, "*Semua server berhasil dihapus!*");
  } catch (_0x409468) {
    _0x3f7a03.sendMessage(_0xb63ed5, "Terjadi kesalahan: " + _0x409468.message);
  }
});
_0x3f7a03.onText(/\/clearuser2/, async _0x2fae12 => {
  const _0x33a6bf = _0x2fae12.chat.id;
  const _0x5a731b = _0x2fae12.from.id;
  const _0x2a2ce8 = 1849375880;
  if (_0x5a731b !== _0x2a2ce8) {
    return _0x3f7a03.sendMessage(_0x33a6bf, "Perintah ini hanya dapat dijalankan oleh pemilik.");
  }
  try {
    const _0x4a02b2 = await fetch(_0x206b50 + "/api/application/users", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey2
      }
    });
    if (!_0x4a02b2.ok) {
      throw new Error("Gagal mendapatkan data user. Status: " + _0x4a02b2.status);
    }
    const _0x25ec55 = await _0x4a02b2.json();
    const _0x14a946 = _0x25ec55.data;
    if (!_0x14a946 || _0x14a946.length === 0) {
      return _0x3f7a03.sendMessage(_0x33a6bf, "Tidak ada user yang ditemukan.");
    }
    for (const _0x3ac6a2 of _0x14a946) {
      const _0x4a7d47 = _0x3ac6a2.attributes;
      if (!_0x4a7d47.root_admin) {
        const _0x471ff7 = await fetch(_0x206b50 + "/api/application/users/" + _0x4a7d47.id, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey2
          }
        });
        if (_0x471ff7.ok) {
          _0x3f7a03.sendMessage(_0x33a6bf, "Berhasil menghapus user dengan ID: " + _0x4a7d47.id);
        } else {
          const _0x3e7c81 = await _0x471ff7.text();
          _0x3f7a03.sendMessage(_0x33a6bf, "Gagal menghapus user dengan ID: " + _0x4a7d47.id + ". Error: " + _0x471ff7.status + " - " + _0x3e7c81);
        }
      }
    }
    _0x3f7a03.sendMessage(_0x33a6bf, "Semua user kecuali admin berhasil dihapus!");
  } catch (_0x30c17e) {
    _0x3f7a03.sendMessage(_0x33a6bf, "Terjadi kesalahan: " + _0x30c17e.message);
  }
});
_0x3f7a03.onText(/\/listsrv2/, async _0x5164e4 => {
  const _0x49724b = _0x5164e4.chat.id;
  const _0x4762bb = _0x5164e4.from.id;
  const _0x3d1556 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x9380c = _0x3d1556.includes(String(_0x5164e4.from.id));
  if (!_0x9380c) {
    _0x3f7a03.sendMessage(_0x49724b, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧.", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  let _0x204daa = 1;
  try {
    let _0x2227fd = await fetch(_0x206b50 + "/api/application/servers?page=" + _0x204daa, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      }
    });
    let _0x1ae14d = await _0x2227fd.json();
    let _0x72a158 = _0x1ae14d.data;
    let _0x28ab70 = "Daftar server aktif yang dimiliki:\n\n";
    for (let _0x164845 of _0x72a158) {
      let _0x4a57ba = _0x164845.attributes;
      let _0x48af1d = await fetch(_0x206b50 + "/api/client/servers/" + _0x4a57ba.uuid.split("-")[0] + "/resources", {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + _0x549bc1
        }
      });
      let _0x23b2fa = await _0x48af1d.json();
      let _0x2f728f = _0x23b2fa.attributes ? _0x23b2fa.attributes.current_state : _0x4a57ba.status;
      _0x28ab70 += "ID Server: " + _0x4a57ba.id + "\n";
      _0x28ab70 += "Nama Server: " + _0x4a57ba.name + "\n";
      _0x28ab70 += "Status: " + _0x2f728f + "\n\n";
    }
    _0x3f7a03.sendMessage(_0x49724b, _0x28ab70);
  } catch (_0x27bc38) {
    console.error(_0x27bc38);
    _0x3f7a03.sendMessage(_0x49724b, "Terjadi kesalahan dalam memproses permintaan.");
  }
});
_0x3f7a03.onText(/\/listusr2/, async _0x209663 => {
  const _0x8b1127 = _0x209663.chat.id;
  const _0x369c0f = _0x209663.from.id;
  const _0x42350f = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x1be423 = _0x42350f.includes(String(_0x209663.from.id));
  if (!_0x1be423) {
    _0x3f7a03.sendMessage(_0x8b1127, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  let _0x44352a = "1";
  try {
    let _0x29e0a1 = await fetch(_0x206b50 + "/api/application/users?page=" + _0x44352a, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      }
    });
    let _0x372ce5 = await _0x29e0a1.json();
    let _0x35705c = _0x372ce5.data;
    let _0x241d5d = "Berikut daftar users aktif yang dimiliki :\n\n";
    for (let _0x409475 of _0x35705c) {
      let _0x37dbc7 = _0x409475.attributes;
      _0x241d5d += "\nID Users: " + _0x37dbc7.id;
      _0x241d5d += "\nName Users: " + _0x37dbc7.username;
    }
    _0x241d5d += "\nPage : " + _0x372ce5.meta.pagination.current_page + "/" + _0x372ce5.meta.pagination.total_pages + "\n";
    _0x241d5d += "Total User : " + _0x372ce5.meta.pagination.count;
    _0x3f7a03.sendMessage(_0x8b1127, _0x241d5d);
  } catch (_0x311c11) {
    console.error(_0x311c11);
    _0x3f7a03.sendMessage(_0x8b1127, "Terjadi kesalahan dalam memproses permintaan.");
  }
});
_0x3f7a03.onText(/^(\.|\#|\/)delsrv2$/, async _0x2e5332 => {
  const _0x4e56e2 = _0x2e5332.chat.id;
  _0x3f7a03.sendMessage(_0x4e56e2, "Format salah example delsrv2 id");
});
_0x3f7a03.onText(/\/delsrv (.+)/, async (_0x3ce95e, _0xa59b5c) => {
  const _0x158a2e = _0x3ce95e.chat.id;
  const _0x134fa6 = _0xa59b5c[1].trim();
  const _0x28f35d = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0xcd6bac = _0x28f35d.includes(String(_0x3ce95e.from.id));
  if (!_0xcd6bac) {
    _0x3f7a03.sendMessage(_0x158a2e, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  if (!_0x134fa6) {
    _0x3f7a03.sendMessage(_0x158a2e, "Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv2 1234");
    return;
  }
  try {
    let _0x169a5e = await fetch(_0xb62ec7 + "/api/application/servers/" + _0x134fa6, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      }
    });
    let _0x416ec9 = _0x169a5e.ok ? {
      errors: null
    } : await _0x169a5e.json();
    if (_0x416ec9.errors) {
      _0x3f7a03.sendMessage(_0x158a2e, "SERVER TIDAK ADA");
    } else {
      _0x3f7a03.sendMessage(_0x158a2e, "SUCCESFULLY DELETE SERVER");
    }
  } catch (_0x281bdb) {
    console.error(_0x281bdb);
    _0x3f7a03.sendMessage(_0x158a2e, "Terjadi kesalahan saat menghapus server.");
  }
});
_0x3f7a03.onText(/^(\.|\#|\/)deluser2$/, async _0x292027 => {
  const _0x47d4c0 = _0x292027.chat.id;
  _0x3f7a03.sendMessage(_0x47d4c0, "Format salah example delusr2 id yang akan di hapus");
});
_0x3f7a03.onText(/\/delusr2(.*)/, async (_0x55246c, _0x3959db) => {
  const _0x43d387 = _0x55246c.chat.id;
  const _0x56e113 = _0x3959db[1].trim();
  const _0x18e858 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x20b920 = _0x18e858.includes(String(_0x55246c.from.id));
  if (!_0x20b920) {
    _0x3f7a03.sendMessage(_0x43d387, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  if (!_0x56e113) {
    _0x3f7a03.sendMessage(_0x43d387, "Mohon masukkan ID server yang ingin dihapus, contoh: /delusr2 1");
    return;
  }
  try {
    let _0x41d380 = await fetch(_0x206b50 + "/api/application/users/" + _0x56e113, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      }
    });
    let _0x21946d = _0x41d380.ok ? {
      errors: null
    } : await _0x41d380.json();
    if (_0x21946d.errors) {
      _0x3f7a03.sendMessage(_0x43d387, "USER NOT FOUND");
    } else {
      _0x3f7a03.sendMessage(_0x43d387, "SUCCESSFULLY DELETE THE USER");
    }
  } catch (_0xc64ea2) {
    console.error(_0xc64ea2);
    _0x3f7a03.sendMessage(_0x43d387, "Terjadi kesalahan saat menghapus server.");
  }
});
_0x3f7a03.onText(/\/1gb2 (.+)/, async (_0x2bb87a, _0x1eaba0) => {
  const _0x4e18bd = _0x2bb87a.chat.id;
  const _0x4788a2 = _0x1eaba0[1];
  const _0x242458 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x5df0ca = _0x242458.includes(String(_0x2bb87a.from.id));
  if (!_0x5df0ca) {
    _0x3f7a03.sendMessage(_0x4e18bd, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x18bc5a = _0x4788a2.split(",");
  if (_0x18bc5a.length < 2) {
    _0x3f7a03.sendMessage(_0x4e18bd, "Invalid format. Usage: /1gb2 namapanel,idtele");
    return;
  }
  const _0x5eb2fa = _0x18bc5a[0];
  const _0x33296c = _0x18bc5a[1];
  const _0x194da7 = _0x5eb2fa + "1gb2";
  const _0x2690b5 = _0x12cc77.eggs;
  const _0xc11c93 = _0x12cc77.loc;
  const _0x5a0c11 = "1024";
  const _0x49dd3b = "30";
  const _0x272981 = "1024";
  const _0x26e261 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x16882f = _0x5eb2fa + "@Fxyy.dev";
  const _0x182e16 = _0x12cc77.pp;
  const _0x31c22b = _0x5eb2fa + "001";
  let _0x24aa8f;
  let _0x157815;
  try {
    const _0x291bd9 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x16882f,
        username: _0x5eb2fa,
        first_name: _0x5eb2fa,
        last_name: _0x5eb2fa,
        language: "en",
        password: _0x31c22b
      })
    });
    const _0x8aaa54 = await _0x291bd9.json();
    if (_0x8aaa54.errors) {
      if (_0x8aaa54.errors[0].meta.rule === "unique" && _0x8aaa54.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x4e18bd, "Email already exists. Please use a different email.");
      } else {
        _0x3f7a03.sendMessage(_0x4e18bd, "Error: " + JSON.stringify(_0x8aaa54.errors[0], null, 2));
      }
      return;
    }
    _0x24aa8f = _0x8aaa54.attributes;
    const _0x263089 = await fetch(_0xb62ec7 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x194da7,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x24aa8f.id,
        egg: parseInt(_0x2690b5),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x26e261,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x5a0c11,
          swap: 0,
          disk: _0x272981,
          io: 500,
          cpu: _0x49dd3b
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0xc11c93)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x1462e3 = await _0x263089.json();
    _0x157815 = _0x1462e3.attributes;
  } catch (_0x4d9a80) {
    _0x3f7a03.sendMessage(_0x4e18bd, "Error: " + _0x4d9a80.message);
  }
  if (_0x24aa8f && _0x157815) {
    _0x3f7a03.sendMessage(_0x4e18bd, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x5eb2fa + "\nEMAIL: " + _0x16882f + "\nID: " + _0x24aa8f.id + "\nMEMORY: " + (_0x157815.limits.memory === 0 ? "Unlimited" : _0x157815.limits.memory) + " MB\nDISK: " + (_0x157815.limits.disk === 0 ? "Unlimited" : _0x157815.limits.disk) + " MB\nCPU: " + _0x157815.limits.cpu + "%");
    if (_0x182e16) {
      _0x3f7a03.sendAnimation(_0x33296c, _0x182e16, {
        caption: "Hai @" + _0x33296c + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x24aa8f.username + "\n〽️ Password : " + _0x31c22b + " \n┏━━━━━━━⬣\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — XxzFallOffc"
      });
      _0x3f7a03.sendMessage(_0x4e18bd, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x4e18bd, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/2gb2 (.+)/, async (_0x2a046e, _0x43733f) => {
  const _0x3b01b7 = _0x2a046e.chat.id;
  const _0x425d6f = _0x43733f[1];
  const _0x5af310 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x407be1 = _0x5af310.includes(String(_0x2a046e.from.id));
  if (!_0x407be1) {
    _0x3f7a03.sendMessage(_0x3b01b7, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0xbca27c = _0x425d6f.split(",");
  if (_0xbca27c.length < 2) {
    _0x3f7a03.sendMessage(_0x3b01b7, "Invalid format. Usage: /2gb2 namapanel,idtele");
    return;
  }
  const _0x925c06 = _0xbca27c[0];
  const _0x4f410d = _0xbca27c[1];
  const _0x5c1193 = _0x925c06 + "2gb2";
  const _0x59e101 = _0x12cc77.eggs;
  const _0x48f838 = _0x12cc77.loc;
  const _0x27e87c = "2048";
  const _0x58722c = "60";
  const _0x5d6ded = "2048";
  const _0x46aca4 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x35daa0 = _0x925c06 + "_" + _0x4f410d + "@Fxyy.dev";
  const _0x48677b = _0x12cc77.pp;
  const _0x196fba = _0x925c06 + "001";
  let _0x55316c;
  let _0x34ba21;
  try {
    const _0x2f936f = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x35daa0,
        username: _0x925c06,
        first_name: _0x925c06,
        last_name: _0x925c06,
        language: "en",
        password: _0x196fba
      })
    });
    const _0x16f2e5 = await _0x2f936f.json();
    if (_0x16f2e5.errors) {
      if (_0x16f2e5.errors[0].meta.rule === "unique" && _0x16f2e5.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x3b01b7, "Email already exists. Please use a different email.");
      } else {
        _0x3f7a03.sendMessage(_0x3b01b7, "Error: " + JSON.stringify(_0x16f2e5.errors[0], null, 2));
      }
      return;
    }
    _0x55316c = _0x16f2e5.attributes;
    const _0x4cd49f = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x5c1193,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x55316c.id,
        egg: parseInt(_0x59e101),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x46aca4,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x27e87c,
          swap: 0,
          disk: _0x5d6ded,
          io: 500,
          cpu: _0x58722c
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x48f838)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0xdeeff3 = await _0x4cd49f.json();
    _0x34ba21 = _0xdeeff3.attributes;
  } catch (_0x593745) {
    _0x3f7a03.sendMessage(_0x3b01b7, "Error: " + _0x593745.message);
  }
  if (_0x55316c && _0x34ba21) {
    _0x3f7a03.sendMessage(_0x3b01b7, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x925c06 + "\nEMAIL: " + _0x35daa0 + "\nID: " + _0x55316c.id + "\nMEMORY: " + (_0x34ba21.limits.memory === 0 ? "Unlimited" : _0x34ba21.limits.memory) + " MB\nDISK: " + (_0x34ba21.limits.disk === 0 ? "Unlimited" : _0x34ba21.limits.disk) + " MB\nCPU: " + _0x34ba21.limits.cpu + "%");
    if (_0x48677b) {
      _0x3f7a03.sendAnimation(_0x4f410d, _0x48677b, {
        caption: "Hai @" + _0x4f410d + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x55316c.username + "\n〽️ Password : " + _0x196fba + " \n┏━━━━━━━⬣\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x3b01b7, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x3b01b7, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/3gb (.+)/, async (_0x3cf31a, _0x4bc0c0) => {
  const _0x33f9db = _0x3cf31a.chat.id;
  const _0x1b1c22 = _0x4bc0c0[1];
  const _0x1b3028 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x5b2e10 = _0x1b3028.includes(String(_0x3cf31a.from.id));
  if (!_0x5b2e10) {
    _0x3f7a03.sendMessage(_0x33f9db, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "@XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x1934d3 = _0x1b1c22.split(",");
  if (_0x1934d3.length < 2) {
    _0x3f7a03.sendMessage(_0x33f9db, "Invalid format. Usage: /3gb namapanel,idtele");
    return;
  }
  const _0x560e30 = _0x1934d3[0];
  const _0x4edcc8 = _0x1934d3[1];
  const _0x2f9cf7 = _0x560e30 + "3gb";
  const _0x4e423d = _0x12cc77.eggs;
  const _0x28c726 = _0x12cc77.loc;
  const _0x303bc1 = "3072";
  const _0x552f5d = "90";
  const _0x13a470 = "3072";
  const _0x3b035a = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x2589cb = _0x560e30 + "@Fxyy.dev";
  const _0x4c0a4e = _0x12cc77.pp;
  const _0x112d0a = _0x560e30 + "001";
  let _0x19a63e;
  let _0x5a5f1c;
  try {
    const _0x3576b0 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x2589cb,
        username: _0x560e30,
        first_name: _0x560e30,
        last_name: _0x560e30,
        language: "en",
        password: _0x112d0a
      })
    });
    const _0x45a2f5 = await _0x3576b0.json();
    if (_0x45a2f5.errors) {
      if (_0x45a2f5.errors[0].meta.rule === "unique" && _0x45a2f5.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x33f9db, "Email&user telah ada di data panel — 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧.");
      } else {
        _0x3f7a03.sendMessage(_0x33f9db, "Error: " + JSON.stringify(_0x45a2f5.errors[0], null, 2));
      }
      return;
    }
    _0x19a63e = _0x45a2f5.attributes;
    const _0x13994f = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x2f9cf7,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x19a63e.id,
        egg: parseInt(_0x4e423d),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x3b035a,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x303bc1,
          swap: 0,
          disk: _0x13a470,
          io: 500,
          cpu: _0x552f5d
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x28c726)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x2fd188 = await _0x13994f.json();
    _0x5a5f1c = _0x2fd188.attributes;
  } catch (_0x1769dd) {
    _0x3f7a03.sendMessage(_0x33f9db, "Error: " + _0x1769dd.message);
  }
  if (_0x19a63e && _0x5a5f1c) {
    _0x3f7a03.sendMessage(_0x33f9db, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x560e30 + "\nEMAIL: " + _0x2589cb + "\nID: " + _0x19a63e.id + "\nMEMORY: " + (_0x5a5f1c.limits.memory === 0 ? "Unlimited" : _0x5a5f1c.limits.memory) + " MB\nDISK: " + (_0x5a5f1c.limits.disk === 0 ? "Unlimited" : _0x5a5f1c.limits.disk) + " MB\nCPU: " + _0x5a5f1c.limits.cpu + "%");
    if (_0x4c0a4e) {
      _0x3f7a03.sendAnimation(_0x4edcc8, _0x4c0a4e, {
        caption: "Hai @" + _0x4edcc8 + "\n\nPANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x19a63e.username + "\n〽️ Password : " + _0x112d0a + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x33f9db, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x33f9db, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/4gb2 (.+)/, async (_0x358262, _0xb08a1c) => {
  const _0x4ebaa7 = _0x358262.chat.id;
  const _0x37f408 = _0xb08a1c[1];
  const _0x53bada = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x5dc8d1 = _0x53bada.includes(String(_0x358262.from.id));
  if (!_0x5dc8d1) {
    _0x3f7a03.sendMessage(_0x4ebaa7, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "@XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x589b96 = _0x37f408.split(",");
  if (_0x589b96.length < 2) {
    _0x3f7a03.sendMessage(_0x4ebaa7, "Invalid format. Usage: /4gb2 namapanel,idtele");
    return;
  }
  const _0x1a34ab = _0x589b96[0];
  const _0x3d4758 = _0x589b96[1];
  const _0x1f5a8a = _0x1a34ab + "4gb2";
  const _0x3ee122 = _0x12cc77.eggs;
  const _0x41524f = _0x12cc77.loc;
  const _0x2f6676 = "4048";
  const _0x3b4bdc = "110";
  const _0x40ce62 = "4048";
  const _0x341ac7 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x5edfb6 = _0x1a34ab + "@Fxyy.dev";
  const _0x5711f8 = _0x12cc77.pp;
  const _0x45888b = _0x1a34ab + "001";
  let _0xf4080f;
  let _0x268103;
  try {
    const _0x386b09 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x5edfb6,
        username: _0x1a34ab,
        first_name: _0x1a34ab,
        last_name: _0x1a34ab,
        language: "en",
        password: _0x45888b
      })
    });
    const _0x4cdb9d = await _0x386b09.json();
    if (_0x4cdb9d.errors) {
      if (_0x4cdb9d.errors[0].meta.rule === "unique" && _0x4cdb9d.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x4ebaa7, "Email already exists. Please use a different email.");
      } else {
        _0x3f7a03.sendMessage(_0x4ebaa7, "Error: " + JSON.stringify(_0x4cdb9d.errors[0], null, 2));
      }
      return;
    }
    _0xf4080f = _0x4cdb9d.attributes;
    const _0x5ecba0 = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x1f5a8a,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0xf4080f.id,
        egg: parseInt(_0x3ee122),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x341ac7,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x2f6676,
          swap: 0,
          disk: _0x40ce62,
          io: 500,
          cpu: _0x3b4bdc
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x41524f)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x5ea7a9 = await _0x5ecba0.json();
    _0x268103 = _0x5ea7a9.attributes;
  } catch (_0x3747c4) {
    _0x3f7a03.sendMessage(_0x4ebaa7, "Error: " + _0x3747c4.message);
  }
  if (_0xf4080f && _0x268103) {
    _0x3f7a03.sendMessage(_0x4ebaa7, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x1a34ab + "\nEMAIL: " + _0x5edfb6 + "\nID: " + _0xf4080f.id + "\nMEMORY: " + (_0x268103.limits.memory === 0 ? "Unlimited" : _0x268103.limits.memory) + " MB\nDISK: " + (_0x268103.limits.disk === 0 ? "Unlimited" : _0x268103.limits.disk) + " MB\nCPU: " + _0x268103.limits.cpu + "%");
    if (_0x5711f8) {
      _0x3f7a03.sendAnimation(_0x3d4758, _0x5711f8, {
        caption: "Hai @" + _0x3d4758 + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0xf4080f.username + "\n〽️ Password : " + _0x45888b + " \n┏━━━━━━━⬣\n│ RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x4ebaa7, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x4ebaa7, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/5gb2 (.+)/, async (_0x4eb7d1, _0x1a3bf7) => {
  const _0x2ac9cf = _0x4eb7d1.chat.id;
  const _0x42c9de = _0x1a3bf7[1];
  const _0x1974e8 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x653541 = _0x1974e8.includes(String(_0x4eb7d1.from.id));
  if (!_0x653541) {
    _0x3f7a03.sendMessage(_0x2ac9cf, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x119853 = _0x42c9de.split(",");
  if (_0x119853.length < 2) {
    _0x3f7a03.sendMessage(_0x2ac9cf, "Invalid format. Usage: /5gb namapanel,idtele");
    return;
  }
  const _0x7d9a6f = _0x119853[0];
  const _0x1c3bd2 = _0x119853[1];
  const _0x4976b6 = _0x7d9a6f + "5gb";
  const _0x3f7945 = _0x12cc77.eggs;
  const _0x39b53a = _0x12cc77.loc;
  const _0x50a3a6 = "5048";
  const _0x11c0f8 = "140";
  const _0x412e13 = "5048";
  const _0x2b9c0b = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x223344 = _0x7d9a6f + "@Fxyy.dev";
  const _0x4543b7 = _0x12cc77.pp;
  const _0x525523 = _0x7d9a6f + "001";
  let _0xe6c86b;
  let _0xf3ffd8;
  try {
    const _0x9b98ab = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x223344,
        username: _0x7d9a6f,
        first_name: _0x7d9a6f,
        last_name: _0x7d9a6f,
        language: "en",
        password: _0x525523
      })
    });
    const _0x178908 = await _0x9b98ab.json();
    if (_0x178908.errors) {
      if (_0x178908.errors[0].meta.rule === "unique" && _0x178908.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x2ac9cf, "Email&user telah ada di panel — 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧.");
      } else {
        _0x3f7a03.sendMessage(_0x2ac9cf, "Error: " + JSON.stringify(_0x178908.errors[0], null, 2));
      }
      return;
    }
    _0xe6c86b = _0x178908.attributes;
    const _0x4baabb = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x4976b6,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0xe6c86b.id,
        egg: parseInt(_0x3f7945),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x2b9c0b,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x50a3a6,
          swap: 0,
          disk: _0x412e13,
          io: 500,
          cpu: _0x11c0f8
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x39b53a)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x466af2 = await _0x4baabb.json();
    _0xf3ffd8 = _0x466af2.attributes;
  } catch (_0x41a3f7) {
    _0x3f7a03.sendMessage(_0x2ac9cf, "Error: " + _0x41a3f7.message);
  }
  if (_0xe6c86b && _0xf3ffd8) {
    _0x3f7a03.sendMessage(_0x2ac9cf, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x7d9a6f + "\nEMAIL: " + _0x223344 + "\nID: " + _0xe6c86b.id + "\nMEMORY: " + (_0xf3ffd8.limits.memory === 0 ? "Unlimited" : _0xf3ffd8.limits.memory) + " MB\nDISK: " + (_0xf3ffd8.limits.disk === 0 ? "Unlimited" : _0xf3ffd8.limits.disk) + " MB\nCPU: " + _0xf3ffd8.limits.cpu + "%");
    if (_0x4543b7) {
      _0x3f7a03.sendAnimation(_0x1c3bd2, _0x4543b7, {
        caption: "Hai @" + _0x1c3bd2 + "\n\nPANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0xe6c86b.username + "\n〽️ Password : " + _0x525523 + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x2ac9cf, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x2ac9cf, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/6gb2 (.+)/, async (_0x6efc10, _0x1d8eee) => {
  const _0x51dc40 = _0x6efc10.chat.id;
  const _0x518a5b = _0x1d8eee[1];
  const _0x16b208 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x13482c = _0x16b208.includes(String(_0x6efc10.from.id));
  if (!_0x13482c) {
    _0x3f7a03.sendMessage(_0x51dc40, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x3dc3c1 = _0x518a5b.split(",");
  if (_0x3dc3c1.length < 2) {
    _0x3f7a03.sendMessage(_0x51dc40, "Invalid format. Usage: /6gb namapanel,idtele");
    return;
  }
  const _0x578a55 = _0x3dc3c1[0];
  const _0x381edc = _0x3dc3c1[1];
  const _0x2877ec = _0x578a55 + "6gb";
  const _0x2da82e = _0x12cc77.eggs;
  const _0x149bdd = _0x12cc77.loc;
  const _0xa95767 = "6048";
  const _0x524f32 = "170";
  const _0x234956 = "6048";
  const _0x4ebe4c = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x39e991 = _0x578a55 + "@Fxyy.dev";
  const _0x588cd2 = _0x12cc77.pp;
  const _0x2654b4 = _0x578a55 + "001";
  let _0x3c83a5;
  let _0x3ab34f;
  try {
    const _0x5162e8 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x39e991,
        username: _0x578a55,
        first_name: _0x578a55,
        last_name: _0x578a55,
        language: "en",
        password: _0x2654b4
      })
    });
    const _0x1a63e3 = await _0x5162e8.json();
    if (_0x1a63e3.errors) {
      if (_0x1a63e3.errors[0].meta.rule === "unique" && _0x1a63e3.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x51dc40, "Email&user telah ada di panel — FallOffc.");
      } else {
        _0x3f7a03.sendMessage(_0x51dc40, "Error: " + JSON.stringify(_0x1a63e3.errors[0], null, 2));
      }
      return;
    }
    _0x3c83a5 = _0x1a63e3.attributes;
    const _0x5a542e = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x2877ec,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x3c83a5.id,
        egg: parseInt(_0x2da82e),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x4ebe4c,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0xa95767,
          swap: 0,
          disk: _0x234956,
          io: 500,
          cpu: _0x524f32
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x149bdd)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x693450 = await _0x5a542e.json();
    _0x3ab34f = _0x693450.attributes;
  } catch (_0x4a74cc) {
    _0x3f7a03.sendMessage(_0x51dc40, "Error: " + _0x4a74cc.message);
  }
  if (_0x3c83a5 && _0x3ab34f) {
    _0x3f7a03.sendMessage(_0x51dc40, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x578a55 + "\nEMAIL: " + _0x39e991 + "\nID: " + _0x3c83a5.id + "\nMEMORY: " + (_0x3ab34f.limits.memory === 0 ? "Unlimited" : _0x3ab34f.limits.memory) + " MB\nDISK: " + (_0x3ab34f.limits.disk === 0 ? "Unlimited" : _0x3ab34f.limits.disk) + " MB\nCPU: " + _0x3ab34f.limits.cpu + "%");
    if (_0x588cd2) {
      _0x3f7a03.sendAnimation(_0x381edc, _0x588cd2, {
        caption: "Hai @" + _0x381edc + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x3c83a5.username + "\n〽️ Password : " + _0x2654b4 + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x51dc40, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x51dc40, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/7gb2 (.+)/, async (_0x4da338, _0x42aaee) => {
  const _0x59f48d = _0x4da338.chat.id;
  const _0x37f1e9 = _0x42aaee[1];
  const _0x3d3f65 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x15dbb9 = _0x3d3f65.includes(String(_0x4da338.from.id));
  if (!_0x15dbb9) {
    _0x3f7a03.sendMessage(_0x59f48d, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x2e5ba9 = _0x37f1e9.split(",");
  if (_0x2e5ba9.length < 2) {
    _0x3f7a03.sendMessage(_0x59f48d, "Invalid format. Usage: /7gb2 namapanel,idtele");
    return;
  }
  const _0x360044 = _0x2e5ba9[0];
  const _0x58930a = _0x2e5ba9[1];
  const _0x52e89a = _0x360044 + "7gb2";
  const _0x54db21 = _0x12cc77.eggs;
  const _0x56fb18 = _0x12cc77.loc;
  const _0x20b0f2 = "7048";
  const _0x48ca1e = "200";
  const _0x8f644c = "7048";
  const _0xa3b585 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x524c09 = _0x360044 + "@Fxyy.dev";
  const _0x355f51 = _0x12cc77.pp;
  const _0x3f2a62 = _0x360044 + "001";
  let _0x33b10d;
  let _0x3ed30f;
  try {
    const _0x2aa05d = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x524c09,
        username: _0x360044,
        first_name: _0x360044,
        last_name: _0x360044,
        language: "en",
        password: _0x3f2a62
      })
    });
    const _0xaef052 = await _0x2aa05d.json();
    if (_0xaef052.errors) {
      if (_0xaef052.errors[0].meta.rule === "unique" && _0xaef052.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x59f48d, "Email&user telah ada di panel — 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧.");
      } else {
        _0x3f7a03.sendMessage(_0x59f48d, "Error: " + JSON.stringify(_0xaef052.errors[0], null, 2));
      }
      return;
    }
    _0x33b10d = _0xaef052.attributes;
    const _0x3e1a2d = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x52e89a,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x33b10d.id,
        egg: parseInt(_0x54db21),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0xa3b585,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x20b0f2,
          swap: 0,
          disk: _0x8f644c,
          io: 500,
          cpu: _0x48ca1e
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x56fb18)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x5dfcbd = await _0x3e1a2d.json();
    _0x3ed30f = _0x5dfcbd.attributes;
  } catch (_0x432ced) {
    _0x3f7a03.sendMessage(_0x59f48d, "Error: " + _0x432ced.message);
  }
  if (_0x33b10d && _0x3ed30f) {
    _0x3f7a03.sendMessage(_0x59f48d, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x360044 + "\nEMAIL: " + _0x524c09 + "\nID: " + _0x33b10d.id + "\nMEMORY: " + (_0x3ed30f.limits.memory === 0 ? "Unlimited" : _0x3ed30f.limits.memory) + " MB\nDISK: " + (_0x3ed30f.limits.disk === 0 ? "Unlimited" : _0x3ed30f.limits.disk) + " MB\nCPU: " + _0x3ed30f.limits.cpu + "%");
    if (_0x355f51) {
      _0x3f7a03.sendAnimation(_0x58930a, _0x355f51, {
        caption: "Hai @" + _0x58930a + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x33b10d.username + "\n〽️ Password : " + _0x3f2a62 + " \n┏━━━━━━━⬣\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — XxzFallOffc "
      });
      _0x3f7a03.sendMessage(_0x59f48d, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x59f48d, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/8gb2 (.+)/, async (_0x5fc545, _0x2b4d7e) => {
  const _0x3de178 = _0x5fc545.chat.id;
  const _0x128a4d = _0x2b4d7e[1];
  const _0x42e616 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x41c38a = _0x42e616.includes(String(_0x5fc545.from.id));
  if (!_0x41c38a) {
    _0x3f7a03.sendMessage(_0x3de178, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x27e806 = _0x128a4d.split(",");
  if (_0x27e806.length < 2) {
    _0x3f7a03.sendMessage(_0x3de178, "Invalid format. Usage: /8gb namapanel,idtele");
    return;
  }
  const _0x10c426 = _0x27e806[0];
  const _0x398f98 = _0x27e806[1];
  const _0x5441c5 = _0x10c426 + "8gb";
  const _0x49418d = _0x12cc77.eggs;
  const _0x206874 = _0x12cc77.loc;
  const _0x41932c = "8048";
  const _0xe5f94 = "230";
  const _0x461bee = "8048";
  const _0x27206c = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x1016e1 = _0x10c426 + "@Fxyy.dev";
  const _0x30d06a = _0x12cc77.pp;
  const _0x239bd8 = _0x10c426 + "001";
  let _0x52df0c;
  let _0xc8aef8;
  try {
    const _0x3452a5 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x1016e1,
        username: _0x10c426,
        first_name: _0x10c426,
        last_name: _0x10c426,
        language: "en",
        password: _0x239bd8
      })
    });
    const _0x137e1c = await _0x3452a5.json();
    if (_0x137e1c.errors) {
      if (_0x137e1c.errors[0].meta.rule === "unique" && _0x137e1c.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x3de178, "Email already exists. Please use a different email.");
      } else {
        _0x3f7a03.sendMessage(_0x3de178, "Error: " + JSON.stringify(_0x137e1c.errors[0], null, 2));
      }
      return;
    }
    _0x52df0c = _0x137e1c.attributes;
    const _0x44018b = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x5441c5,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x52df0c.id,
        egg: parseInt(_0x49418d),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x27206c,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x41932c,
          swap: 0,
          disk: _0x461bee,
          io: 500,
          cpu: _0xe5f94
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x206874)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x527438 = await _0x44018b.json();
    _0xc8aef8 = _0x527438.attributes;
  } catch (_0x5e40b9) {
    _0x3f7a03.sendMessage(_0x3de178, "Error: " + _0x5e40b9.message);
  }
  if (_0x52df0c && _0xc8aef8) {
    _0x3f7a03.sendMessage(_0x3de178, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0x10c426 + "\nEMAIL: " + _0x1016e1 + "\nID: " + _0x52df0c.id + "\nMEMORY: " + (_0xc8aef8.limits.memory === 0 ? "Unlimited" : _0xc8aef8.limits.memory) + " MB\nDISK: " + (_0xc8aef8.limits.disk === 0 ? "Unlimited" : _0xc8aef8.limits.disk) + " MB\nCPU: " + _0xc8aef8.limits.cpu + "%");
    if (_0x30d06a) {
      _0x3f7a03.sendAnimation(_0x398f98, _0x30d06a, {
        caption: "Hai @" + _0x398f98 + "\n\n PANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x52df0c.username + "\n〽️ Password : " + _0x239bd8 + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x3de178, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x3de178, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/9gb2 (.+)/, async (_0x390e50, _0x67c4bf) => {
  const _0x401df9 = _0x390e50.chat.id;
  const _0x2f366d = _0x67c4bf[1];
  const _0x50ea60 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x35f144 = _0x50ea60.includes(String(_0x390e50.from.id));
  if (!_0x35f144) {
    _0x3f7a03.sendMessage(_0x401df9, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Owner",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x10aea9 = _0x2f366d.split(",");
  if (_0x10aea9.length < 2) {
    _0x3f7a03.sendMessage(_0x401df9, "ᴘᴇɴɢɢᴜɴᴀᴀɴ sᴀʟᴀʜ ᴋᴇᴛɪᴋ /ᴘᴀɴᴇʟ");
    return;
  }
  const _0x2d6358 = _0x10aea9[0];
  const _0x50d675 = _0x10aea9[1];
  const _0x56ff32 = _0x2d6358 + "9gb2";
  const _0x29c5a6 = _0x12cc77.eggs;
  const _0x32d7ee = _0x12cc77.loc;
  const _0x3423ed = "9048";
  const _0x29014c = "225";
  const _0x2c40e0 = "9048";
  const _0x414431 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x40efe1 = _0x2d6358 + "panel@gmail.com";
  const _0x4e957b = _0x12cc77.pp;
  const _0x388b2a = _0x2d6358 + "871";
  let _0x29accf;
  let _0x30c241;
  try {
    const _0x3a4757 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x40efe1,
        username: _0x2d6358,
        first_name: _0x2d6358,
        last_name: _0x2d6358,
        language: "en",
        password: _0x388b2a
      })
    });
    const _0x12beff = await _0x3a4757.json();
    if (_0x12beff.errors) {
      if (_0x12beff.errors[0].meta.rule === "unique" && _0x12beff.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x401df9, "ᴜsᴇʀɴᴀᴍᴇ sᴜᴅᴀʜ ᴀᴅᴀ, ɢᴀɴᴛɪ ᴅᴇɴɢᴀɴ ʏᴀɴɢ ʟᴀɪɴ.");
      } else {
        _0x3f7a03.sendMessage(_0x401df9, "Error: " + JSON.stringify(_0x12beff.errors[0], null, 2));
      }
      return;
    }
    _0x29accf = _0x12beff.attributes;
    const _0x281a67 = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x56ff32,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x29accf.id,
        egg: parseInt(_0x29c5a6),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x414431,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x3423ed,
          swap: 0,
          disk: _0x2c40e0,
          io: 500,
          cpu: _0x29014c
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x32d7ee)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x13b2bd = await _0x281a67.json();
    _0x30c241 = _0x13b2bd.attributes;
  } catch (_0x4e1335) {
    _0x3f7a03.sendMessage(_0x401df9, "Error: " + _0x4e1335.message);
  }
  if (_0x29accf && _0x30c241) {
    _0x3f7a03.sendMessage(_0x401df9, "BERIKUT DATA PANEL ANDA\nᴜsᴇʀ: " + _0x2d6358 + "\nᴇᴍᴀɪʟ: " + _0x40efe1 + "\nɪᴅ: " + _0x29accf.id + "\nʀᴀᴍ: " + (_0x30c241.limits.memory === 0 ? "Unlimited" : _0x30c241.limits.memory) + " MB\nᴅɪsᴋ: " + (_0x30c241.limits.disk === 0 ? "Unlimited" : _0x30c241.limits.disk) + " MB\nᴄᴘᴜ: " + _0x30c241.limits.cpu + "%");
    if (_0x4e957b) {
      _0x3f7a03.sendPhoto(_0x50d675, _0x4e957b, {
        caption: "Hai @" + _0x50d675 + "\n\n\nPANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x29accf.username + "\n〽️ Password : " + _0x388b2a + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x401df9, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x401df9, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/10gb2 (.+)/, async (_0x428db0, _0x5123cf) => {
  const _0x5aed02 = _0x428db0.chat.id;
  const _0x2a0b6d = _0x5123cf[1];
  const _0x20d941 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x1488ce = _0x20d941.includes(String(_0x428db0.from.id));
  if (!_0x1488ce) {
    _0x3f7a03.sendMessage(_0x5aed02, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Owner",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x39d273 = _0x2a0b6d.split(",");
  if (_0x39d273.length < 2) {
    _0x3f7a03.sendMessage(_0x5aed02, "ᴘᴇɴɢɢᴜɴᴀᴀɴ sᴀʟᴀʜ ᴋᴇᴛɪᴋ /ᴘᴀɴᴇʟ");
    return;
  }
  const _0x43fdd6 = _0x39d273[0];
  const _0x3118b2 = _0x39d273[1];
  const _0xabe640 = _0x43fdd6 + "10gb";
  const _0x3fcea6 = _0x12cc77.eggs;
  const _0x48ad56 = _0x12cc77.loc;
  const _0xba48cb = "10000";
  const _0x3e0b2c = "250";
  const _0x17f558 = "10000";
  const _0xdf48db = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x2b60b6 = _0x43fdd6 + "panel@gmail.com";
  const _0x313f2e = _0x12cc77.pp;
  const _0x52f48b = _0x43fdd6 + "881";
  let _0x4eae64;
  let _0x27eda6;
  try {
    const _0x11a1d9 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x2b60b6,
        username: _0x43fdd6,
        first_name: _0x43fdd6,
        last_name: _0x43fdd6,
        language: "en",
        password: _0x52f48b
      })
    });
    const _0x1e39b0 = await _0x11a1d9.json();
    if (_0x1e39b0.errors) {
      if (_0x1e39b0.errors[0].meta.rule === "unique" && _0x1e39b0.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x5aed02, "ᴜsᴇʀɴᴀᴍᴇ sᴜᴅᴀʜ ᴀᴅᴀ, ɢᴀɴᴛɪ ᴅᴇɴɢᴀɴ ʏᴀɴɢ ʟᴀɪɴ.");
      } else {
        _0x3f7a03.sendMessage(_0x5aed02, "Error: " + JSON.stringify(_0x1e39b0.errors[0], null, 2));
      }
      return;
    }
    _0x4eae64 = _0x1e39b0.attributes;
    const _0x2e707c = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0xabe640,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x4eae64.id,
        egg: parseInt(_0x3fcea6),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0xdf48db,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0xba48cb,
          swap: 0,
          disk: _0x17f558,
          io: 500,
          cpu: _0x3e0b2c
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x48ad56)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x2f3d80 = await _0x2e707c.json();
    _0x27eda6 = _0x2f3d80.attributes;
  } catch (_0x2e2774) {
    _0x3f7a03.sendMessage(_0x5aed02, "Error: " + _0x2e2774.message);
  }
  if (_0x4eae64 && _0x27eda6) {
    _0x3f7a03.sendMessage(_0x5aed02, "BERIKUT DATA PANEL ANDA\nɴᴀᴍᴀ: " + _0x43fdd6 + "\nᴇᴍᴀɪʟ: " + _0x2b60b6 + "\nɪᴅ:  " + _0x4eae64.id + "\nʀᴀᴍ: " + (_0x27eda6.limits.memory === 0 ? "Unlimited" : _0x27eda6.limits.memory) + " MB\nᴅɪsᴋ: " + (_0x27eda6.limits.disk === 0 ? "Unlimited" : _0x27eda6.limits.disk) + " MB\nᴄᴘᴜ: " + _0x27eda6.limits.cpu + "%");
    if (_0x313f2e) {
      _0x3f7a03.sendPhoto(_0x3118b2, _0x313f2e, {
        caption: "Hai @" + _0x3118b2 + "\n\nPANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x4eae64.username + "\n〽️ Password : " + _0x52f48b + " \n┏━━━━━━━⬣\n│RULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — FallTamvan"
      });
      _0x3f7a03.sendMessage(_0x5aed02, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x5aed02, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/unli2 (.+)/, async (_0xc1a70a, _0x1d8cb7) => {
  const _0x3ff4a5 = _0xc1a70a.chat.id;
  const _0x19d349 = _0x1d8cb7[1];
  const _0x24894c = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x367bde = _0x24894c.includes(String(_0xc1a70a.from.id));
  if (!_0x367bde) {
    _0x3f7a03.sendMessage(_0x3ff4a5, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x2f6218 = _0x19d349.split(",");
  if (_0x2f6218.length < 2) {
    _0x3f7a03.sendMessage(_0x3ff4a5, "Invalid format. Usage: /unli2 namapanel,idtele");
    return;
  }
  const _0xaf962d = _0x2f6218[0];
  const _0x5b4803 = _0x2f6218[1];
  const _0x34796f = _0xaf962d + "unli2";
  const _0x7728ea = _0x12cc77.eggs;
  const _0x487fab = _0x12cc77.loc;
  const _0x330f78 = "0";
  const _0x5a2799 = "0";
  const _0x489e47 = "0";
  const _0x3a4328 = _0xaf962d + "@Fxyy.dev";
  const _0x5bf243 = _0x12cc77.pp;
  const _0x1e7807 = "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}";
  const _0x65e8dc = _0xaf962d + "001";
  let _0x242814;
  let _0x5253ac;
  try {
    const _0x269ef1 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x3a4328,
        username: _0xaf962d,
        first_name: _0xaf962d,
        last_name: _0xaf962d,
        language: "en",
        password: _0x65e8dc
      })
    });
    const _0x58eb42 = await _0x269ef1.json();
    if (_0x58eb42.errors) {
      if (_0x58eb42.errors[0].meta.rule === "unique" && _0x58eb42.errors[0].meta.source_field === "email") {
        _0x3f7a03.sendMessage(_0x3ff4a5, "Email&user telah ada di panel — 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧.");
      } else {
        _0x3f7a03.sendMessage(_0x3ff4a5, "Error: " + JSON.stringify(_0x58eb42.errors[0], null, 2));
      }
      return;
    }
    _0x242814 = _0x58eb42.attributes;
    const _0x14f41b = await fetch(_0x206b50 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        name: _0x34796f,
        description: "— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧",
        user: _0x242814.id,
        egg: parseInt(_0x7728ea),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: _0x1e7807,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: _0x330f78,
          swap: 0,
          disk: _0x489e47,
          io: 500,
          cpu: _0x5a2799
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(_0x487fab)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const _0x2b91f2 = await _0x14f41b.json();
    _0x5253ac = _0x2b91f2.attributes;
  } catch (_0x2d45e9) {
    _0x3f7a03.sendMessage(_0x3ff4a5, "Error: " + _0x2d45e9.message);
  }
  if (_0x242814 && _0x5253ac) {
    _0x3f7a03.sendMessage(_0x3ff4a5, "BERIKUT DATA PANEL ANDA\nNAMA: " + _0xaf962d + "\nEMAIL: " + _0x3a4328 + "\nID: " + _0x242814.id + "\nMEMORY: " + (_0x5253ac.limits.memory === 0 ? "Unlimited" : _0x5253ac.limits.memory) + " MB\nDISK: " + (_0x5253ac.limits.disk === 0 ? "Unlimited" : _0x5253ac.limits.disk) + " MB\nCPU: " + _0x5253ac.limits.cpu + "%");
    if (_0x5bf243) {
      _0x3f7a03.sendAnimation(_0x5b4803, _0x5bf243, {
        caption: "Hai @" + _0x5b4803 + "\n\nPANEL DATA ANDA :\n〽️ Login : " + _0x206b50 + "\n〽️ Username : " + _0x242814.username + "\n〽️ Password : " + _0x65e8dc + " \n┏━━━━━━━⬣\nRULES :\n│• Jangan Ddos Server\n│• Wajib tutup domain saat screenshot\n│• Jngan bagikan domain ke siapapun\n┗━━━━━━━━━━━━━━━━━━⬣\nCREATE PANEL BY — Falltamvan"
      });
      _0x3f7a03.sendMessage(_0x3ff4a5, "Data panel berhasil dikirim ke ID Telegram yang dimaksud.");
    }
  } else {
    _0x3f7a03.sendMessage(_0x3ff4a5, "Gagal membuat data panel. Silakan coba lagi.");
  }
});
_0x3f7a03.onText(/\/createadmin2 (.+)/, async (_0x30cc63, _0x2a8591) => {
  const _0x175127 = _0x30cc63.chat.id;
  const _0x3f4c16 = _0x30cc63.from.id;
  const _0x35c78a = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x595aa4 = _0x35c78a.includes(String(_0x30cc63.from.id));
  if (!_0x595aa4) {
    _0x3f7a03.sendMessage(_0x175127, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x582b13 = _0x2a8591[1].split(",");
  const _0x484aa3 = _0x582b13[0].trim();
  const _0x5da3ee = _0x582b13[1].trim();
  if (_0x582b13.length < 2) {
    _0x3f7a03.sendMessage(_0x175127, "Format Salah! Penggunaan: /createadmin2 namapanel,idtele");
    return;
  }
  const _0x49422e = _0x484aa3 + "117";
  try {
    const _0x5d9962 = await fetch(_0x206b50 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x447c7d
      },
      body: JSON.stringify({
        email: _0x484aa3 + "@Fxyy.dev",
        username: _0x484aa3,
        first_name: _0x484aa3,
        last_name: "Memb",
        language: "en",
        root_admin: true,
        password: _0x49422e
      })
    });
    const _0x5b86dc = await _0x5d9962.json();
    if (_0x5b86dc.errors) {
      _0x3f7a03.sendMessage(_0x175127, JSON.stringify(_0x5b86dc.errors[0], null, 2));
      return;
    }
    const _0x2a95da = _0x5b86dc.attributes;
    const _0x235687 = "\nTYPE: user\n➟ ID: " + _0x2a95da.id + "\n➟ USERNAME: " + _0x2a95da.username + "\n➟ EMAIL: " + _0x2a95da.email + "\n➟ NAME: " + _0x2a95da.first_name + " " + _0x2a95da.last_name + "\n➟ LANGUAGE: " + _0x2a95da.language + "\n➟ ADMIN: " + _0x2a95da.root_admin + "\n➟ CREATED AT: " + _0x2a95da.created_at + "\n    ";
    _0x3f7a03.sendMessage(_0x175127, _0x235687);
    _0x3f7a03.sendMessage(_0x5da3ee, "\n┏━⬣❏「 INFO DATA ADMIN PANEL 」❏\n│➥  Login : " + _0x206b50 + "\n│➥  Username : " + _0x2a95da.username + "\n│➥  Password : " + _0x49422e + " \n┗━━━━━━━━━⬣\n│ Rules : \n│• Jangan Curi Sc\n│• Jangan Buka Panel Orang\n│• Jangan Ddos Server\n│• Kalo jualan sensor domainnya\n│• Jangan Bagi² Panel Free !!\n┗━━━━━━━━━━━━━━━━━━⬣\nTHANKS FOR FALL\n    ");
  } catch (_0x4a51ee) {
    console.error(_0x4a51ee);
    _0x3f7a03.sendMessage(_0x175127, "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti.");
  }
});
_0x3f7a03.onText(/\/createadmin (.+)/, async (_0x13b774, _0x4b0d6b) => {
  const _0x291239 = _0x13b774.chat.id;
  const _0x20a875 = _0x13b774.from.id;
  const _0x5f23a8 = JSON.parse(_0x2230b1.readFileSync(_0x187e45));
  const _0x1453d5 = _0x5f23a8.includes(String(_0x13b774.from.id));
  if (!_0x1453d5) {
    _0x3f7a03.sendMessage(_0x291239, "𝐌𝐢𝐧𝐭𝐚 𝐀𝐤𝐬𝐞𝐬 𝐝𝐥𝐮 𝐛𝐫𝐨 #— 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧", {
      reply_markup: {
        inline_keyboard: [[{
          text: "Ｃｏｎｔａｃｋ",
          url: "https://t.me/XxzFallOffc"
        }]]
      }
    });
    return;
  }
  const _0x1b3655 = _0x4b0d6b[1].split(",");
  const _0xd4e94f = _0x1b3655[0].trim();
  const _0x246aa8 = _0x1b3655[1].trim();
  if (_0x1b3655.length < 2) {
    _0x3f7a03.sendMessage(_0x291239, "Format Salah! Penggunaan: /createadmin namapanel,idtele");
    return;
  }
  const _0x58ac5f = _0xd4e94f + "117";
  try {
    const _0x1633b9 = await fetch(_0xb62ec7 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + _0x5a238b
      },
      body: JSON.stringify({
        email: _0xd4e94f + "@Fxyy.dev",
        username: _0xd4e94f,
        first_name: _0xd4e94f,
        last_name: "Memb",
        language: "en",
        root_admin: true,
        password: _0x58ac5f
      })
    });
    const _0x523364 = await _0x1633b9.json();
    if (_0x523364.errors) {
      _0x3f7a03.sendMessage(_0x291239, JSON.stringify(_0x523364.errors[0], null, 2));
      return;
    }
    const _0x30590c = _0x523364.attributes;
    const _0x533257 = "\nTYPE: user\n➟ ID: " + _0x30590c.id + "\n➟ USERNAME: " + _0x30590c.username + "\n➟ EMAIL: " + _0x30590c.email + "\n➟ NAME: " + _0x30590c.first_name + " " + _0x30590c.last_name + "\n➟ LANGUAGE: " + _0x30590c.language + "\n➟ ADMIN: " + _0x30590c.root_admin + "\n➟ CREATED AT: " + _0x30590c.created_at + "\n    ";
    _0x3f7a03.sendMessage(_0x291239, _0x533257);
    _0x3f7a03.sendMessage(_0x246aa8,"\n┏━⬣❏「 INFO DATA ADMIN PANEL 」❏\n│➥  Login : " + _0xb62ec7 + "\n│➥  Username : " + _0x30590c.username + "\n│➥  Password : " + _0x58ac5f + " \n┗━━━━━━━━━⬣\n│ Rules : \n│• Jangan Curi Sc\n│• Jangan Buka Panel Orang\n│• Jangan Ddos Server\n│• Kalo jualan sensor domainnya\n│• Jangan Bagi² Panel Free !!\n┗━━━━━━━━━━━━━━━━━━⬣\nTHANKS FOR — FallOffc\n    ");
  } catch (_0x3e77c6) {
    console.error(_0x3e77c6);
    _0x3f7a03.sendMessage(_0x291239, "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti.");
  }
});
_0x2230b1.readFile(_0x187e45, (_0x10a7c3, _0x4656b2) => {
  if (_0x10a7c3) {
    console.error(_0x10a7c3);
  } else {
    adminIDs = JSON.parse(_0x4656b2);
  }
});
console.log(_0x57388a.green.bold("\nCreate Panel Telegram\n" + _0x57388a.white.bold("⎋VERSION : 3.0.0\n⎋Developer : — FallOffc") + "\n\n" + _0x57388a.green.bold("🧾 Information :") + "   \n" + _0x57388a.white.bold("⎋ Script : Create Panel — FallOffc\n⎋ Author : — 𝐝𝐢𝐬𝐜𝐮𝐬𝐢𝐜𝐨𝐧\n⎋ Versi : 3.0.0\n") + "\n" + _0x57388a.green.italic("Bot Telegram Anda Sudah Berjalan....") + "\n"));